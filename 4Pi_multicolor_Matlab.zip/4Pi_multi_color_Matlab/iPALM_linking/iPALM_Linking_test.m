%%
gap=1;
[vutarax1,vutaray1,vutaraz1,vutarat1,vutaraI1,vutarabg1,vutaracrlb1,vutarall1,vutarazerr1,vutarazcon1,vutarazaster1,ID,ML]=...
    Vutara_Linking(vutarax,vutaray,vutaraz,vutarat,vutaraI,vutarabg,vutaracrlb,vutarall,vutarazerr,vutarazcon,vutarazaster,gap);
