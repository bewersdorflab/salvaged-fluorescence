%%
gap=30;
vutarazaster=vutarazerr;
[vutarax1,vutaray1,vutaraz1,vutarat1,vutaraI1,vutarabg1,vutaracrlb1,vutarall1,vutarazerr1,vutarazcon1,vutarazaster1,ID1,ML1]=...
    Vutara_Linking(vutarax{1},vutaray{1},vutaraz{1},vutarat{1},vutaraI{1},vutarabg{1},vutaracrlb{1},vutarall{1},vutarazerr{1},vutarazcon{1},vutarazaster{1},gap);

[vutarax2,vutaray2,vutaraz2,vutarat2,vutaraI2,vutarabg2,vutaracrlb2,vutarall2,vutarazerr2,vutarazcon2,vutarazaster2,ID2,ML2]=...
    Vutara_Linking(vutarax{2},vutaray{2},vutaraz{2},vutarat{2},vutaraI{2},vutarabg{2},vutaracrlb{2},vutarall{2},vutarazerr{2},vutarazcon{2},vutarazaster{2},gap);
%%
currentfolder='E:\4Pi_Paper\tubulin_ER\20171005\';
savename='Cell03_gap30';

%%
vutarax=[];
vutaray=[];
vutaraz=[];
vutarat=[];
vutaraI=[];
vutaracrlb=[];
vutarall=[];
vutarabg=[];
vutarazcon=[];
vutarazerr=[];
vutarax{1}=vutarax1;
vutarax{2}=vutarax2;
vutaray{1}=vutaray1;
vutaray{2}=vutaray2;
vutaraz{1}=vutaraz1;
vutaraz{2}=vutaraz2;
vutarat{1}=ceil(vutarat1/100);
vutarat{2}=ceil(vutarat2/100);
vutaraI{1}=vutaraI1;
vutaraI{2}=vutaraI2;
vutaracrlb{1}=vutaracrlb1;
vutaracrlb{2}=vutaracrlb2;
vutarall{1}=vutarall1;
vutarall{2}=vutarall2;
vutarabg{1}=vutarabg1;
vutarabg{2}=vutarabg2;
vutarazcon{1}=vutarazcon1;
vutarazcon{2}=vutarazcon2;
vutarazerr{1}=vutarazaster1;
vutarazerr{2}=vutarazaster2;

%%
coords=[];
coords(:,1)=vutarax{1}/10;
coords(:,2)=vutaray{1}/10;
coords(:,3)=vutarat{1};
zm=12.8;
szx=168*zm;
szy=168*zm;
im=cHistRecon(szx,szy,single(coords(:,1)),single(coords(:,2)),0);
gaussim=gaussf(im,[1 1]);
% str1=([currentfolder savename '_dot_1.tif']);
str2=([currentfolder savename '_gauss_1.tif']);
% writeim(im,str1,'tiff',1);
writeim(gaussim,str2,'tiff',1);

coords=[];
coords(:,1)=vutarax{2}/10;
coords(:,2)=vutaray{2}/10;
coords(:,3)=vutarat{2};
zm=12.8;
szx=168*zm;
szy=168*zm;
im=cHistRecon(szx,szy,single(coords(:,1)),single(coords(:,2)),0);
gaussim=gaussf(im,[1 1]);
% str1=([currentfolder savename '_dot_2.tif']);
str2=([currentfolder savename '_gauss_2.tif']);
% writeim(im,str1,'tiff',1);
writeim(gaussim,str2,'tiff',1);

[flag]=iPALM2vutarav2(currentfolder,[savename '_ll'],2,vutarax,vutaray,vutaraz,vutarat,vutaraI,vutaracrlb,vutarall,vutarabg,vutarazcon,vutarazerr);
vutarat{1}=vutarat1;
vutarat{2}=vutarat2;
save([currentfolder savename '_' '642' 'v20_60_two_color'],'vutarax','vutaray','vutaraz','vutarat','vutarall','vutaraI','vutarabg','vutarazcon','vutaracrlb','vutarazerr','ID1','ML1','ID2','ML2');
