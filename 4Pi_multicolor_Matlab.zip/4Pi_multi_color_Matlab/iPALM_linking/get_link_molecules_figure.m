%%
L=length(ID);
V=[];
m=0;
for i=1:L
    ix=ID{i,1};
    if length(ix)>9 && max(vutaracrlb(ix))<15/128
        cx=vutarax(ix);
        cy=vutaray(ix);
        cz=vutaraz(ix);
        crlb=vutaracrlb(ix)*128;
        I=vutaraI(ix);
        cx=cx-mean(cx);
        cy=cy-mean(cy);
        cz=cz-mean(cz);
        V0=[cx,cy,cz,crlb,I];
        V=cat(1,V,V0);
        m=m+1;
    end
end

std(V(:,1:3))
std(V(:,1:3))*2.3548

%% AF647
figure('Position',[200 100 900 600]);hold on;
subplot(2,2,1);plot3(V(:,1),V(:,2),V(:,3),'b.');set(gca,'linewidth',2,'fontsize',16);axis([-40 40 -40 40 -40 40]);xlabel('x (nm)');ylabel('y (nm)');zlabel('z (nm)');title('from 1117 clusters > 9 localizations');
subplot(2,2,2);histogram(V(:,1),(-40:2:40));set(gca,'linewidth',2,'fontsize',16);axis([-40 40 0 2500]);xlabel('x (nm)');ylabel('count');title('\sigma_x = 7.0 nm')
subplot(2,2,3);histogram(V(:,2),(-40:2:40));set(gca,'linewidth',2,'fontsize',16);axis([-40 40 0 2500]);xlabel('y (nm)');ylabel('count');title('\sigma_y = 6.7 nm')
subplot(2,2,4);histogram(V(:,3),(-40:2:40));set(gca,'linewidth',2,'fontsize',16);axis([-40 40 0 2500]);xlabel('z (nm)');ylabel('count');title('\sigma_z = 4.8 nm')
fnames='E:\4Pi_Paper\resolution\FigureS_AF647.jpg';
print('-djpeg','-r300',fnames);

%% CF660C
figure('Position',[200 100 900 600]);hold on
subplot(2,2,1);plot3(V(:,1),V(:,2),V(:,3),'b.'); set(gca,'linewidth',2,'fontsize',16);axis([-40 40 -40 40 -40 40]);xlabel('x (nm)');ylabel('y (nm)');zlabel('z (nm)');title('from 920 clusters > 9 localizations')
subplot(2,2,2);histogram(V(:,1),(-40:2:40));set(gca,'linewidth',2,'fontsize',16);axis([-40 40 0 1800]);xlabel('x (nm)');ylabel('count');title('\sigma_x = 7.1 nm')
subplot(2,2,3);histogram(V(:,2),(-40:2:40));set(gca,'linewidth',2,'fontsize',16);axis([-40 40 0 1800]);xlabel('y (nm)');ylabel('count');title('\sigma_y = 7.4 nm')
subplot(2,2,4);histogram(V(:,3),(-40:2:40));set(gca,'linewidth',2,'fontsize',16);axis([-40 40 0 1800]);xlabel('z (nm)');ylabel('count');title('\sigma_z = 4.9 nm')
fnames='E:\4Pi_Paper\resolution\FigureS_CF660C.jpg';
print('-djpeg','-r300',fnames);

%% DY634
figure('Position',[200 100 900 600]);hold on
subplot(2,2,1);plot3(V(:,1),V(:,2),V(:,3),'b.');set(gca,'linewidth',2,'fontsize',16);axis([-40 40 -40 40 -40 40]);xlabel('x (nm)');ylabel('y (nm)');zlabel('z (nm)');title('from 923 clusters > 9 localizations')
subplot(2,2,2);histogram(V(:,1),(-40:2:40));set(gca,'linewidth',2,'fontsize',16);axis([-40 40 0 1600]);xlabel('x (nm)');ylabel('count');title('\sigma_x = 8.6 nm')
subplot(2,2,3);histogram(V(:,2),(-40:2:40));set(gca,'linewidth',2,'fontsize',16);axis([-40 40 0 1600]);xlabel('y (nm)');ylabel('count');title('\sigma_y = 9.2 nm')
subplot(2,2,4);histogram(V(:,3),(-40:2:40));set(gca,'linewidth',2,'fontsize',16);axis([-40 40 0 1600]);xlabel('z (nm)');ylabel('count');title('\sigma_z = 6.1 nm')
fnames='E:\4Pi_Paper\resolution\FigureS_DY634.jpg';
print('-djpeg','-r300',fnames);

%% DL650
figure('Position',[200 100 900 600]);hold on
subplot(2,2,1);plot3(V(:,1),V(:,2),V(:,3),'b.');set(gca,'linewidth',2,'fontsize',16);axis([-40 40 -40 40 -40 40]);xlabel('x (nm)');ylabel('y (nm)');zlabel('z (nm)');title('from 881 clusters > 9 localizations')
subplot(2,2,2);histogram(V(:,1),(-40:2:40));set(gca,'linewidth',2,'fontsize',16);axis([-40 40 0 1800]);xlabel('x (nm)');ylabel('count');title('\sigma_x = 7.2 nm')
subplot(2,2,3);histogram(V(:,2),(-40:2:40));set(gca,'linewidth',2,'fontsize',16);axis([-40 40 0 1800]);xlabel('y (nm)');ylabel('count');title('\sigma_y = 7.6 nm')
subplot(2,2,4);histogram(V(:,3),(-40:2:40));set(gca,'linewidth',2,'fontsize',16);axis([-40 40 0 1800]);xlabel('z (nm)');ylabel('count');title('\sigma_z = 5.1 nm')
fnames='E:\4Pi_Paper\resolution\FigureS_DL650.jpg';
print('-djpeg','-r300',fnames);

%% CF680
figure('Position',[200 100 900 600]);hold on
subplot(2,2,1);plot3(V(:,1),V(:,2),V(:,3),'b.');set(gca,'linewidth',2,'fontsize',16);axis([-40 40 -40 40 -40 40]);xlabel('x (nm)');ylabel('y (nm)');zlabel('z (nm)');title('from 1144 clusters > 9 localizations')
subplot(2,2,2);histogram(V(:,1),(-40:2:40));set(gca,'linewidth',2,'fontsize',16);axis([-40 40 0 2000]);xlabel('x (nm)');ylabel('count');title('\sigma_x = 9.7 nm')
subplot(2,2,3);histogram(V(:,2),(-40:2:40));set(gca,'linewidth',2,'fontsize',16);axis([-40 40 0 2000]);xlabel('y (nm)');ylabel('count');title('\sigma_y = 9.2 nm')
subplot(2,2,4);histogram(V(:,3),(-40:2:40));set(gca,'linewidth',2,'fontsize',16);axis([-40 40 0 2000]);xlabel('z (nm)');ylabel('count');title('\sigma_z = 5.8 nm')
fnames='E:\4Pi_Paper\resolution\FigureS_CF680.jpg';
% print('-djpeg','-r300',fnames);

