function ID=iPALM_Linking(x,y,z,t,gap,dist,crlb)
%%
t=t+1;
V=[x,y,z,t];
V(:,5)=0;
V(:,6)=(1:size(V,1))';
V(:,7)=crlb;
fn=max(t);

M=size(V,1);
ID=cell(M,1);

tic
if gap<20 && size(V,1)>10000   % link frame by frame
    V1=cell(fn,1);
    for i=1:fn
        id=V(:,4)==i;
        V1{i,1}=V(id,:);
    end   
    n=0;
    for j=1:fn
        m=length(V1{j}(:,1));
        for i=1:m
            if V1{j}(i,5)==0
                n=n+1;
                V1{j}(i,5)=n;
                id=V1{j}(i,6);
                V(id,5)=n;
                ID{n}(1)=id;
                ii=2;
                k=j+1;
                stopframe=min(j+gap,fn);
                cx=V1{j}(i,1);
                cy=V1{j}(i,2);
                cz=V1{j}(i,3);
                sig0=V1{j}(i,7);
                while k<=stopframe
                    Tx=V1{k}(:,1);
                    Ty=V1{k}(:,2);
                    Tz=V1{k}(:,3);
                    sig1=V1{k}(:,7);
                    sig=sqrt(sig0.^2+sig1.^2);
                    dist=2*sig;
                    %                 Dist=sqrt((Tx-cx).^2+(Ty-cy).^2+(Tz-cz).^2);
                    %                 id=Dist<dist;
                    id=abs(Tx-cx)<dist & abs(Ty-cy)<dist & abs(Tz-cz)<dist;
                    if any(id)
                        cx=mean(Tx(id));
                        cy=mean(Ty(id));
                        cz=mean(Tz(id));
                        V1{k}(id,5)=n;
                        ix=V1{k}(id,6);
                        V(ix,5)=n;
                        for l=1:length(ix)
                            ID{n}(ii)=ix(l);
                            ii=ii+1;
                        end
                        stopframe=min(k+gap,fn);
                    end
                    k=k+1;
                end
            end
        end
    end
else % link by molecule
    m=size(V,1);
    n=0;
    for i=1:m
        if V(i,5)==0
            n=n+1;
            V(i,5)=n;
            ID{n}(1)=i;
            k=V(i,4)+1;
            cx=V(i,1);
            cy=V(i,2);
            cz=V(i,3);
            sig0=V(i,7);
            stopframe=min(V(i,4)+gap,fn);
            st=2;
            while k<=stopframe
                id=V(:,5)==0 & V(:,4)>=k & V(:,4)<=stopframe;
                V1=V(id,:);
                sig1=V1(:,7);
                sig=sqrt(sig0.^2+sig1.^2);
                dist=2*sig;
                id=abs(V1(:,1)-cx)<=dist & abs(V1(:,2)-cy)<=dist & abs(V1(:,3)-cz)<=dist;
                if any(id)
                    id=V1(id,6);
                    mm=length(id);
                    ID{n}(st:st+mm-1)=id;
                    st=st+mm;
                    V(id,5)=n;
                    Vnew=V(id,:);
                    k=max(Vnew(:,4))+1;
                    stopframe=min(max(Vnew(:,4))+gap,fn);
                    %% update position
                    %  cx=Vnew(end,1);
                    %  cy=Vnew(end,2);
                    cx=mean(Vnew(:,1));
                    cy=mean(Vnew(:,2));
                    cz=mean(Vnew(:,3));
                else
                    break;
                end
            end
        end
    end
end
toc

% %%
% for i=1:M
%     if isempty(ID{i})
%         break
%     end  
% end
% n=i-1;
% 
% handles.fitInfo(:,11)=V(:,5);                   %% molecule number
% V_link=zeros(n,11);
% for i=1:n
%     IX=ID{i};
%     handles.fitInfo_link(i,11)=length(IX);         %% molecule length
%     V0=[];
%     V0(:,1:3)=V(IX,1:3);
%     V0(:,4:10)=handles.fitInfo(IX,4:10);
%     handles.fitInfo_link(i,1)=sum(V0(:,1).*V0(:,4))/sum(V0(:,4));
%     handles.fitInfo_link(i,2)=sum(V0(:,2).*V0(:,4))/sum(V0(:,4));
%     handles.fitInfo_link(i,3)=V0(1,3);
%     handles.fitInfo_link(i,4:10)=mean(V0(:,4:10),1);
%     if floor(i/n*100)>floor((i-1)/n*100)
%         mywaitbar(i/n,handles.axes1,[num2str(floor(i/n*100)),'%']);
%     end
% end
