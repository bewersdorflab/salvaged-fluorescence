L=length(ID);
V=[];
m=0;
for i=1:L
    ix=ID{i,1};
    if length(ix)>9 && max(vutaracrlb(ix))<0.15
        cx=vutarax(ix);
        cy=vutaray(ix);
        cz=vutaraz(ix);
        cx=cx-mean(cx);
        cy=cy-mean(cy);
        cz=cz-mean(cz);
        V0=[cx,cy,cz];
        V=cat(1,V,V0);
        m=m+1;
    end
end

plot3(V(:,1),V(:,2),V(:,3),'b.');
std(V)
std(V)*2.3548

%%
L=length(ID1);
V1=[];
m1=0;
for i=1:L
    ix=ID1{i,1};
    if length(ix)>9
        cx=vutarax{1}(ix);
        cy=vutaray{1}(ix);
        cz=vutaraz{1}(ix);
        cx=cx-mean(cx);
        cy=cy-mean(cy);
        cz=cz-mean(cz);
        V0=[cx,cy,cz];
        V1=cat(1,V1,V0);
        m1=m1+1;
    end
end

plot3(V1(:,1),V1(:,2),V1(:,3),'b.');
std(V1)
std(V1)*2.3548

L=length(ID2);
V2=[];
m2=0;
for i=1:L
    ix=ID2{i,1};
    if length(ix)>9
        cx=vutarax{2}(ix);
        cy=vutaray{2}(ix);
        cz=vutaraz{2}(ix);
        cx=cx-mean(cx);
        cy=cy-mean(cy);
        cz=cz-mean(cz);
        V0=[cx,cy,cz];
        V2=cat(1,V2,V0);
        m2=m2+1;
    end
end

plot3(V2(:,1),V2(:,2),V2(:,3),'b.');
std(V2)
std(V2)*2.3548