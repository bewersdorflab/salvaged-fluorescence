function [vutarax1,vutaray1,vutaraz1,vutarat1,vutaraI1,vutarabg1,vutaracrlb1,vutarall1,vutarazerr1,vutarazcon1,vutarazaster1,ID,ML]=...
    Vutara_Linking(vutarax,vutaray,vutaraz,vutarat,vutaraI,vutarabg,vutaracrlb,vutarall,vutarazerr,vutarazcon,vutarazaster,gap)

x=vutarax;
y=vutaray;
z=vutaraz;
t=vutarat;
crlb=vutaracrlb*128;
% gap=100;
dist=30;
ID=iPALM_Linking(x,y,z,t,gap,dist,crlb);

%%
M=length(ID);
for i=1:M
    if isempty(ID{i})
        break
    end  
end
N=i-1;

%%
vutarax1=zeros(N,1);
vutaray1=zeros(N,1);
vutaraz1=zeros(N,1);
vutarat1=zeros(N,1);
vutaraI1=zeros(N,1);
vutarabg1=zeros(N,1);
vutaracrlb1=zeros(N,1);
vutarall1=zeros(N,1);
vutarazerr1=zeros(N,1);
vutarazcon1=zeros(N,1);
vutarazaster1=zeros(N,1);
ML=zeros(N,1);
for i=1:N
    IX=ID{i};
    ML(i,1)=length(IX);
    vutarax1(i,1)=mean(vutarax(IX));
    vutaray1(i,1)=mean(vutaray(IX));
    vutaraz1(i,1)=mean(vutaraz(IX));
    vutarat1(i,1)=min(vutarat(IX));
    vutaraI1(i,1)=sum(vutaraI(IX));
    vutarabg1(i,1)=mean(vutarabg(IX));
    vutaracrlb1(i,1)=mean(vutaracrlb(IX));
    vutarall1(i,1)=mean(vutarall(IX));
    vutarazerr1(i,1)=mean(vutarazerr(IX));
    vutarazcon1(i,1)=mean(vutarazcon(IX));
    vutarazaster1(i,1)=mean(vutarazaster(IX));
end

%%
% pixelsz=50;
% x1_1=single(vutarax1)/pixelsz;
% x2_1=single(vutaray1)/pixelsz;
% x1sz=ceil(128*168/pixelsz);
% im1=cHistRecon(x1sz,x1sz,x1_1,x2_1,0);
% dipshow(im1);