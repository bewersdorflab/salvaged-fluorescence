function [qd1,qd2,qd3,qd4]=medFilter2(qd1,qd2,qd3,qd4,fnum)
    num_images=size(qd1,3);
    seg=num_images/fnum;
    for k=1:seg
        st=(k-1)*fnum+1;
        et=k*fnum;
        
        medianMap=median(qd1(:,:,st:et),3);
        medianMap=medianMap-min(medianMap(:));
        qd1(:,:,st:et)=qd1(:,:,st:et)-repmat(medianMap,[1,1,fnum]);        

        medianMap=median(qd2(:,:,st:et),3);
        medianMap=medianMap-min(medianMap(:));
        qd2(:,:,st:et)=qd2(:,:,st:et)-repmat(medianMap,[1,1,fnum]);
        
        medianMap=median(qd3(:,:,st:et),3);
        medianMap=medianMap-min(medianMap(:));
        qd3(:,:,st:et)=qd3(:,:,st:et)-repmat(medianMap,[1,1,fnum]);
        
        medianMap=median(qd4(:,:,st:et),3);
        medianMap=medianMap-min(medianMap(:));
        qd4(:,:,st:et)=qd4(:,:,st:et)-repmat(medianMap,[1,1,fnum]);
    end
    qd1(qd1<=1e-6)=1e-6;
    qd2(qd2<=1e-6)=1e-6;
    qd3(qd3<=1e-6)=1e-6;
    qd4(qd4<=1e-6)=1e-6;
end