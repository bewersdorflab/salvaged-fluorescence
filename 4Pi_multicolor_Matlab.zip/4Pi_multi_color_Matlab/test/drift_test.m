clc
P=PT(vutarapr,:);
R=RT(vutarapr,:);
mask=vutarall<300 & vutarazerr<60 & P(:,2)>0 & P(:,3)>0;% & vutarax>4000 & vutarax<16000 & vutaray>2000 & vutaray<14000;% & vutaraz>-300 & vutaraz<200;% & vutarat>3000; 
% mask=P(:,2)>0;
P=P(mask,:);
R=R(mask,:);
% mask=ones(length(vutarax),1)>0;
xout=vutarax(mask);
yout=vutaray(mask);
zout=vutaraz(mask);
currt=vutarat(mask); 
currI=vutaraI(mask);
currcrlb=vutaracrlb(mask);
currll=vutarall(mask);
currbg=vutarabg(mask);
currzcon=vutarazcon(mask);
currzerr=vutarazerr(mask);

%%
id=currt<3000;
x=xout(id);
y=yout(id);
z=zout(id);
t=currt(id);

%%
x1in=x;
x2in=y;
x3in=z;
pixelsz=10;
rndsz=2;
x1=floor((x1in-min(x1in(:)))./pixelsz);
x2=floor((x2in-min(x2in(:)))./pixelsz);
x3=floor((x3in-min(x3in(:)))./pixelsz);
% x1=floor((x1in)./pixelsz);
% x2=floor((x2in)./pixelsz);
x1sz=ceil(max(x1)/rndsz)*rndsz+1;
x2sz=ceil(max(x2)/rndsz)*rndsz+1;
x3sz=max(ceil(max(x3)/rndsz)*rndsz+1,21);

x1_1=x1;
x2_1=x2;
x3_1=x3;
x1_2=x1_1+0;
x2_2=x2_1-0;
x3_2=x3_1-8;

% im1=cHistRecon(x1sz,x2sz,x1_1,x2_1,0);
% im2=cHistRecon(x1sz,x2sz,x1_2,x2_2,0);

im1=cHistRecon(x1sz,single(x3sz),x1_1,single(x3_1),0);
im2=cHistRecon(x1sz,single(x3sz),x1_2,single(x3_2),0);

%%
corrim=normxcorr2(im1,im2);
rowval=(size(corrim,1)+1)./2;
colval=(size(corrim,2)+1)./2;
cropsz2 = 32; 
ori=[colval-cropsz2/2-1 rowval-cropsz2/2-1];
smallim=cut(corrim,cropsz2,ori);

corr = CrossCorrelation(im1,im2);
rowval=(size(corr,1)+1)./2;
colval=(size(corr,2)+1)./2;
cropsz2 = 32; 
ori=[colval-cropsz2/2-1 rowval-cropsz2/2-1];

A=mean(corrim,1)';
B=mean(corr,1)';
smallim1=cut(corr,cropsz2,ori);