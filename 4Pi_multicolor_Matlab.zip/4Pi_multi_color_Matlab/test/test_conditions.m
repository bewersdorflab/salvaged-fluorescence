clc
path='G:\4PISCMOS\2016-12-14\20161214\';
str=strcat(path,'*tmpresult*.mat');
files=dir(str);
L=length(files);
D=[];
for i=1:L
    filename=strcat(path,files(i,1).name);
    P=importdata(filename);
    D(i,1)=mean(P.Iresult);
    D(i,2)=median(P.Iresult);
    D(i,3)=mean(P.bgresult);
    D(i,4)=D(i,1)/D(i,3);
    A=P.CRLBresult(:,1);
    A=abs(A);
    A=A(A<1);
    D(i,5)=mean(A);
    D(i,6)=median(A);
    D(i,7)=mean(P.zangctrresult(P.zangctrresult<1));
    D(i,8)=mean(P.zast_err_result);
    D(i,9)=std(P.zfresult(P.zfresult>0 & P.zfresult<1200));
end