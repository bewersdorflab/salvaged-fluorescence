function [qd1,qd2,qd3,qd4]=medFilter(qd1,qd2,qd3,qd4,fnum)
    num_images=size(qd1,3);
    seg=ceil(num_images/fnum);
    sz=size(qd1,1);
    for k=1:seg
        st=(k-1)*fnum+1;
        et=k*fnum;
        medianMap=zeros(sz,sz);
        for i=1:sz
            for j=1:sz
                I=qd1(i,j,st:et);
                threshold=mean(I)+3*std(I);
                id=I<threshold;
                I=I(id);
                medianMap(i,j)=median(I);
            end
        end
        medianMap=medianMap-min(medianMap(:));
        qd1(:,:,st:et)=qd1(:,:,st:et)-repmat(medianMap,[1,1,fnum]);        

        medianMap=zeros(sz,sz);
        for i=1:sz
            for j=1:sz
                I=qd2(i,j,st:et);
                threshold=mean(I)+3*std(I);
                id=I<threshold;
                I=I(id);
                medianMap(i,j)=median(I);
            end
        end
        medianMap=medianMap-min(medianMap(:));
        qd2(:,:,st:et)=qd2(:,:,st:et)-repmat(medianMap,[1,1,fnum]);

        medianMap=zeros(sz,sz);
        for i=1:sz
            for j=1:sz
                I=qd3(i,j,st:et);
                threshold=mean(I)+3*std(I);
                id=I<threshold;
                I=I(id);
                medianMap(i,j)=median(I);
            end
        end
        medianMap=medianMap-min(medianMap(:));
        qd3(:,:,st:et)=qd3(:,:,st:et)-repmat(medianMap,[1,1,fnum]);

        medianMap=zeros(sz,sz);
        for i=1:sz
            for j=1:sz
                I=qd4(i,j,st:et);
                threshold=mean(I)+3*std(I);
                id=I<threshold;
                I=I(id);
                medianMap(i,j)=median(I);
            end
        end
        medianMap=medianMap-min(medianMap(:));
        qd4(:,:,st:et)=qd4(:,:,st:et)-repmat(medianMap,[1,1,fnum]);
    end
    qd1(qd1<=1e-6)=1e-6;
    qd2(qd2<=1e-6)=1e-6;
    qd3(qd3<=1e-6)=1e-6;
    qd4(qd4<=1e-6)=1e-6;
end