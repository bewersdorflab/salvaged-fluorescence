clear
% clc
centers=[235,476,1554,1796];
dataFolder1='G:\4PISCMOS\test\2017-10-31\Cell10\Cell10_642_000_000.dcimg';
dataFolder2='G:\4PISCMOS\test\2017-10-31\Cell11\Cell11_642_000_000.dcimg';
[~,qds1]=iPALM_readdcimg(dataFolder1,centers);
[~,qds2]=iPALM_readdcimg(dataFolder2,centers);

for t=1:4
    meanqds1 = mean(qds1(:,:,:,t),3);
    offset = median(meanqds1(:));
    meanqds1=meanqds1-offset;
    meanqds1(meanqds1<=0)=1e-37;
%     meanqds1=medfilt2(meanqds1);
    
    meanqds2 = mean(qds2(:,:,:,t),3);
    offset = median(meanqds2(:));
    meanqds2=meanqds2-offset;
    meanqds2(meanqds2<=0)=1e-37;
%     meanqds2=medfilt2(meanqds2);
    
    ii=t;
    % zm=168;
%     zm_all=[];
%     trans_all=[];
%     ang_all=[];
    R=[];
    invR=[];
    [zm,trans,ang] = fmmatch(meanqds2,meanqds1);
    [out,R(:,:,ii)] = find_affine_trans(meanqds2, meanqds1, [[zm zm],trans,ang]);
    zm_fin=out(1:2);
    trans_fin=out(3:4)
    ang_fin=out(5)
    
    [imout]=affine_trans(meanqds2,zm_fin,trans_fin,ang_fin);
    zm_all(ii,:)=zm_fin;
    trans_all(ii,:)=trans_fin;
    ang_all(ii,:)=ang_fin;
    joinchannels('RBG',meanqds1,imout)
end