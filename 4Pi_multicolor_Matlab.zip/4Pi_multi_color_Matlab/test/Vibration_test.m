%%
clc
% save('G:\4PISCMOS\test\Cell08_drift.mat','drift');
L=length(drift(:,3));
Drift=[];
Drift(:,1)=(drift(:,1)-drift(1,1))*128;
Drift(:,2)=(drift(:,2)-drift(1,2))*128;
Drift(:,3)=(drift(:,3)-drift(1,3))/0.0199;
Fs=200;
T=1/Fs; 
t=(0:L-1)'*T; 
NFFT=2^nextpow2(L); 
f=Fs/2*linspace(0,1,NFFT/2+1);

y1=Drift(:,1);
Y1=fft(y1,NFFT)/L;
Y1_new=2*abs(Y1(1:NFFT/2+1));
figure;subplot(3,2,1);plot(f(1:NFFT/2+1),Y1_new(1:NFFT/2+1)); hold on 
xlabel('Frequency (Hz)')
ylabel('x (nm)')
axis([0 Fs/2 0 10])

y1d=diff(y1)/T;
Y1d = fft(y1d,NFFT)/L;
Y1d_new=2*abs(Y1d(1:NFFT/2+1));
subplot(3,2,2);plot(f(1:NFFT/2+1),Y1d_new(1:NFFT/2+1)); 
xlabel('Frequency (Hz)')
ylabel('velocity (nm/s)')
axis([0 Fs/2 0 2000])

y1=Drift(:,2);
Y1=fft(y1,NFFT)/L;
Y1_new=2*abs(Y1(1:NFFT/2+1));
subplot(3,2,3);plot(f(1:NFFT/2+1),Y1_new(1:NFFT/2+1)); 
xlabel('Frequency (Hz)')
ylabel('y (nm)')
axis([0 Fs/2 0 10])

y1d=diff(y1)/T;
Y1d = fft(y1d,NFFT)/L;
Y1d_new=2*abs(Y1d(1:NFFT/2+1));
subplot(3,2,4);plot(f(1:NFFT/2+1),Y1d_new(1:NFFT/2+1)); 
xlabel('Frequency (Hz)')
ylabel('velocity (nm/s)')
axis([0 Fs/2 0 2000])

y1=Drift(:,3);
Y1=fft(y1,NFFT)/L;
Y1_new=2*abs(Y1(1:NFFT/2+1));
subplot(3,2,5);plot(f(1:NFFT/2+1),Y1_new(1:NFFT/2+1)); 
xlabel('Frequency (Hz)')
ylabel('z (nm)')
axis([0 Fs/2 0 10])

y1d=diff(y1)/T;
Y1d = fft(y1d,NFFT)/L;
Y1d_new=2*abs(Y1d(1:NFFT/2+1));
subplot(3,2,6);plot(f(1:NFFT/2+1),Y1d_new(1:NFFT/2+1)); 
xlabel('Frequency (Hz)')
ylabel('velocity (nm/s)')
axis([0 Fs/2 0 2000])

std(Drift)