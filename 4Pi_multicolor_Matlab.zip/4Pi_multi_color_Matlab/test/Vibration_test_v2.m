%%
clear
clc
str='E:\test\20190405\Cell04_642_tmpresult_20190405.mat';
str1='E:\test\20190405\Cell04_drift.mat';
str2='E:\test\20190405\Cell04_drift.jpg';
Fs=400; % frame rate
photonI=5000; % photon threshold
plotRange=1;

tmpld=load(str);
Vin=[];
Vin(:,1)=tmpld.xresult;
Vin(:,2)=tmpld.yresult;
Vin(:,3)=tmpld.tresult+1;
Vin(:,5)=tmpld.Iresult;
Vin(:,6)=tmpld.zangresult;
Vin(:,7)=tmpld.zfresult;

%%
V=Vin;
m=sum((V(:,3)==1));
n=0;
N=max(Vin(:,3))-min(Vin(:,3))+1;
for i=1:m
    id=abs(V(:,1)-V(i,1))<2 & abs(V(:,2)-V(i,2))<2;
    V1=V(id,:);
    V1(:,5)=find(id>0);    
    U=unique(V1(:,3));
    if length(U)==N                 %% exist for every frame 
        n=n+1;
        V(i,4)=n;
        V(id,4)=n;  
%         if length(V1(:,1))>length(U)%size(V1,1)>=N-3000 && size(V1,1)<=N+3000      %% more than frame number
%             % find frame contains more than one molecule
%             M=hist(V1(:,3),U);
%             FI=find(M>1);           
%             for k=1:length(FI)
%                 f=FI(k);
%                 id=V1(:,3)==U(f);
%                 Vnew=V1(id,:);
%                 id=V1(:,3)==U(f)-1;
%                 cx=mean(V1(id,1));
%                 cy=mean(V1(id,2));
%                 if isempty(cx)
%                     continue
%                 end
%                 dist=(Vnew(:,1)-cx).^2+(Vnew(:,2)-cy).^2;
%                 FI1=find(dist==min(dist));             %% keep the closest molecule
%                 for j=1:size(Vnew,1)
%                     if j~=FI1
%                         n1=Vnew(j,5);
%                         V(n1,4)=0;
%                     end
%                 end
%             end
%         end
    end
end

m=max(V(:,4));
drift=zeros(N,4);
Vout=V(:,1:2);
Vout(:,3:4)=V(:,6:7);
n=0;
for i=1:m
    IX=V(:,4)==i;
    I=V(IX,5);
    if sum(IX)==N
        Vnew=V(IX,:);
        if mean(Vnew(:,5))>photonI
            drift(:,1:2)=drift(:,1:2)+Vnew(:,1:2);
            %         drift(:,3)=drift(:,3)+Vnew(:,6)-Vnew(1,6);
            drift(:,3)=drift(:,3)+unwrap(Vnew(:,6))-Vnew(1,6);
            %         drift(:,3)=drift(:,3)+wrapToPi(Vnew(:,6)-Vnew(1,6))+2;
            drift(:,4)=drift(:,4)+Vnew(:,7);
            n=n+1;
        end
    end     
end

disp([num2str(n),' beads are used for drift correction.']);
if n>0
    drift=drift-ones(N,1)*drift(1,:);
    drift=drift/n;
    flag=1;
else
    flag=0;
end
save(str1,'drift');

%%
L=length(drift(:,3));
Drift=[];
Drift(:,1)=(drift(:,1)-drift(1,1))*128;
Drift(:,2)=(drift(:,2)-drift(1,2))*128;
Drift(:,3)=(drift(:,3)-drift(1,3))/0.0199;
T=1/Fs; 
t=(0:L-1)'*T; 
NFFT=2^nextpow2(L); 
f=Fs/2*linspace(0,1,NFFT/2+1);

y1=Drift(:,1);
Y1=fft(y1,NFFT)/L;
Y1_new=2*abs(Y1(1:NFFT/2+1));
figure('position',[300 300 1800 1200]);
subplot(3,2,1);plot(f(1:NFFT/2+1),Y1_new(1:NFFT/2+1)); hold on 
xlabel('Frequency (Hz)')
ylabel('x (nm)')
axis([0 Fs/2 0 plotRange])

y1d=diff(y1)/T;
Y1d = fft(y1d,NFFT)/L;
Y1d_new=2*abs(Y1d(1:NFFT/2+1));
subplot(3,2,2);plot(f(1:NFFT/2+1),Y1d_new(1:NFFT/2+1)); 
xlabel('Frequency (Hz)')
ylabel('velocity (nm/s)')
axis([0 Fs/2 0 plotRange*100])

y1=Drift(:,2);
Y1=fft(y1,NFFT)/L;
Y1_new=2*abs(Y1(1:NFFT/2+1));
subplot(3,2,3);plot(f(1:NFFT/2+1),Y1_new(1:NFFT/2+1)); 
xlabel('Frequency (Hz)')
ylabel('y (nm)')
axis([0 Fs/2 0 plotRange])

y1d=diff(y1)/T;
Y1d = fft(y1d,NFFT)/L;
Y1d_new=2*abs(Y1d(1:NFFT/2+1));
subplot(3,2,4);plot(f(1:NFFT/2+1),Y1d_new(1:NFFT/2+1)); 
xlabel('Frequency (Hz)')
ylabel('velocity (nm/s)')
axis([0 Fs/2 0 plotRange*100])

y1=Drift(:,3);
Y1=fft(y1,NFFT)/L;
Y1_new=2*abs(Y1(1:NFFT/2+1));
subplot(3,2,5);plot(f(1:NFFT/2+1),Y1_new(1:NFFT/2+1)); 
xlabel('Frequency (Hz)')
ylabel('z (nm)')
axis([0 Fs/2 0 plotRange])

y1d=diff(y1)/T;
Y1d = fft(y1d,NFFT)/L;
Y1d_new=2*abs(Y1d(1:NFFT/2+1));
subplot(3,2,6);plot(f(1:NFFT/2+1),Y1d_new(1:NFFT/2+1)); 
xlabel('Frequency (Hz)')
ylabel('velocity (nm/s)')
axis([0 Fs/2 0 plotRange*100])

print('-djpeg','-r300',str2);
std(Drift)