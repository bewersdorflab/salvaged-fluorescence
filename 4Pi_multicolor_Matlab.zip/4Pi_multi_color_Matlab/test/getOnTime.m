clc
path='G:\4PISCMOS\2017-1-24\';
str=strcat(path,'*tmpresult*.mat');
files=dir(str);
L=length(files);
D=[];
for kk=1:L
    kk
    filename=strcat(path,files(kk,1).name);
    load(filename);
%     P=importdata(filename);
    D(kk,1)=mean(Iresult);
    D(kk,2)=median(Iresult);
    D(kk,3)=mean(bgresult);
    D(kk,4)=D(kk,1)/D(kk,3);
    A=CRLBresult(:,1);
    A=abs(A);
    A=A(A<1);
    D(kk,5)=mean(A);
    D(kk,6)=median(A);
    D(kk,7)=mean(zangctrresult(zangctrresult<1));
    D(kk,8)=mean(zast_err_result);
    D(kk,9)=std(zfresult(zfresult>0 & zfresult<1200));
    
    mask=tresult+1<=6000;
    V=[];
    V(:,1)=xresult(mask);
    V(:,2)=yresult(mask);
    V(:,3)=tresult(mask)+1;
    V(:,6)=zangresult(mask);
    V(:,4)=0;
    V(:,5)=(1:size(V,1))';
    
    fn=max(V(:,3));
    M=size(V,1);
    ID=cell(M,1);
    
    V1=cell(fn,1);
    for i=1:fn
        id=V(:,3)==i;
        V1{i,1}=V(id,:);
    end
    
    n=0;
    dist=0.5;
    gap=1;
    for j=1:fn
        m=length(V1{j}(:,1));
        for i=1:m
            if V1{j}(i,4)==0
                n=n+1;
                V1{j}(i,4)=n;
                id=V1{j}(i,5);
                V(id,4)=n;
                ID{n}(1)=id;
                ii=2;
                k=j+1;
                stopframe=min(j+gap,fn);
                cx=V1{j}(i,1);
                cy=V1{j}(i,2);
                while k<=stopframe
                    Tx=V1{k}(:,1);
                    Ty=V1{k}(:,2);
                    Dist=sqrt((Tx-cx).^2+(Ty-cy).^2);
                    if min(Dist)<dist;
                        id=find(Dist==min(Dist));
                        if length(id)>1
                            id=id(1);
                        end
                        cx=Tx(id);
                        cy=Ty(id);
                        V1{k}(id,4)=n;
                        ix=V1{k}(id,5);
                        V(ix,4)=n;
                        for l=1:length(ix)
                            ID{n}(ii)=ix(l);
                            ii=ii+1;
                        end
                        stopframe=min(k+gap,fn);
                    end
                    k=k+1;
                end
            end
        end
    end
    
    for i=1:M
        if isempty(ID{i})
            break
        end
    end
    n=i-1;
    
    T=zeros(n,1);
    for i=1:n
        IX=ID{i};
        T(i,1)=length(IX);
    end
    
    id=T<20;
%     hist(T(id,1),20);
    D(kk,10)=mean(T(id));   
end



