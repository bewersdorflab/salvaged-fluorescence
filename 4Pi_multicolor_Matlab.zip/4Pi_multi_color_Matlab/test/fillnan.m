function Vout=fillnan(Vin)
    l=length(Vin);
    for i=1:l
        if isnan(Vin(i,1)) 
            Vin(i,:)=Vin(i-1,:);
        end
    end
    Vout=Vin;
end