clear
clc
str='F:\4Pi_two_color\2018-1-21\Cell03_642v20_60.mat';
load(str);
pixelsz=50;
x1_1=(vutarax)/pixelsz;
x2_1=(vutaray)/pixelsz;
x1sz=ceil(128*168/pixelsz);
im1=cHistRecon(x1sz,x1sz,x1_1,x2_1,0);
dipshow(im1);

%%
V=[vutarax,vutaray];
% theta=atand(t);
theta=72;
T=[cosd(theta) -sind(theta);sind(theta),cosd(theta)];
V1=V(:,1:2)*T;
V1(:,1)=V1(:,1)-mean(V1(:,1))+11000;
V1(:,2)=V1(:,2)-mean(V1(:,2))+11000;

x1_1=(V1(:,1))/pixelsz;
x2_1=(V1(:,2))/pixelsz;
x1sz=ceil(128*168/pixelsz);
im2=cHistRecon(x1sz,x1sz,x1_1,x2_1,0);
dipshow(im2);

%%
vutarax=V1(:,1);
vutaray=V1(:,2);

%%
vutaraz=vutaraz+100;
mask1=abs(vutaraz)<=500;
mask2=vutarax>=8000&vutarax<=20000;
mask3=vutaray>=9000&vutaray<=13000;

%%
id=mask1&mask2&mask3;
vutarax1=vutarax(id);
vutaray1=vutaray(id);
vutaraz1=vutaraz(id);
vutarat1=vutarat(id);
vutaraI1=vutaraI(id);
vutaracrlb1=vutaracrlb(id);
vutarall1=vutarall(id);
vutarabg1=vutarabg(id);
vutarazcon1=vutarazcon(id);
vutarazerr1=vutarazerr(id);

%%
vutarax1(end+1:end+2)=mean(vutarax1);
vutaray1(end+1)=9000;
vutaray1(end+1)=13000;
vutaraz1(end+1)=-500;
vutaraz1(end+1)=500;
vutarat1(end+1:end+2)=0;
vutaraI1(end+1:end+2)=0;
vutaracrlb1(end+1:end+2)=0;
vutarall1(end+1:end+2)=0;
vutarabg1(end+1:end+2)=0;
vutarazcon1(end+1:end+2)=0;
vutarazerr1(end+1:end+2)=0;
%%
% currentfolder='F:\4Pi_two_color\2018-1-21\';
% savename='Cell04_rotate';
% [flag]=iPALM2vutarav2(currentfolder,[savename '_ll'],1,{vutarax1},{vutaray1},{vutaraz1},{ceil(vutarat1/100)},{vutaraI1},{vutaracrlb1},{vutarall1},{vutarabg1},{vutarazcon1},{vutarazerr1});

%%
x1_1=(vutarax1)/pixelsz;
x2_1=(vutaray1)/pixelsz;
x1sz=ceil(128*168/pixelsz);
im3=cHistRecon(x1sz,x1sz,x1_1,x2_1,0);
dipshow(im3);
