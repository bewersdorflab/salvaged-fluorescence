function [trans1,trans2,fitness] = GetTransM(x1,x2)
    trans1 = [1 0
            0 1];
    trans2=[0 0];
    
    
    step = 0.001;
    grid = 0.05;
    maxround = 6000;
    fitness = zeros(1,maxround);
    
    for round = 1:maxround
        for m=1:2
            for n=1:2
                tx=GetPointSet(x1,trans1,trans2);
                fit0 = GetPointFit(tx,x2);
                ttrans1=trans1;
                ttrans1(m,n)=ttrans1(m,n)+step;
                tx=GetPointSet(x1,ttrans1,trans2);
                fit1 = GetPointFit(tx,x2);
                dfit = fit0-fit1;
                trans1(m,n)=trans1(m,n)+dfit*grid;
            end
        end
        for n=1:2
            tx=GetPointSet(x1,trans1,trans2);
            fit0 = GetPointFit(tx,x2);
            ttrans2=trans2;
            ttrans2(n)=ttrans2(n)+step;
            tx=GetPointSet(x1,trans1,ttrans2);
            fit1 = GetPointFit(tx,x2);
            dfit = fit0-fit1;
            trans2(n)=trans2(n)+dfit*grid;
        end
        
        tx=GetPointSet(x1,trans1,trans2);
        fit0 = GetPointFit(tx,x2);
        %disp(['round ' num2str(round) ' ,fitness = ' num2str(fit0)]);
        fitness(round)=fit0;
        
    end
end

function result = GetPointSet(x,tr1,tr2)
    result = x*tr1;
    result(:,1)=result(:,1)+tr2(1);
    result(:,2)=result(:,2)+tr2(2);
end

function result = GetPointFit(x1,x2)
    s=size(x1);
    r=zeros(1,s(1));
    for i=1:s(1)
        t=(x2(:,1)-x1(i,1)).^2+(x2(:,2)-x1(i,2)).^2;
        r(i)=min(t);
    end
    
    result = sum(r);
end