clear
clc
addpath('calibration_files\');
addpath('scmos_based_codes\');

main_folder='G:\4PISCMOS\2016-8-23\';

% foldername1=main_folder;
% tmpf=dir([foldername1 '\*Ast*.mat']);
% if numel(tmpf)>1
%     error('More than one calibration file detected!');
% end
% astfile=tmpf.name;
% tmpf=dir([foldername1 '\*dphi*.mat']);
% if numel(tmpf)>1
%     error('More than one calibration file detected!');
% end
% anglefile=tmpf.name;
% tmpf=dir([foldername1 '\*FMTtransform*.mat']);
% if numel(tmpf)>1
%     error('More than one calibration file detected!');
% end
% fmfile=tmpf.name;
fmfile='align1_642_Jan8th_2016FMTtransform010816.mat';
% fmfile='align1_561_Oct28th_2015FMTtransform102815.mat';

scmos_cali_file='readout1_tmpcalibration.mat';
tmpld=load(scmos_cali_file);
offsetim=tmpld.offsetim; 
varim=tmpld.varim;
gainim=tmpld.g3;    
caliims=cat(3,offsetim,varim,gainim);

folders=subdir(main_folder);
n=0;
V=[];
for i=3:4%1:size(folders,2);
    current_folder=[folders{i},'\'];
    files=dir([current_folder,'\*.dcimg']);
    I=[];
    n=n+1;
    V0=[];
    for j=1:numel(files)
        filename=files(j).name;
        centers=[235 495 1536 1797];
        display(['Reading dcimg files...']);
        [~,qds,calicrops]=iPALM_readdcimg([current_folder,filename],centers,caliims);
        tmpim=calicrops(:,:,3,:);
        tmpim(tmpim<1.3|tmpim>3.5)=mean(mean(mean(calicrops(:,:,3,:))));
        calicrops(:,:,3,:)=tmpim;
        offsetim=squeeze(calicrops(:,:,1,:));
        varim=squeeze(calicrops(:,:,2,:));
        gainim=squeeze(calicrops(:,:,3,:));
        stacknum=getstepnum(filename);
        qd1=(qds(:,:,:,1)-repmat(offsetim(:,:,1),[1 1 size(qds,3) 1]))./repmat(gainim(:,:,1),[1 1 size(qds,3) 1]);
        qd2=(qds(:,:,:,2)-repmat(offsetim(:,:,2),[1 1 size(qds,3) 1]))./repmat(gainim(:,:,2),[1 1 size(qds,3) 1]);
        qd3=(qds(:,:,:,3)-repmat(offsetim(:,:,3),[1 1 size(qds,3) 1]))./repmat(gainim(:,:,3),[1 1 size(qds,3) 1]);
        qd4=(qds(:,:,:,4)-repmat(offsetim(:,:,4),[1 1 size(qds,3) 1]))./repmat(gainim(:,:,4),[1 1 size(qds,3) 1]);
        num_images=size(qds,3);
%         clear mex
        %
        %% rotate and align
%         [q1 q2 q3 q4]=iPALMast_RotAlign_FMT(qd1,qd2,qd3,qd4,fmfile);
%         [v1 v2 v3 v4]=iPALMast_RotAlign_FMT(varim(:,:,1),varim(:,:,2),varim(:,:,3),varim(:,:,4),fmfile);
%         [g1 g2 g3 g4]=iPALMast_RotAlign_FMT(gainim(:,:,1),gainim(:,:,2),gainim(:,:,3),gainim(:,:,4),fmfile);
%         maskg=g1<=1|g2<=1|g3<=1|g4<=1;
%         v1(maskg)=1e7;
%         v2(maskg)=1e7;
%         v3(maskg)=1e7;
%         v4(maskg)=1e7;
%         
%         g1(maskg)=1e-7;
%         g2(maskg)=1e-7;
%         g3(maskg)=1e-7;
%         g4(maskg)=1e-7;
%         sumim1=q1+q2+q3+q4;
%         I(:,:,j)=sumim1;
%         I1(:,:,j)=q1;
%         I2(:,:,j)=q2;
%         I3(:,:,j)=q3;
%         I4(:,:,j)=q4;
%         I=sumim1;
        q1=mean(qd1,3);
        q2=mean(qd2,3);
        q3=mean(qd3,3);
        q4=mean(qd4,3);
        I(:,:,1)=q1;
        I(:,:,2)=q2;
        I(:,:,3)=q3;
        I(:,:,4)=q4;
%         I1=q1;
%         I2=q2;
%         I3=q3;
%         I4=q4;          
    end
    filestr=[main_folder filename(1:end-6) '.tif'];
    tiffwrite(I,filestr);
%     filestr=[main_folder filename(1:end-6) '.tif'];
%     tiffwrite(I,filestr);
%     filestr=[main_folder filename(1:end-6) '_q1' '.tif'];
%     tiffwrite(I1,filestr);
%     filestr=[main_folder filename(1:end-6) '_q2' '.tif'];
%     tiffwrite(I2,filestr);
%     filestr=[main_folder filename(1:end-6) '_q3' '.tif'];
%     tiffwrite(I3,filestr);
%     filestr=[main_folder filename(1:end-6) '_q4' '.tif'];
%     tiffwrite(I4,filestr);

    det_thresh = 13;
    mean_v = varim./size(qd1,3);
%     mean_vg = gainim;
    mean_vg = mean_v./gainim./gainim;
    pick_flag=1; % use range
    pick_sz= 20;
%     [sub_regions tlz locmaxc subvar_g]=iPALMast_sumim_seg(sumim1,det_thresh,subsz,sumv,sumvg,pick_flag,pick_sz);
    [sub_regions tlz locmaxc subvar_g]=iPALMast_sumim_seg(I,det_thresh,11,mean_v(:,:,1),mean_vg,1);
    [P1 CRLB1 LL1]=sCMOS_MLE_DB_YL_CUDA42(single(sub_regions(:,:,:)),1.4,200,7,single(subvar_g(:,:,:)),single(subvar_g(:,:,:).*0+1));
    xf=P1(:,2);
    yf=P1(:,1);
    xest=xf+tlz(:,2);
    yest=yf+tlz(:,1);
    V0(:,1)=xest;
    V0(:,2)=yest;
    V0(:,3)=tlz(:,3)+1+(n-1)*4;
    V=cat(1,V,V0);
end

for i=1:4
    id=V(:,3)==i;
    x1=V(id,1:2);
    id=V(:,3)==i+4;
    x2=V(id,1:2);
%     id=abs(x1(:,1)-128)<64 & abs(x1(:,2)-128)<64;
%     x1=x1(id,:);
%     id=abs(x2(:,1)-128)<64 & abs(x2(:,2)-128)<64;
%     x2=x2(id,:);
    [rx1 rx2 result flag] = GetPointsReg(x1,x2);
%     [rx1 rx2 result flag] = GetPointsReg(rx1,rx2);
    er=(rx1-rx2)*128;
    id=abs(er(:,1)-median(er(:,1)))<40 & abs(er(:,2)-median(er(:,2)))<40;
    er=er(id,:);
    E(i,1)=median(er(:,1));
    E(i,2)=median(er(:,2));
    E(i,3)=std(er(:,1));
    E(i,4)=std(er(:,2));
%     r2=[result(5) result(6)]*256*128;
%     E1(i,:)=r2;    
end

r1 = [result(1) result(2)
    result(3) result(4)];
r2 = [result(5) result(6)];
 
x3 = x1*r1;
x3(:,1)=x3(:,1)+r2(1)*256;
x3(:,2)=x3(:,2)+r2(2)*256;

figure;
hold on
plot(x1(:,1),x1(:,2),'b.');
plot(x2(:,1),x2(:,2),'g.');
plot(x3(:,1),x3(:,2),'go');