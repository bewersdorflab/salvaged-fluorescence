function [zangresult,mtcresult]=PhaseShift(zangresult,mtcresult,tresult,fnum)

E=[];
N=ceil(max(tresult)/fnum);
for i=1:N
    id=tresult<fnum*i&tresult>=(i-1)*fnum;
%     E(i,1)=median(zangresult(id));
    E(i,1)=(median(mtcresult(id))+mean(mtcresult(id)))/2;
end

for i=1:N
    id=tresult<fnum*i&tresult>=(i-1)*fnum;
%     zangresult(id)=zangresult(id)-E(i,2)*0;
%     zangresult(id)=wrapToPi(zangresult(id));
    mtcresult(id)=mtcresult(id)-E(i,1);
end
