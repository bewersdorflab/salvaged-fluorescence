%%
clc
P=PT(vutarapr,:);
R=RT(vutarapr,:);
mask=vutarall<300 & vutarazerr<60 & P(:,2)>0 & P(:,3)>0;% & vutarax>4000 & vutarax<16000 & vutaray>2000 & vutaray<14000;% & vutaraz>-300 & vutaraz<200;% & vutarat>3000; 
% mask=P(:,2)>0;
P=P(mask,:);
R=R(mask,:);
% mask=ones(length(vutarax),1)>0;
xout=vutarax(mask);
yout=vutaray(mask);
zout=vutaraz(mask);
currt=vutarat(mask); 
currI=vutaraI(mask);
currcrlb=vutaracrlb(mask);
currll=vutarall(mask);
currbg=vutarabg(mask);
currzcon=vutarazcon(mask);
currzerr=vutarazerr(mask);

%%
id=currt<3000;
x=xout(id);
y=yout(id);
z=zout(id);
t=currt(id);

%%
xx=[];
yy=[];
zz=[];
tt=[];
for i=1:10
    x1=x+i*10;
    y1=y;
    z1=z+i*5;
    t1=t+(i-1)*3000;
    xx=cat(1,xx,x1);
    yy=cat(1,yy,y1);
    zz=cat(1,zz,z1);
    tt=cat(1,tt,t1);
end

%%
% id=currt>=3000 & currt<6000;
% x2=xout(id);
% y2=yout(id);
% z2=zout(id);
% t2=t+3000*9;

% x2=rand(25550,1)*20000;
% y2=rand(25550,1)*20000;
% z2=rand(25550,1)*500;
% t2=t+3000*9;
% 
% xx=cat(1,xx,x2);
% yy=cat(1,yy,y2);
% zz=cat(1,zz,z2);
% tt=cat(1,tt,t2);

%%
p.correctxy=true;
p.drift_timepoints=10;
p.correctz=true;
p.drift_timepointsz=10;
p.zrange=[-500 500];
p.framestart=0;
p.framestop=ceil((max(tt)/3000))*3000-1;
[drift,driftinfo,fieldc]=driftcorrection3D_so(xx,yy,zz,tt,p);

%%
[xout1,yout1,zout1,shifts1]=iPALM_driftcorrection_RedunLSv8(xx,yy,zz,tt,3000,0,1,0);