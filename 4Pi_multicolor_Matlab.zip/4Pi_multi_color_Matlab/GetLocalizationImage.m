function [out1,out2]=GetLocalizationImage(im1,im2)
    sz=size(im1,1);
    mean_v=ones(sz,sz);
    mean_vg=ones(sz,sz);
        
%     parameter.wavelet_threshold = 5;
%     parameter.wavelet_coefficient = 3;
%     parameter.weightedcentrid = 0;
%     parameter.width = 5;
% 
%     data_w=Detection(im1,parameter);
%     V1=FindParticles(data_w,parameter);
%     figure;imshow(im1,[]);hold on;plot(V1(:,1),V1(:,2),'bo');
    
    I=repmat(im1,1,1,10);
    V1=[];
    [sub_regions tlz locmaxc subvar_g]=iPALMast_sumim_seg(I,20,7,mean_v,mean_vg,0,1);
    [P1 CRLB1 LL1]=sCMOS_MLE_DB_YL_CUDA42(single(sub_regions(:,:,:)),1.4,200,2,single(subvar_g(:,:,:)),single(subvar_g(:,:,:).*0+1));
    xf=P1(:,2);
    yf=P1(:,1);
    xest=xf+tlz(:,2);
    yest=yf+tlz(:,1);
    L=length(xf);
    V1(:,1)=xest(1:round(L/10))+1;
    V1(:,2)=yest(1:round(L/10))+1;
    
    figure;imshow(im1,[]);hold on;plot(V1(:,1),V1(:,2),'bo');
    
    I=repmat(im2,1,1,10);
    V2=[];
    [sub_regions tlz locmaxc subvar_g]=iPALMast_sumim_seg(I,20,7,mean_v,mean_vg,0,1);
    [P1 CRLB1 LL1]=sCMOS_MLE_DB_YL_CUDA42(single(sub_regions(:,:,:)),1.4,200,2,single(subvar_g(:,:,:)),single(subvar_g(:,:,:).*0+1));
    xf=P1(:,2);
    yf=P1(:,1);
    xest=xf+tlz(:,2);
    yest=yf+tlz(:,1);
    L=length(xf);
    V2(:,1)=xest(1:round(L/10))+1;
    V2(:,2)=yest(1:round(L/10))+1;
    
    figure;imshow(im2,[]);hold on;plot(V2(:,1),V2(:,2),'bo');
    
    x1=[V1(:,1),V1(:,2)];
    x2=[V2(:,1),V2(:,2)];
    [rcx1 rcx2 result flag] = GetPointsReg(x1,x2);
%     figure;plot(x1(:,1),x1(:,2),'bo');hold on;plot(x2(:,1),x2(:,2),'go');
%     figure;plot(rcx1(:,1),rcx1(:,2),'bo');hold on;plot(rcx2(:,1),rcx2(:,2),'go');
    D=sqrt((rcx1(:,1)-rcx2(:,1)).^2+(rcx1(:,2)-rcx2(:,2)).^2);
    id1=D<5;
    
    rx1=rcx1(id1,:);
    rx2=rcx2(id1,:);
        
    x1=rx1;
    x2=rx2;
    [betax,betay]=biplaneReg_linear(x2(:,1),x2(:,2),x1(:,1),x1(:,2));
    
    x3=[];
    XX=[ones(size(x1(:,1))),x1(:,1),x1(:,2),x1(:,1).*x1(:,2),x1(:,1).^2,x1(:,2).^2];
    x3(:,1)=XX*betax;
    x3(:,2)=XX*betay;
    
    Ex=x2(:,1)-x3(:,1);
    Ey=x2(:,2)-x3(:,2);  
    id2=abs(Ex)<2 & abs(Ey)<2;
    
%     figure;
%     hold on
%     plot(x2(id2,1),x2(id2,2),'r.');
%     plot(x3(id2,1),x3(id2,2),'go');
%     axis([0 sz 0 sz]);
%     axis equal

    V1new=x1(id2,:);
    V2new=x2(id2,:);
    
%     V1new=V1(id1,:);
%     V2new=V2(id1,:);
%     V1new=V1new(id2,:);
%     V2new=V2new(id2,:);
    id3=V1new(:,1)>7 & V1new(:,1)<161 & V1new(:,2)>7 & V1new(:,2)<161 & V2new(:,1)>7 & V2new(:,1)<161 & V2new(:,2)>7 & V2new(:,2)<161;
    V1new=V1new(id3,:);
    V2new=V2new(id3,:);
    
%     figure;plot(V1new(:,1),V1new(:,2),'bo');hold on;plot(V2new(:,1),V2new(:,2),'ro');
    
    im0=cHistRecon(sz,sz,single(V1new(:,2)),single(V1new(:,1)),0);
    out1=gaussf(im0,[1 1])*10000+100;
    im0=cHistRecon(sz,sz,single(V2new(:,2)),single(V2new(:,1)),0);
    out2=gaussf(im0,[1 1])*10000+100;
end