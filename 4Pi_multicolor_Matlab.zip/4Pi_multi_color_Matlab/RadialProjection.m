close all;

%%%%%%%%%%Fig 2%%%%%%%%%%%%%%%%%%%%%
% ttitle = 'catsper1 wt uncap';
% dirname = 'G:\Data\sperm\20120220.CatSper1,Src,pY416-Src\2.CatSper wt uncap (#1)';
% filename = 'STORM_0006_prox5um.txt';
% ttitle = 'catsper-delta wt uncap';
% dirname = 'G:\Data\sperm\20120424.Cav1KO,PP1,CatSperDelta\8.wt CatSperDelta uncap (#7)';
% filename = 'STORM_0003_prox5um.txt';
%%%%%%%%%%Fig 1%%%%%%%%%%%%%%%%%%%%%
% ttitle = 'glut3 wt uncap';
% dirname = 'F:\Data\Sperm\20120601.AKAP4,GLUT3,P-PP1-Fab-SA\2.GLUT3(500x) wt uncap';
% filename = 'STORM_0004_prox5um.txt';
ttitle = 'PMCA4 wt uncap';
dirname = 'H:\Data\Sperm\20130308.spermatogenesis KO\4.PMCA4 wt uncap';
filename = 'STORM_0008_prox5um.txt';
%%%%%%%%%%Fig 4%%%%%%%%%%%%%%%%%%%%%
% ttitle = 'P-CaMKII wt uncap';
% dirname = 'D:\Sang-Hee\Data\20121028.pCaMKII 1KO uncap\4.wt uncap 25x';
% filename = 'STORM_0001_prox5um.txt';
% ttitle = 'cav1 wt uncap';
% dirname = 'G:\Data\sperm\20110927.hCatSperBeta,Cav(wt KO cap uncap)\2.wt uncap Cav1 (#1)';
% filename = 'STORM_0003_prox5um.txt';
% ttitle = 'PP2B-Agamma wt uncap';
% dirname = 'F:\Data\Sperm\20120804.PP2B-Agamma\1.PP2B-Agamma wt uncap (8-3#4-1)';
% filename = 'STORM_0002_prox5um.txt';
% ttitle = 'CaM wt uncap';
% dirname = 'F:\Data\Sperm\20120626.CaM,calcineuin,PP\2.CaM(Upstate) wt uncap (#2-1)';
% filename = 'STORM_0003_prox5um.txt';
%%%%%%%%%%Fig 6%%%%%%%%%%%%%%%%%%%%%
% ttitle = 'catsper1 cav1KO uncap';
% dirname = 'G:\Data\sperm\20120424.Cav1KO,PP1,CatSperDelta\2.Cav1KO CatSper1 uncap';
% filename = 'STORM_0002_prox5um.txt';
% ttitle = 'cav1 CatSper1KO uncap';
% dirname = 'G:\Data\sperm\20110927.hCatSperBeta,Cav(wt KO cap uncap)\3.1KO uncap Cav1 (#1-1)';
% filename = 'STORM_0002_prox5um.txt';
% ttitle = 'P-CaMKII CatSper1KO uncap';
% dirname = 'G:\Data\sperm\20111119.CaMKII,CaM,Src,PP1,GLUT3+pY,tub+pY\3.CaMKII 1KO uncap (#1)';
% filename = 'STORM_0006_prox5um.txt';
% ttitle = 'PP2B-Agamma CatSper1KO uncap';
% dirname = 'F:\Data\Sperm\20120804.PP2B-Agamma\3.PP2B-Agamma 1KO uncap (8-3#4-3)';
% filename = 'STORM_0007_prox5um.txt';
% ttitle = 'CaM CatSper1KO uncap';
% dirname = 'F:\Data\Sperm\20120629.CaM,calcineurin,tubulin\6.CaM 1KO uncap (6-26#2-3)';
% filename = 'STORM_0002_prox5um.txt';
%%%%%%%%%%Fig 5%%%%%%%%%%%%%%%%%%%%%
% ttitle = 'PP2B-Agamma wt cap';
% dirname = 'F:\Data\Sperm\20120804.PP2B-Agamma\2.PP2B-Agamma wt cap (8-3#4-2)';
% filename = 'STORM_0003_prox5um.txt';    %cell #1 in fig
% filename = 'STORM_0006_prox5um.txt';    %cell #2 in fig
% filename = 'STORM_0008_prox5um.txt';    %cell #3 in fig
% filename = 'STORM_0008_prox5um.txt';    %cell #3 in fig
% ttitle = 'Cav1 wt cap';
% dirname = 'G:\Data\sperm\20110927.hCatSperBeta,Cav(wt KO cap uncap)\5.wt cap Cav1 (#1-2)';
% filename = 'STORM_0002_prox5um.txt';    %cell #1 in fig
% filename = 'STORM_0003_prox5um.txt';    %cell #2 in fig
% filename = 'STORM_0004_prox5um.txt';    %cell #3 in fig
% ttitle = 'P-CaMKII wt cap 1';
% dirname = 'G:\Data\sperm\20111113.CaMK,acet-tubulin,pY+tubulin\3.CaMKII wt cap (#1-2)';
% filename = 'STORM_0005_prox5um.txt';    %cell #1 in fig
% filename = 'STORM_0010_prox5um.txt';    %cell #2 in fig
% filename = 'STORM_0008_prox5um1.txt';    %cell #3 in fig
% filename = 'StatCap\STORM_0010_prox5um2.txt';    %Statistics
% ttitle = 'CatSper1 wt cap';
% dirname = 'G:\Data\sperm\20120213.Lck,Src,Lyn,CatSper1,CA4\7.CatSper wt cap (#3-1)';
% filename = 'STORM_0005_prox5um.txt';    %cell #1 in fig
% filename = 'STORM_0004_prox5um.txt';    %cell #2 in fig
% filename = 'STORM_0003_prox5um1.txt';    %cell #3 in fig
% filename = 'Prox5umForStatistics\STORM_0005_prox5um2.txt';    %Statistics
% ttitle = 'CatSperDelta wt cap';
% dirname = 'G:\Data\sperm\20120424.Cav1KO,PP1,CatSperDelta\9.wt CatSperDelta cap (#7-1)';
% filename = 'STORM_0003_prox5um4.txt';    %cell #1 in fig
% filename = 'STORM_0002_prox5um1.txt';    %cell #2 in fig
% filename = 'STORM_0002_prox5um2.txt';    %cell #2 in fig
%%%%%%%% Fig X. pY time series %%%%%%%%%%%%
% dirname = 'H:\Data\Sperm\20121116.pY KO time series\1.pY 1Ko 5 min';
% filename = 'STORM_0003_prox5um.txt';
% dirname = 'H:\Data\Sperm\20121116.pY KO time series\2.pY 1Ko 15 min';
% filename = 'STORM_0005_prox5um.txt';
% dirname = 'H:\Data\Sperm\20121116.pY KO time series\3.pY 1Ko 30 min';
% filename = 'STORM_0004_prox5um.txt';
% dirname = 'H:\Data\Sperm\20121116.pY KO time series\4.pY 1Ko 60 min';
% filename = 'STORM_0004_prox5um.txt';
% dirname = 'H:\Data\Sperm\20121120.pY wt, +PP2B\4.pY wt 4hr';
% filename = 'STORM_0006_prox5um.txt';
%%%%%%%% Fig X. pY-CaM %%%%%%%%%%%%%%%%%%%%
% dirname = 'H:\Data\Sperm\20121205.SP17,pY-CaM,pJAK OLD\5.pY-CaM wt cap';
% filename = 'STORM_0004_prox5um.txt';
% dirname = 'H:\Data\Sperm\20121205.SP17,pY-CaM,pJAK OLD\6.pY-CaM 1KO cap';
% filename = 'STORM_0005_prox5um.txt';
% ttitle = 'pY-CaM wt cap';
%%%%%%%% HYPERACTIVE %%%%%%%%%%%%%%%%%%%%
% dirname = 'C:\Documents and Settings\Sang-Hee\My Documents\Dropbox\CatSper (1)\Most updated figures\Illustrator files\CatSper Ca2+ domain and pY\D07\D07 materials\Hyperactivation-correlative STORM images\03112013,grid4P';
% % filename = 'STORM_0003_prox5um1.txt';
% filename = 'STORM_0004_prox5um.txt';
% ttitle = 'CatSper1 hyperactivated';

%% read .csv file
% foldername='F:\4Pi_two_color\Jean-Ju\Cell04_rotate_ll-1-1-1\';
% num=xlsread([ foldername 'particles.csv']);
% vutarax1=num(:,16);
% vutaray1=num(:,17);
% vutaraz1=num(:,18);
% load('F:\4Pi_two_color\Jean-Ju\Efcab9_Cell04.mat');
load('F:\4Pi_two_color\Jean-Ju\WT_Cell08.mat');
vutarax1=x;
vutaray1=y;
vutaraz1=z;

%%
fitcenter = 1;
rotang = (0)/180*pi;  %deg
shiftadd = 0;
pixelsize = 167;
dx = 100; %nm
maxx = 8000;

x = 19500-vutarax1;
y = vutaray1;
z = vutaraz1;
mask = x<maxx & x>0;
x = x(mask);
y = y(mask);
z = z(mask);

% mol = readmoltxt(fullfile(dirname,filename));
% x = mol.xc*pixelsize;
% y = mol.yc*pixelsize;
% z = mol.zc;

Nmol = size(x,1);
phi = zeros(Nmol,1);
rho = ones(Nmol,1)*1000;

x = x-min(x);
y = y-mean(y);
z = z-mean(z);

pxy = polyfit(x,y,1);
pxz = polyfit(x,z,1);
x0 = 0:dx:maxx;
if (fitcenter)
    y0 = polyval(pxy,x0)+0;
    z0 = polyval(pxz,x0)+0;
else
    N = size(x0);
    y0 = zeros(N);
    z0 = zeros(N);
end

% figure(1)
% scatter(x,y,2);
% hold on;plot(x0,y0,'r');hold off;
% daspect([1 1 1]);
% 
% figure(2)
% scatter(x,z,2);
% hold on;plot(x0,z0,'r');hold off;
% daspect([1 1 1]);

for n = 1:floor(maxx/dx)
    ind = find(x>=x0(n) & x<x0(n+1));
    yy = y(ind)-y0(n);
    zz = z(ind)-z0(n);
    if (rotang>0)
        yyy = yy*cos(rotang)+zz*sin(rotang);
        zzz = -yy*sin(rotang)+zz*cos(rotang);
        yy = yyy;
        zz = zzz;
    else
        
    end
    [M,N]= size(ind);
    
    pp = atand(zz./yy);
    ind1 = find(yy<0 & zz>=0);
    pp(ind1) = pp(ind1)+180;
    ind1 = find(yy<0 & zz<0);
    pp(ind1) = pp(ind1)-180;
    
    phi(ind) = pp;
    rho(ind) = sqrt(yy.^2+zz.^2);
end

indsur = find(rho>200 & rho<600 & x<=maxx);
% indsur = indsur(1:1319);

xs = x(indsur);
phis = phi(indsur);

phis = phis-110;
ind1 = find(phis>180);
phis(ind1) = phis(ind1)-360;
ind1 = find(phis<-180);
phis(ind1) = phis(ind1)+360;

meanphi = mean(phis)-shiftadd*5;
meanphi = -15;
phiss = phis-meanphi;
if (meanphi>0)
    ind1 = find(phiss<-180);
    phiss(ind1) = phiss(ind1)+360;
else
    ind1 = find(phiss>180);
    phiss(ind1) = phiss(ind1)-360;
end

% phiss = phiss+15;
% ind1 = find(phiss<-180);
% phiss(ind1) = phiss(ind1)+360;
% ind1 = find(phiss>180);
% phiss(ind1) = phiss(ind1)-360;
% phis = phiss+meanphi;

pbin = -180:6:180;
pn = hist(phis,pbin);
pns = circshift(pn,[1 -floor(meanphi/5)])/sum(pn)*100;

figure(31)
subplot(1,3,[1 2]);
% scatter(xs/1000,phiss,2);
plot(xs/1000,phiss,'.');
axis([0 maxx/1000 -180 180]);
xlabel('Distance from annulus (um)');
ylabel('Angle');
set(gca,'XTick',0:10);
set(gca,'YTick',-180:60:180);
% title(sprintf('%s',ttitle));

% figure(32)
subplot(1,3,3);
barh(pbin,pns,'hist');
axis([0 8 -180 180]);
set(gca,'YTick',-180:60:180);
set(gca,'YAxisLocation','right');
xlabel('Fraction %');
% ylabel('angle (degree)')

% figure(32)
% plot(pbin,pns);
% axis([-180 180 0 8]);
% set(gca,'XTick',-180:60:180);
% xlabel('Angle (degree)')
% ylabel('Fraction (%)');


% figure(4)
% plot(pbin,pn,'k');
% plot(pbin,pns,'r');
% xlabel('angle (deg)');
% ylabel('%');
% title(sprintf('%s',ttitle));
% axis([-180 180 0 8]);
% set(gca,'XTick',-180:60:180);

ind = find(x<=500);

rbin = 0:20:800;
rn = hist(rho(ind),rbin);
% rnn = rn/sum(rn)*100;
rnn = rn/max(rn)*100;

% figure(4)
% bar(rbin,rnn,'hist');
% title(sprintf('%s',ttitle));
% axis([0 600 0 16]);
% xlabel('r (nm)');
% ylabel('%');

% figure(5)
% plot(rbin,rnn);
% title(sprintf('%s',ttitle));
% axis([0 600 0 120]);
% xlabel('r (nm)');
% ylabel('count');
