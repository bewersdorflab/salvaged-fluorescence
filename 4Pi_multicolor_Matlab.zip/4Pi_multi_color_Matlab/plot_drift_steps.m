N=size(shifts,2);
Z=[];
X=[];
Y=[];
for i=1:N
    Z(:,i)=shifts{1,i}(:,3);
    X(:,i)=shifts{1,i}(:,1);
    Y(:,i)=shifts{1,i}(:,2);
end
figure;hold on;
subplot(1,3,1);plot(X);
subplot(1,3,2);plot(Y);
subplot(1,3,3);plot(Z);