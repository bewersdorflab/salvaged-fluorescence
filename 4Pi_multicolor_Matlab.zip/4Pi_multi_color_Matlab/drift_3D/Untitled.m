%%
clc
x=V(:,1);
y=V(:,2);
z=V(:,3);
frame=V(:,4);
p.drift_timepointsz=20;
p.zrange=[-100 100];
drift=driftcorrection3D_so(x,y,z,frame,p);  

%%
% pos.xnm=x;
% pos.ynm=y;
% pos.znm=z;
% pos.frame=frame;
% poso=applydriftcorrection(drift,pos);
% 
% %%
% N=length(x);
% vutarax=[];
% vutaray=[];
% vutaraz=[];
% vutarat=[];
% vutaraI=[];
% vutaracrlb=[];
% vutarall=[];
% vutarabg=[];
% vutarazcon=[];
% vutarazerr=[];
% vutarax{1}=x;
% vutarax{2}=poso.xnm;
% vutaray{1}=y;
% vutaray{2}=poso.ynm;
% vutaraz{1}=z;
% vutaraz{2}=poso.znm;
% vutarat{1}=frame;
% vutarat{2}=frame;
% vutaraI{1}=ones(N,1);
% vutaraI{2}=ones(N,1);
% vutaracrlb{1}=ones(N,1);
% vutaracrlb{2}=ones(N,1);
% vutarall{1}=ones(N,1);
% vutarall{2}=ones(N,1);
% vutarabg{1}=ones(N,1);
% vutarabg{2}=ones(N,1);
% vutarazcon{1}=ones(N,1);
% vutarazcon{2}=ones(N,1);
% vutarazerr{1}=ones(N,1);
% vutarazerr{2}=ones(N,1);
% 
% currentfolder='C:\Users\yz558\Desktop\drift_3D\';
% savename='Cell03_1';
% [flag]=iPALM2vutarav2(currentfolder,[savename '_ll'],2,vutarax,vutaray,vutaraz,vutarat,vutaraI,vutaracrlb,vutarall,vutarabg,vutarazcon,vutarazerr);
