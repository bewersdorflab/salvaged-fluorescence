% for v14 iPALMast_analysisv14scmos.m

function [zout2,shifts]=iPALM_driftcorrection_RedunLSv9(xout,zout,tout,frmnum,reverseflag)
%% drift correction
% frmnum=3000;

cutmeth='nocut';
pixelsz=16; % nm
thresh=8; % nm

[shiftx,shiftz]=correct_drift_LS(single(xout),single(zout),tout,frmnum,pixelsz,thresh,cutmeth);
[zout2]=shiftcoords_LS(zout,shiftz,tout,frmnum,reverseflag);

shifts=shiftz;
