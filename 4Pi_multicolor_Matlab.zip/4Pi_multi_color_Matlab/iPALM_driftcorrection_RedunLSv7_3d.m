% for v14 iPALMast_analysisv14scmos.m

function [xout3 yout3 zout2 shifts]=iPALM_driftcorrection_RedunLSv7_3d(xout,yout,zout,tout,frmnum,reverseflag)
%% drift correction
% frmnum=3000;

cutmeth='nocut';
pixelsz=25; % nm
thresh=10; % nm
[shiftx,shifty,R_shift3,flag,error1_final,error2_final,error3_final]=iPALM_driftcorrection_RedunLS3D(xout,yout,zout,pixelsz,thresh,cutmeth,frmnum,tout);

pixelsz=16; % nm
thresh=8; % nm
% % save(['D:\debug_temp\looptmp_out.mat']);
[xout2]=shiftcoords_LS(xout,shiftx,tout,frmnum,reverseflag);
[yout2]=shiftcoords_LS(yout,shifty,tout,frmnum,reverseflag);
[zout2]=shiftcoords_LS(zout,R_shift3,tout,frmnum,reverseflag);

[shiftx_d,shifty_d]=correct_drift_LS(single(xout2),single(yout2),tout,frmnum,pixelsz,thresh,cutmeth);
% [shiftx2 shiftz]=correct_drift_LS(single(xout),single(zout),tout,frmnum,pixelsz,thresh,cutmeth);
% [shifty2 shiftz]=correct_drift_LS(single(yout),single(zout),tout,frmnum,pixelsz,thresh,cutmeth);
% save(['D:\debug_temp\looptmp_out2.mat']);
[xout3]=shiftcoords_LS(xout2,shiftx_d,tout,frmnum,reverseflag);
[yout3]=shiftcoords_LS(yout2,shifty_d,tout,frmnum,reverseflag);

% save drftcorrresult xout2 yout2 zout2 R_shift1 R_shift2 R_shift3
shifts=[shiftx(:)+shiftx_d(:),shifty(:)+shifty_d(:),R_shift3(:)];