N=length(xresult);
frame=max(tresult);
D=zeros(frame,3);
V(:,1)=xresult;
V(:,2)=yresult;
V(:,3)=zangresult;
V(:,4)=tresult;
V(:,5)=0;
for i=1:frame
    i
    id1=V(:,4)==i-1;
    id2=V(:,4)==i;
    if sum(id1)==0 || sum(id2)==0
        continue
    end
    V1=V(id1,:);
    V2=V(id2,:);
    d=[];
    m=1;
    for j=1:length(V1(:,1))
        dist1=V2(:,1)-V(j,1);
        dist2=V2(:,2)-V(j,2);
        dist3=V2(:,3)-V(j,3);
        ix=abs(dist1)<0.3 & abs(dist2)<0.3;
        if sum(ix)==1
            [a,b]=find(ix>0);
            V1(j,5)=a;
            d(m,1)=dist1(ix);
            d(m,2)=dist2(ix);
            d(m,3)=dist3(ix);
            m=m+1;
        end
    end
    if ~isempty(d)
        D(i,1)=mean(d(:,1));
        D(i,2)=mean(d(:,2));
        D(i,3)=mean(d(:,3));
    end
end