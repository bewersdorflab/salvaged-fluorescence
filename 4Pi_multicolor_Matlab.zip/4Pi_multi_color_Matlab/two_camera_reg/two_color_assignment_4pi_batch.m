%%
clear
clc
currentfolder='E:\4Pi_two_color\2018-6-14\';
ID=[2,3,4];
for tt=1:length(ID)
    tt
    close all
    str=strcat(currentfolder,['Cell',num2str(ID(tt),'%02d'),'_642v20_60.mat'])
    load(str);
    str=strcat(currentfolder,['Cell',num2str(ID(tt),'%02d'),'_ratio.mat'])
    load(str);
    savename=['Cell',num2str(ID(tt),'%02d')];
    
    P0=PT(vutarapr,:);
    R0=RT(vutarapr,:);
    mask=vutarall<500 & vutarazerr<60 & P0(:,2)>0 & P0(:,3)>0;% & vutarax>500 & vutarax<20500 & vutaray>500 & vutaray<20500; 
    % mask=P(:,2)>0;
    Pnew=P0(mask,:);
    Rnew=R0(mask,:);
    % mask=ones(length(vutarax),1)>0;
    xout=vutarax(mask);
    yout=vutaray(mask);
    zout=vutaraz(mask);
    currt=vutarat(mask);
    currI=vutaraI(mask);
    currcrlb=vutaracrlb(mask);
    currll=vutarall(mask);
    currbg=vutarabg(mask);
    currzcon=vutarazcon(mask);
    currzerr=vutarazerr(mask);
    
%     drift3d_flag=0;
%     frmnum=3000;
%     tic
%     if drift3d_flag==1
%         mask1=xout>5000&xout<15000&yout>5000&yout<15000;
%         xout1=xout(mask1);
%         yout1=yout(mask1);
%         zout1=zout(mask1);
%         currt1=currt(mask1);
%         [xout1,yout1,zout1,shifts]=iPALM_driftcorrection_RedunLSv7_3d(single(xout1),single(yout1),single(zout1),currt1,frmnum,0);
%         [xout]=shiftcoords_LSv2(xout,shifts(:,1),currt,frmnum,0,0);
%         [yout]=shiftcoords_LSv2(yout,shifts(:,2),currt,frmnum,0,0);
%         [zout]=shiftcoords_LSv2(zout,shifts(:,3),currt,frmnum,0,0);
%     else
%         [xout,yout,zout,shifts]=iPALM_driftcorrection_RedunLSv8(xout,yout,zout,currt,frmnum,0,1,0);
%     end
%     frmnum=3000;
%     [zout,shifts]=iPALM_driftcorrection_RedunLSv9(xout,zout,currt,frmnum,0);
%     toc
%     save([currentfolder savename '_DCresult_two_color'],'xout','yout','zout','shifts');
    
    %%
    P=zeros(length(Pnew),2);
    R=zeros(length(Rnew),1);
    P(:,1)=Pnew(:,1);
    P(:,2)=Pnew(:,3);
    R(:,1)=Rnew(:,2);
    
    threshold1=0.08;
    threshold2=0.16;
    level1=0.05;
    level2=0.05;
    
    ix=R(:,1)<threshold1;
    P1=log10(P(ix,:));
    X1=(P1(:,1)-2.2)*200;
    Y1=(P1(:,2))*60;
    
    dmap=cHistRecon(400,400,single(Y1),single(X1),0);
    dmap=double(gaussf(dmap,2));
    dmap=dmap/max(dmap(:));
    figure;subplot(1,3,1);imshow(dmap,[]); hold on
    
    BW=im2bw(dmap,level1);
    se=strel('disk',10);
    BW=imclose(BW,se);
    
    B=bwboundaries(BW);
    B1=B{1};
    plot(B1(:,2),B1(:,1),'b-');
    
    ix=R(:,1)>threshold2;
    P1=log10(P(ix,:));
    X1=(P1(:,1)-2.2)*200;
    Y1=(P1(:,2))*60;
    
    dmap=cHistRecon(400,400,single(Y1),single(X1),0);
    dmap=double(gaussf(dmap,2));
    dmap=dmap/max(dmap(:));
    subplot(1,3,2);imshow(dmap,[]); hold on
    
    BW=im2bw(dmap,level2);
    se=strel('disk',5);
    BW=imclose(BW,se);
    
    B=bwboundaries(BW);
    B2=B{1};
    plot(B2(:,2),B2(:,1),'b-');
    
    X=(log10(P(:,1))-2.2)*200;
    Y=(log10(P(:,2)))*60;
    dmap=cHistRecon(400,400,single(Y),single(X),0);
    dmap=double(gaussf(dmap,2));
    dmap=dmap/max(dmap(:));
    subplot(1,3,3);imshow(dmap,[]); hold on;
    plot(B1(:,2),B1(:,1),'g-');
    plot(B2(:,2),B2(:,1),'b-');
    pause(1)
    
    %%
    tic
    id1=inpolygon(X,Y,B1(:,2),B1(:,1));
    id2=inpolygon(X,Y,B2(:,2),B2(:,1));
    toc
        
    %%
%     id1=R(:,1)<threshold1;
%     id2=R(:,1)>threshold2;
    vutarax=[];
    vutaray=[];
    vutaraz=[];
    vutarat=[];
    vutaraI=[];
    vutaracrlb=[];
    vutarall=[];
    vutarabg=[];
    vutarazcon=[];
    vutarazerr=[];
    
%     vutarax{1}=xout1;
%     vutarax{2}=xout2;
%     vutaray{1}=yout1;
%     vutaray{2}=yout2;
%     vutaraz{1}=zout1;
%     vutaraz{2}=zout2;  
    vutarax{1}=xout(id1);
    vutarax{2}=xout(id2);
    vutaray{1}=yout(id1);
    vutaray{2}=yout(id2);
    vutaraz{1}=zout(id1);
    vutaraz{2}=zout(id2);

    vutarat{1}=currt(id1);
    vutarat{2}=currt(id2);
    vutaraI{1}=currI(id1);
    vutaraI{2}=currI(id2);
    vutaracrlb{1}=currcrlb(id1);
    vutaracrlb{2}=currcrlb(id2);
    vutarall{1}=currll(id1);
    vutarall{2}=currll(id2);
    vutarabg{1}=currbg(id1);
    vutarabg{2}=currbg(id2);
    vutarazcon{1}=currzcon(id1);
    vutarazcon{2}=currzcon(id2);
    vutarazerr{1}=currzerr(id1);
    vutarazerr{2}=currzerr(id2);
    
    save([currentfolder savename '_' '642' 'v20_60_two_color'],'vutarax','vutaray','vutaraz','vutarat','vutarall','vutaraI','vutarabg','vutarazcon','vutaracrlb','vutarazerr');
    vutarat{1}=ceil(currt(id1)/100);
    vutarat{2}=ceil(currt(id2)/100);
    [flag]=iPALM2vutarav2(currentfolder,[savename '_ll'],2,vutarax,vutaray,vutaraz,vutarat,vutaraI,vutaracrlb,vutarall,vutarabg,vutarazcon,vutarazerr);
    
    %%
    coords=[];
    coords(:,1)=vutarax{1}/10;
    coords(:,2)=vutaray{1}/10;
    coords(:,3)=vutarat{1};
    zm=12.8;
    szx=168*zm;
    szy=168*zm;
    im=cHistRecon(szx,szy,single(coords(:,1)),single(coords(:,2)),0);
    gaussim=gaussf(im,[1 1]);
    str1=([currentfolder savename '_dot_1.tif']);
    str2=([currentfolder savename '_gauss_1.tif']);
    writeim(im,str1,'tiff',1);
    writeim(gaussim,str2,'tiff',1);

    coords=[];
    coords(:,1)=vutarax{2}/10;
    coords(:,2)=vutaray{2}/10;
    coords(:,3)=vutarat{2};
    zm=12.8;
    szx=168*zm;
    szy=168*zm;
    im=cHistRecon(szx,szy,single(coords(:,1)),single(coords(:,2)),0);
    gaussim=gaussf(im,[1 1]);
    str1=([currentfolder savename '_dot_2.tif']);
    str2=([currentfolder savename '_gauss_2.tif']);
    writeim(im,str1,'tiff',1);
    writeim(gaussim,str2,'tiff',1);
end