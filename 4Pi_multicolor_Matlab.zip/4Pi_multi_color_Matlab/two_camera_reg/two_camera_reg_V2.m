%% SCMOS data
clear
close all
centers=[235,472,1559,1797];
pathname='G:\4PISCMOS\2018-11-16\';
savename='two_camera_reg_20181116.mat';
% dataFolder=[pathname,'Cell01\'];
% files=dir([dataFolder,'*.dcimg']);
ID=(11:20)';
l=length(ID);
% l=length(files);
for i=1:l
%     imageName='Cell18_642_000_000.dcimg';
    dataFolder=([pathname,'Cell',num2str(ID(i),'%02d'),'\']);
    imageName=(['Cell',num2str(ID(i),'%02d'),'_642_000_000.dcimg']);
%     imageName=files(i).name;
    [~,qds]=iPALM_readdcimg([dataFolder imageName],centers);
    meanqds1 = mean(qds(:,:,:,1),3);
    offset = median(meanqds1(:));
    qd1=qds(:,:,:,1)-offset;
    qd1(qd1<=0)=1e-7;
    im1(:,:,i)=mean(qd1,3);
end

%% EMCCD data
% dataFolder=[pathname,'\EMCCD\Cell' ];
% files=dir([dataFolder,'*.tif']);
for i=1:l
    dataFolder=([pathname,'EMCCD\','Cell',num2str(ID(i),'%02d'),'\']);
    imageName=(['Cell',num2str(ID(i),'%02d'),'_001.tif']);
%     imageName=files(i).name;
    A=tiffread([dataFolder imageName]);
    meanA=mean(A,3);
    offset=median(meanA(:));
    A=A-offset;
    A=double(A);
    A(A<=0)=1e-7;
    im2(:,:,i)=imrotate(mean(A,3),90);
end

%%
sz=168;
mean_v=ones(sz,sz);
mean_vg=ones(sz,sz);
% I=repmat(im1,1,1,l);
I=im1;
V1=[];
[sub_regions tlz locmaxc subvar_g]=iPALMast_sumim_seg(I,10,9,mean_v,mean_vg,0,1);
[P1 CRLB1 LL1]=sCMOS_MLE_DB_YL_CUDA42(single(sub_regions(:,:,:)),1.4,200,2,single(subvar_g(:,:,:)),single(subvar_g(:,:,:).*0+1));
xf=P1(:,2);
yf=P1(:,1);
xest=xf+tlz(:,2);
yest=yf+tlz(:,1);
V1(:,1)=xest+1;
V1(:,2)=yest+1;
V1(:,3)=tlz(:,3)+1;
% V1(:,1)=xest(1:round(L/10))+1;
% V1(:,2)=yest(1:round(L/10))+1;
figure;imshow(mean(im1,3),[]);hold on;plot(V1(:,1),V1(:,2),'bo');

%%
mean_v=ones(128,128);
mean_vg=ones(128,128);
% I=repmat(im2,1,1,l);
I=im2;
V2=[];
[sub_regions tlz locmaxc subvar_g]=iPALMast_sumim_seg(I,10,7,mean_v,mean_vg,0,2);
[P1 CRLB1 LL1]=sCMOS_MLE_DB_YL_CUDA42(single(sub_regions(:,:,:)),1.4,200,2,single(subvar_g(:,:,:)),single(subvar_g(:,:,:).*0+1));
xf=P1(:,2);
yf=P1(:,1);
xest=xf+tlz(:,2);
yest=yf+tlz(:,1);
V2(:,1)=xest+1;
V2(:,2)=yest+1;
V2(:,3)=tlz(:,3)+1;
% V2(:,1)=xest(1:round(L/10))+1;
% V2(:,2)=yest(1:round(L/10))+1;
figure;imshow(mean(im2,3),[]);hold on;plot(V2(:,1),V2(:,2),'bo');
figure;imshow(mean(im1,3),[]);hold on;plot(V2(:,1)*sz/128,V2(:,2)*sz/128,'bo');

figure;hold on;plot(V2(:,1)*sz/128,V2(:,2)*sz/128,'bo');plot(V1(:,1),V1(:,2),'ro');
%%
rx1=[];
rx2=[];
for i=1:l
    x1=V1(V1(:,3)==i,1:2);
%     x2=V2(V2(:,3)==i,1:2)*192/128;
    x2=[];
    x2(:,1)=V2(V2(:,3)==i,1)*sz/128;
    x2(:,2)=V2(V2(:,3)==i,2)*sz/128;
%     figure;plot(x1(:,1),x1(:,2),'bo');hold on;plot(x2(:,1),x2(:,2),'ro');
    [rcx1 rcx2 result flag] = GetPointsReg(x1,x2);
    D=sqrt((rcx1(:,1)-rcx2(:,1)).^2+(rcx1(:,2)-rcx2(:,2)).^2);
    id=D>10;
    rcx1(id,:)=[];
    rcx2(id,:)=[];
    rx1=cat(1,rx1,rcx1);
    rx2=cat(1,rx2,rcx2);
end
figure;plot(rx1(:,1),rx1(:,2),'bo');hold on;plot(rx2(:,1),rx2(:,2),'ro');

%%
x1=rx1;
x2=rx2;
[betax,betay]=biplaneReg_linear(x2(:,1),x2(:,2),x1(:,1),x1(:,2));

x3=[];
XX=[ones(size(x1(:,1))),x1(:,1),x1(:,2),x1(:,1).*x1(:,2),x1(:,1).^2,x1(:,2).^2];
x3(:,1)=XX*betax;
x3(:,2)=XX*betay;

Ex=x2(:,1)-x3(:,1);
Ey=x2(:,2)-x3(:,2);
Ex=Ex*128;
Ey=Ey*128;
std(Ex)
std(Ey)

figure;
hold on
plot(x2(:,1),x2(:,2),'r.');
plot(x3(:,1),x3(:,2),'go');
axis([0 sz 0 sz]);
axis equal

% figure;
% hold on
% plot(V2(:,1),V2(:,2),'r.');
% plot(x3(:,1)*128/sz,x3(:,2)*128/sz,'go');
% axis([0 128 0 128]);
% axis equal

id=abs(Ex)>200 | abs(Ey)>200;
x1(id,:)=[];
x2(id,:)=[];

x3=[];
[betax,betay]=biplaneReg_linear(x2(:,1),x2(:,2),x1(:,1),x1(:,2));
XX=[ones(size(x1(:,1))),x1(:,1),x1(:,2),x1(:,1).*x1(:,2),x1(:,1).^2,x1(:,2).^2];
x3(:,1)=XX*betax;
x3(:,2)=XX*betay;

Ex=x2(:,1)-x3(:,1);
Ey=x2(:,2)-x3(:,2);
Ex=Ex*128;
Ey=Ey*128;
std(Ex)
std(Ey)

figure;
hold on
plot(x2(:,1),x2(:,2),'r.');
plot(x3(:,1),x3(:,2),'go');
axis([0 sz 0 sz]);
axis equal


id=abs(Ex)>100 | abs(Ey)>100;
x1(id,:)=[];
x2(id,:)=[];

x3=[];
[betax,betay]=biplaneReg_linear(x2(:,1),x2(:,2),x1(:,1),x1(:,2));
XX=[ones(size(x1(:,1))),x1(:,1),x1(:,2),x1(:,1).*x1(:,2),x1(:,1).^2,x1(:,2).^2];
x3(:,1)=XX*betax;
x3(:,2)=XX*betay;

Ex=x2(:,1)-x3(:,1);
Ey=x2(:,2)-x3(:,2);
Ex=Ex*128;
Ey=Ey*128;
std(Ex)
std(Ey)

figure;
hold on
plot(x2(:,1),x2(:,2),'r.');
plot(x3(:,1),x3(:,2),'go');
axis([0 sz 0 sz]);
axis equal

% figure;
% hold on
% plot(V2(:,1),V2(:,2),'r.');
% plot(x3(:,1)*128/sz,x3(:,2)*128/sz,'go');
% axis([0 128 0 128]);
% axis equal

savefolder=pathname;
str=strcat(savefolder,'\',savename);
save(str,'betax','betay');