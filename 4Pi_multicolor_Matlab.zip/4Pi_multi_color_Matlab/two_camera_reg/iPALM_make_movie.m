%%
clear
clc
file='D:\4Pi_two_color\2017-4-7\Cell05_movie\Cell05_642_019_000.tif';
I1=tiffread(file);
file='D:\4Pi_two_color\2017-4-7\Cell05_movie\Cell05_20.tif';
I2=tiffread(file);

%%
sz=168;
mean_v=ones(sz,sz);
mean_vg=ones(sz,sz);
[sub_regions tlz locmaxc subvar_g]=iPALMast_sumim_seg(I1,4,7,mean_v,mean_vg,0);

%%
V=[];
V(:,1)=tlz(:,2)+4;
V(:,2)=tlz(:,1)+4;
V(:,3)=tlz(:,3)+1;
id=V(:,3)==1;
cx=V(id,1);
cy=V(id,2);
figure;imshow(I1(:,:,1),[]);hold on;plot(cx,cy,'ro');

%%
% V=[];
% mask=ones(length(xresult),1)>0;
% V(:,1)=xresult(mask)+1;
% V(:,2)=yresult(mask)+1;
% V(:,3)=tresult(mask)+1;
% id=V(:,3)==3000*19+1;
% cx=V(id,1);
% cy=V(id,2);
% figure;imshow(I1(:,:,1),[]);hold on;plot(cx,cy,'ro');

%%
load('D:\4Pi_two_color\2017-4-7\two_camera_reg_20170407.mat');
x1=[];
x1(:,1)=V(:,1);
x1(:,2)=V(:,2);
x3=[];
XX=[ones(size(x1(:,1))),x1(:,1),x1(:,2),x1(:,1).*x1(:,2),x1(:,1).^2,x1(:,2).^2];
x3(:,1)=XX*betax;
x3(:,2)=XX*betay;
x3=x3*128/168;
id=V(:,3)==1;
cx=x3(id,1);
cy=x3(id,2);
figure;imshow(I2(:,:,1),[500 2000]);hold on;plot(cx,cy,'ro');

%%
fstr='D:\4Pi_two_color\2017-4-7\Cell05_movie\RGB1.avi';
% mov=avifile(fstr,'fps',30,'quality',100,'compression','none');
myObj=VideoWriter(fstr);
myObj.FrameRate=30;
open(myObj);
figure;
for i=1:300
    id=V(:,3)==i;
    cx=V(id,1);
    cy=V(id,2);
    cla;
    imshow(I1(:,:,i),[0 300],'InitialMagnification',300);hold on;plot(cx,cy,'ro');
    pause(0.01);
    frame=getframe(gca);
    writeVideo(myObj,frame);
end
close(myObj);

%%
fstr='D:\4Pi_two_color\2017-4-7\Cell05_movie\RGB2.avi';
myObj=VideoWriter(fstr);
myObj.FrameRate=30;
open(myObj);
figure;
for i=1:300
    id=V(:,3)==i;
    cx=x3(id,1);
    cy=x3(id,2);
    cla;
    imshow(I2(:,:,i),[300 3000],'InitialMagnification',300);hold on;plot(cx,cy,'ro');
    pause(0.01);
    frame=getframe(gca);
    writeVideo(myObj,frame);
end
close(myObj);
