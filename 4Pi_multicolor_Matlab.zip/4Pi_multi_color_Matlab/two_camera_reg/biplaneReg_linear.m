function [betax betay XX]=biplaneReg_linear(x1,y1,x2,y2)
%estimate betax
yy=x1;
XX=[ones(size(x1)) x2 y2 x2.*y2 x2.^2 y2.^2];
betax=inv(XX'*XX)*XX'*yy;

yy=y1;
XX=[ones(size(x1)) x2 y2 x2.*y2 x2.^2 y2.^2];
betay=inv(XX'*XX)*XX'*yy;