function fmfile=GetTransform(qd1,qd2,qd3,qd4,foldername,filename)

qdall=cat(4,qd1,qd2,qd3,qd4);
V={};
for ii=1:4
    Im=qdall(:,:,:,ii);
    [sub_regions tlz locmaxc subvar_g]=iPALMast_sumim_seg(Im,5,13,ones(168,168),ones(168,168),0);
    [P CRLB LL]=sCMOS_MLE_DB_YL_CUDA42(single(sub_regions(:,:,:)),1.4,200,7,single(subvar_g(:,:,:)),single(subvar_g(:,:,:).*0+1));
    mask=abs(P(:,1)-6)<1 & abs(P(:,2)-6)<1 & CRLB(:,1)>0 & CRLB(:,2)>0 & CRLB(:,1)<0.01 & CRLB(:,2)<0.01 & -2*LL<400 & P(:,3)>1000;
    P1=P(mask,:);
    tlzf=tlz(mask,:);
    T=tlzf(:,3);
    cx=P1(:,1)+tlzf(:,1)+1;
    cy=P1(:,2)+tlzf(:,2)+1;
    V{ii}(:,1)=cx;
    V{ii}(:,2)=cy;
    V{ii}(:,3)=T;
end

for ii=1:4
    V1=V{1};
    V2=V{ii};
    V2(:,4)=(1:length(V2))';
    V1(:,4)=0;
    for i=1:length(V1)
        x=V1(i,1);
        y=V1(i,2);
        t=V1(i,3);
        ix=V2(:,3)==t;
        V0=V2(ix,:);
        dist=(V0(:,1)-x).^2+(V0(:,2)-y).^2;
        if min(dist)<3
            id=find(dist==min(dist));
            V1(i,4)=V0(id,4);
        end
    end
    id=V1(:,4)>0;
    V1new=V1(id,:);
    V2new=V2(V1new(:,4),:);
    
    x1=single(V1new(:,1:2));
    x2=single(V2new(:,1:2));
    %     figure;plot(x1(:,1),x1(:,2),'bo');hold on;plot(x2(:,1),x2(:,2),'ro');
    im1=gaussf(cHistRecon(168,168,x1(:,1),x1(:,2),0),1);
    im2=gaussf(cHistRecon(168,168,x2(:,1),x2(:,2),0),1);
    
    [zm,trans,ang] = fmmatch(im2,im1);
    [out,R(:,:,ii)] = find_affine_trans(im2, im1, [[zm zm],trans,ang]);
    zm_fin=out(1:2);
    trans_fin=out(3:4);
    ang_fin=out(5);
    
    [imout]=affine_trans(im2,zm_fin,trans_fin,ang_fin);
    zm_all(ii,:)=zm_fin;
    trans_all(ii,:)=trans_fin;
    ang_all(ii,:)=ang_fin;
    
    [zm,trans,ang] = fmmatch(im1,im2);
    [~,invR(:,:,ii)] = find_affine_trans(im1, im2, [[zm zm],trans,ang]);
end

filestr=[foldername filename(1:end-6) '_FMTtransform_' datestr(now,'yyyymmdd'),'.mat'];
save(filestr,'zm_all','trans_all','ang_all','R','invR');
fmfile=filestr;

