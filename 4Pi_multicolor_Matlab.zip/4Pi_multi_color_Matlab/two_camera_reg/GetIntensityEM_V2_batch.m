%%
clear
clc
pathname='E:\4Pi_two_color\2019-3-17\';
% FN=3000;
datestr='20190317.mat';
ID=[1,2,4];
for tt=1:length(ID)
    tt    
    % V=[];
    % V(:,1)=vutarax/128;
    % V(:,2)=vutaray/128;
    % V(:,3)=vutarat+1;
    % V(:,4)=vutaraI;
    close all;
    str=strcat(pathname,['Cell',num2str(ID(tt),'%02d'),'_642_tmpresult_',datestr])
    load(str);
    
    V=[];
%     mask=Iresult>200 & Iresult<20000 & abs(xresult-83)<70 & abs(yresult-83)<70;%  & CRLBresult(:,1)<0.2 & CRLBresult(:,2)<0.2 & llresult<500;% & zangctrresult>0.0 
    mask=ones(length(xresult),1)>0;
    V(:,1)=xresult(mask)+1;
    V(:,2)=yresult(mask)+1;
    V(:,3)=tresult(mask)+1;
    V(:,4)=Iresult(mask);

    %%
%     load('G:\4PISCMOS\2017-10-28\two_camera_reg_20171027.mat');
    load([pathname,'two_camera_reg_',datestr]);
    x1=[];
    x1(:,1)=V(:,1);
    x1(:,2)=V(:,2);
    x3=[];
    XX=[ones(size(x1(:,1))),x1(:,1),x1(:,2),x1(:,1).*x1(:,2),x1(:,1).^2,x1(:,2).^2];
    x3(:,1)=XX*betax;
    x3(:,2)=XX*betay;
    x3=x3*128/168;
    
    %%
    dataFolder=strcat(pathname,'EMCCD\Cell',num2str(ID(tt),'%02d'),'\');
    files=dir([dataFolder,'*.tif']);
    N=length(files);
    k=round(N/2);
    k=40;
    filestr=strcat(dataFolder,files(k).name);
    info=imfinfo(filestr);
    FN=length(info)-1;
    Im=tiffread(filestr,[1,FN]);
    Im=imrotate(Im,90);       
    st=(k-1)*FN+1;
    et=k*FN;
    id=V(:,3)>=st & V(:,3)<=et;
    if sum(id)==0
        continue
    end    
    xin=x3(id,:);
    xin(:,3)=V(id,3)-st+1;
    E=Getshift(Im,xin);
    x3(:,1)=x3(:,1)-E(1,1);
    x3(:,2)=x3(:,2)-E(1,2);
    save([pathname,'Cell',num2str(ID(tt),'%02d'),'_shift.mat'],'E');

    %%
%     dataFolder=strcat(pathname,'EMCCD\Cell',num2str(ID(tt),'%02d'),'\');
%     files=dir([dataFolder,'*.tif']);
%     N=length(files);
    RT=[];
    PT=[];
    for k=1:N
        k
        filestr=strcat(dataFolder,files(k).name);  
%         if k==1
%             info=imfinfo(filestr);
%             FN=length(info)-1;
%         end
        Im=tiffread(filestr,[1,FN]);
        Im=imrotate(Im,90);

        totsz=128;
        om=zeros(totsz,totsz);
        varm=zeros(totsz,totsz);
        for i=1:totsz
            for j=1:totsz
                I=single(Im(i,j,:));
                I=I(:);
                threshold=mean(I)+3*std(I);
                ix=I<threshold;
                I=I(ix);
                om(i,j)=mean(I);
                varm(i,j)=var(I);
            end
        end

        st=(k-1)*FN+1;
        et=k*FN;
        id=V(:,3)>=st & V(:,3)<=et;
        if sum(id)==0
            continue
        end
        
%         if k==1
%             xin=x3(id,:);
%             xin(:,3)=V(id,3)-st+1;
%             E=Getshift(Im,xin);
%             x3(:,1)=x3(:,1)-E(1,1);
%             x3(:,2)=x3(:,2)-E(1,2);
%             save([pathname,'Cell',num2str(ID(tt),'%02d'),'_shift.mat'],'E');
%         end
        
        trans_x=x3(id,1)-1;
        trans_y=x3(id,2)-1;
        tc=V(id,3)-st;
        subsz=5;
        % meanIm=mean(Im,3);
        % im=Im-min(meanIm(:));
        % im=single(Im);
        l=size(Im,3);
        omap=repmat(om,1,1,l);
        im=single(Im)-omap;
        [subims t l]=cMakeSubregions(round(trans_y),round(trans_x),tc,subsz,single(permute(im,[1 2 3])));
        L=length(subims);
        P=[];
%         [subims1 t1 l1]=cMakeSubregions(round(trans_y),round(trans_x),tc,7,single(permute(im,[1 2 3])));
%         subims1=subims1*12/300;
%         subims1(subims1<0)=1e-7;
%         [P1 CRLB1 LL1]=sCMOS_MLE_DB_YL_CUDA42(single(subims1),0.75,50,6,single(ones(7,7,L)),single(ones(7,7,L)));
%         P(:,4)=P1(:,3);
        subims=subims*12/200;
        xcenter=trans_x(:)-l;
        ycenter=trans_y(:)-t;

%         f=100;
%         ix=V(:,3)==st+f-1;
%         I=im(:,:,f);
%         figure;imshow(I,[0 max(I(:))]);hold on;plot(x3(ix,1),x3(ix,2),'bo');

        sigma=0.75;
        sz=size(subims,1);
        Model=single(zeros(sz,sz,size(subims,3)));
        for ii=1:1
            yf=ycenter(:,ii);
            xf=xcenter(:,ii);
            ROI=finiteGaussPSFerf(sz,sigma,1,0,[xf,yf]);
            Model(:,:,:,ii)=single(dip_array(ROI));
        end

    %     st=(k-1)*3000+1;
    %     et=k*3000;
    %     id=V(:,3)>=st & V(:,3)<=et;
        P(:,1)=V(id,4);
        for i=1:L
            I=subims(:,:,i);
            %     I=I-min(I(:));
            I(I<0)=0;
            model=Model(:,:,i);
            Inom=I.*(model);
            P(i,2)=sum(I(:));
            P(i,3)=sum(Inom(:))*10;
        end
        R=[];
        R(:,1)=P(:,2)./P(:,1);
        R(:,2)=P(:,3)./P(:,1); 
%         R(:,3)=P(:,4)./P(:,1);
        RT=cat(1,RT,R);
        PT=cat(1,PT,P);
    end
    figure;plot(log10(PT(:,1)),log10(PT(:,2)),'r.'); 
%     figure;plot(log10(PT(:,1)),log10(PT(:,4)),'r.'); 

    save([pathname,'Cell',num2str(ID(tt),'%02d'),'_ratio.mat'],'PT','RT');
    
end