%%
clear
clc
file='E:\4Pi_Paper\2018-2-18+\movie1\Cell05_642_049_000.tif';
I1=tiffread(file);
file='E:\4Pi_Paper\2018-2-18+\movie1\Cell05_050.tif';
I2=tiffread(file);

%%
sz=168;
mean_v=ones(sz,sz);
mean_vg=ones(sz,sz);
[sub_regions tlz locmaxc subvar_g]=iPALMast_sumim_seg(I1,6,13,mean_v,mean_vg,0,1);

%%
[P1 CRLB1 LL1]=sCMOS_MLE_DB_YL_CUDA42(single(sub_regions),1.4,200,7,single(subvar_g),single(subvar_g.*0+1));

%%
f=1374;
V=[];
V(:,1)=tlz(:,2)+P1(:,1)+7;
V(:,2)=tlz(:,1)+P1(:,2)+7;
V(:,3)=tlz(:,3)+1;
id=V(:,3)==f & V(:,1)>61 & V(:,1)<141 & V(:,2)>66 & V(:,2)<146;
cx=V(id,1);
cy=V(id,2);
figure;imshow(I1(:,:,f),[]);hold on;plot(cx,cy,'ro');

%%
load('E:\4Pi_Paper\2018-2-18+\two_camera_reg_20180218.mat');
x1=[];
x1(:,1)=V(:,1);
x1(:,2)=V(:,2);
x3=[];
XX=[ones(size(x1(:,1))),x1(:,1),x1(:,2),x1(:,1).*x1(:,2),x1(:,1).^2,x1(:,2).^2];
x3(:,1)=XX*betax;
x3(:,2)=XX*betay;
x3=x3*128/168;
% id=V(:,3)==f;
cx=x3(id,1);
cy=x3(id,2);
figure;imshow(I2(:,:,f),[500 5000]);hold on;plot(cx,cy,'ro');

%%
fpath1='E:\4Pi_Paper\2018-2-18+\movie1\Cell05_roi\';
if ~exist(fpath1,'dir')
    mkdir(fpath1);
end
files = dir(fpath1);
for i=3:length(files)
    file=strcat(fpath1,files(i).name);
    delete(file);
end

% id=V(:,3)==f;
cx=x3(id,1)*1680/128-609-5;
cy=x3(id,2)*1680/128-668-5;
% cx=V(id,1)*10-5-609;
% cy=V(id,2)*10-5-668;

V0=[];
V0(:,2)=cy;
V0(:,3)=cx;
V0(:,1)=f;

r=20;
n=length(V0);
for i=1:n
    strk=int2str(V0(i,1));
    lenk=length(strk);
    for lk=lenk:3
        strk=strcat('0',strk);
    end
    stryv=int2str(V0(i,3));
    lenk=length(stryv);
    for lk=lenk:3
        stryv=strcat('0',stryv);
    end
    strxv=int2str(V0(i,2));
    lenk=length(strxv);
    for lk=lenk:3
        strxv=strcat('0',strxv);
    end
    fstr=strcat(strk,'-',stryv,'-',strxv,'.roi');
    fname1=strcat(fpath1,fstr);
    fid1 = fopen(fname1, 'wb');
    p1=floor(round(V0(i,2)-r)/256);
    p2=mod(round(V0(i,2)-r),256);
    p3=floor(round(V0(i,3)-r)/256);
    p4=mod(round(V0(i,3)-r),256);
    p5=floor(round(V0(i,2)+r)/256);
    p6=mod(round(V0(i,2)+r),256);
    p7=floor(round(V0(i,3)+r)/256);
    p8=mod(round(V0(i,3)+r),256);
    head=[73 111 117 116 0 217 2 0 p1 p2 p3 p4 p5 p6 p7 p8];
    package=[head zeros(1,16) zeros(1,16) zeros(1,16)];
    fwrite(fid1,package);
    fclose(fid1);
end

fstr='E:\4Pi_Paper\2018-2-18+\movie1\Cell05_RoiSet1.zip';
if exist(fstr,'file')
    delete(fstr)
end
zip(fstr,fpath1);
files = dir(fpath1);
for i=3:length(files)
    file=strcat(fpath1,files(i).name);
    delete(file);
end
rmdir(fpath1);
