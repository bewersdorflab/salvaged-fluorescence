%%
% clc
P0=PT(vutarapr,:);
R0=RT(vutarapr,:);
mask=vutarall<300 & vutarazerr<60 & P0(:,2)>0 & P0(:,3)>0 & R0(:,2)>0.0 & vutaracrlb<0.20;% & vutaraz>-100 & vutaraz<100;% & vutarax>4000 & vutarax<16000 & vutaray>2000 & vutaray<14000;% & vutaraz>-300 & vutaraz<200;% & vutarat>3000; 
% mask=P(:,2)>0;
Pnew=P0(mask,:);
Rnew=R0(mask,:);
% mask=ones(length(vutarax),1)>0;
xout=vutarax(mask);
yout=vutaray(mask);
zout=vutaraz(mask);
currt=vutarat(mask); 
currI=vutaraI(mask);
currcrlb=vutaracrlb(mask);
currll=vutarall(mask);
currbg=vutarabg(mask);
currzcon=vutarazcon(mask);
currzerr=vutarazerr(mask);

mean(Rnew(:,2))

% currentfolder='E:\4Pi_two_color\2018-6-30\';
% savename='Cell01';

%% AF647
P=zeros(length(Pnew),2);
R=zeros(length(Rnew),1);
P(:,1)=Pnew(:,1);
P(:,2)=Pnew(:,3);
R(:,1)=Rnew(:,2);

threshold1=0.10;
threshold2=0.20;
level1=0.05;
level2=0.01;

ix=R(:,1)>threshold2;
P1=log10(P(ix,:));
% X1=(P1(:,1)-2.2)*200;
% Y1=(P1(:,2)-0.5)*100;
X1=(P1(:,1)-2.5)*200;
Y1=(P1(:,2)-0.1)*100;

dmap=cHistRecon(400,400,single(Y1),single(X1),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
figure;imshow(dmap,[]); hold on; axis xy

BW=im2bw(dmap,level2);
se=strel('disk',5);
BW=imclose(BW,se);

B=bwboundaries(BW);
B2=B{1};
plot(B2(:,2),B2(:,1),'b-');

%% CF660C
P=zeros(length(Pnew),2);
R=zeros(length(Rnew),1);
P(:,1)=Pnew(:,1);
P(:,2)=Pnew(:,3);
R(:,1)=Rnew(:,2);

threshold1=0.10;
threshold2=0.20;
level1=0.05;
level2=0.01;

ix=R(:,1)<threshold1;
P1=log10(P(ix,:));
% X1=(P1(:,1)-2.2)*200;
% Y1=(P1(:,2)-0.5)*100;
X1=(P1(:,1)-2.5)*200;
Y1=(P1(:,2)-0.1)*100;

dmap=cHistRecon(400,400,single(Y1),single(X1),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
figure;imshow(dmap,[]); hold on; axis xy

BW=im2bw(dmap,level1);
se=strel('disk',10);
BW=imclose(BW,se);

B=bwboundaries(BW);
B1=B{1};
plot(B1(:,2),B1(:,1),'b-');


%% DY634
P=zeros(length(Pnew),2);
R=zeros(length(Rnew),1);
P(:,1)=Pnew(:,1);
P(:,2)=Pnew(:,3);
R(:,1)=Rnew(:,2);

threshold1=0.05;
threshold2=0.10;
threshold3=0.25;
threshold4=0.40;
level1=0.10;
level2=0.10;
level3=0.10;

ix=R(:,1)>threshold4;
P1=log10(P(ix,:));
X1=(P1(:,1)-2.2)*200;
Y1=(P1(:,2))*60;

dmap=cHistRecon(400,400,single(Y1),single(X1),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
figure;imshow(dmap,[]); hold on; axis xy

BW=im2bw(dmap,level3);
se=strel('disk',5);
BW=imclose(BW,se);

B=bwboundaries(BW);
B3=B{1};
plot(B3(:,2),B3(:,1),'b-');

%% DL650
P=zeros(length(Pnew),2);
R=zeros(length(Rnew),1);
P(:,1)=Pnew(:,1);
P(:,2)=Pnew(:,3);
R(:,1)=Rnew(:,2);

threshold1=0.05;
threshold2=0.10;
threshold3=0.25;
threshold4=0.40;
level1=0.10;
level2=0.10;
level3=0.10;

ix=R(:,1)>threshold2 & R(:,1)<threshold3;
P1=log10(P(ix,:));
X1=(P1(:,1)-2.2)*200;
Y1=(P1(:,2))*60;

dmap=cHistRecon(400,400,single(Y1),single(X1),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
figure;imshow(dmap,[]); hold on

BW=im2bw(dmap,level2);
se=strel('disk',5);
BW=imclose(BW,se);

B=bwboundaries(BW);
B2=B{1};
plot(B2(:,2),B2(:,1),'g-');

%% CF680
P=zeros(length(Pnew),2);
R=zeros(length(Rnew),1);
P(:,1)=Pnew(:,1);
P(:,2)=Pnew(:,3);
R(:,1)=Rnew(:,2);

threshold1=0.05;
threshold2=0.10;
threshold3=0.25;
threshold4=0.40;
level1=0.10;
level2=0.10;
level3=0.10;

ix=R(:,1)<threshold1 & P(:,2)<80 & P(:,2)>1;
P1=log10(P(ix,:));
X1=(P1(:,1)-2.2)*200;
Y1=(P1(:,2))*60;

dmap=cHistRecon(400,400,single(Y1),single(X1),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
figure;imshow(dmap,[]); hold on

BW=im2bw(dmap,level1);
se=strel('disk',5);
BW=imclose(BW,se);

B=bwboundaries(BW);
B1=B{1};
plot(B1(:,2),B1(:,1),'r-');

%%
figure;plot(Pnew(:,1),Pnew(:,3),'m.'); axis([10^2.5 10^4.5 10^0.1 10^4.1]); set(gca, 'XScale', 'log'); set(gca, 'YScale', 'log');

