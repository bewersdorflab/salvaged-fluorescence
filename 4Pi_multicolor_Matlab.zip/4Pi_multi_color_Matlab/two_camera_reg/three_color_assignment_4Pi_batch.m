%%
clear
clc
currentfolder='G:\4PISCMOS\2017-12-25\';
ID=[1,2,3,4,5,6];
for tt=1:length(ID)
    tt
    close all
    str=strcat(currentfolder,['Cell',num2str(ID(tt),'%02d'),'_642v20_60.mat'])
    load(str);
    str=strcat(currentfolder,['Cell',num2str(ID(tt),'%02d'),'_ratio.mat'])
    load(str);
    savename=['Cell',num2str(ID(tt),'%02d')];

    P0=PT(vutarapr,:);
    R0=RT(vutarapr,:);
    mask=vutarall<300 & vutarazerr<60 & P0(:,2)>0 & P0(:,3)>0;%& vutarax>1500 & vutarax<19500 & vutaray>1500 & vutaray<19500 & 
    % mask=P(:,2)>0;
    Pnew=P0(mask,:);
    Rnew=R0(mask,:);
    % mask=ones(length(vutarax),1)>0;
    xout=vutarax(mask);
    yout=vutaray(mask);
    zout=vutaraz(mask);
    currt=vutarat(mask);
    currI=vutaraI(mask);
    currcrlb=vutaracrlb(mask);
    currll=vutarall(mask);
    currbg=vutarabg(mask);
    currzcon=vutarazcon(mask);
    currzerr=vutarazerr(mask);
    
%     tic
%     [xout,yout,zout,shifts]=iPALM_driftcorrection_RedunLSv8(xout,yout,zout,currt,1000,0,1,0);
%     toc
%     save([currentfolder savename '_DCresult_three_color'],'xout','yout','zout','shifts');
    
    %%
    P=zeros(length(Pnew),2);
    R=zeros(length(Rnew),1);
    P(:,1)=Pnew(:,1);
    P(:,2)=Pnew(:,3);
    R(:,1)=Rnew(:,2);
    
    threshold1=0.06;
    threshold2=0.10;
    threshold3=0.25;
    threshold4=0.40;
    level1=0.09;
    level2=0.2;
    level3=0.2;
    
    ix=R(:,1)<threshold1 & P(:,2)<80;
    P1=log10(P(ix,:));
    X1=(P1(:,1)-2.2)*200;
    Y1=(P1(:,2))*60;
    
    dmap=cHistRecon(400,400,single(Y1),single(X1),0);
    dmap=double(gaussf(dmap,2));
    dmap=dmap/max(dmap(:));
    figure;subplot(2,2,1);imshow(dmap,[]); hold on
    
    BW=im2bw(dmap,level1);
    se=strel('disk',5);
    BW=imclose(BW,se);
    
    B=bwboundaries(BW);
    B1=B{1};
    plot(B1(:,2),B1(:,1),'r-');
    
    ix=R(:,1)>threshold2 & R(:,1)<threshold3;
    P1=log10(P(ix,:));
    X1=(P1(:,1)-2.2)*200;
    Y1=(P1(:,2))*60;
    
    dmap=cHistRecon(400,400,single(Y1),single(X1),0);
    dmap=double(gaussf(dmap,2));
    dmap=dmap/max(dmap(:));
    subplot(2,2,2);imshow(dmap,[]); hold on
    
    BW=im2bw(dmap,level2);
    se=strel('disk',5);
    BW=imclose(BW,se);
    
    B=bwboundaries(BW);
    B2=B{1};
    plot(B2(:,2),B2(:,1),'g-');
    
    ix=R(:,1)>threshold4;
    P1=log10(P(ix,:));
    X1=(P1(:,1)-2.2)*200;
    Y1=(P1(:,2))*60;
    
    dmap=cHistRecon(400,400,single(Y1),single(X1),0);
    dmap=double(gaussf(dmap,2));
    dmap=dmap/max(dmap(:));
    subplot(2,2,3);imshow(dmap,[]); hold on
    
    BW=im2bw(dmap,level3);
    se=strel('disk',5);
    BW=imclose(BW,se);
    
    B=bwboundaries(BW);
    B3=B{1};
    plot(B3(:,2),B3(:,1),'b-');
    
    X=(log10(P(:,1))-2.2)*200;
    Y=(log10(P(:,2)))*60;
    dmap=cHistRecon(400,400,single(Y),single(X),0);
    dmap=double(gaussf(dmap,2));
    dmap=dmap/max(dmap(:));
    subplot(2,2,4);imshow(dmap,[]); hold on;
    plot(B1(:,2),B1(:,1),'r-');
    plot(B2(:,2),B2(:,1),'g-');
    plot(B3(:,2),B3(:,1),'b-');
    pause(1)
    
    %%
    tic
    id1=inpolygon(X,Y,B1(:,2),B1(:,1));
    id2=inpolygon(X,Y,B2(:,2),B2(:,1));
    id3=inpolygon(X,Y,B3(:,2),B3(:,1));
    toc
    
    %%
    % [p1,s1,mu1]=polyfit(P0(id1,1),P0(id1,2),1);
    % [p2,s2,mu2]=polyfit(P0(id2,1),P0(id2,2),1);
    % [y1,d1]=polyval(p1,P0(:,1),s1,mu1);
    % [y2,d2]=polyval(p2,P0(:,1),s2,mu2);
    % e=[];
    % e(:,1)=log10(P(:,2))-y1;
    % e(:,2)=log10(P(:,2))-y2;
    % % ix=e(:,1)>0 & e(:,2)<0;
    % % e1=abs(e(ix,:));
    % % e1(:,3)=e1(:,1)+e1(:,2);
    % % e2=e1(:,1)./e1(:,3);
    
    %%
    % id1=R(:,1)<threshold1;
    % id2=R(:,1)>threshold2 & R(:,1)<threshold3;
    % id3=R(:,1)>threshold4;
    vutarax=[];
    vutaray=[];
    vutaraz=[];
    vutarat=[];
    vutaraI=[];
    vutaracrlb=[];
    vutarall=[];
    vutarabg=[];
    vutarazcon=[];
    vutarazerr=[];
    vutarax{1}=xout(id1);
    vutarax{2}=xout(id2);
    vutarax{3}=xout(id3);
    vutaray{1}=yout(id1);
    vutaray{2}=yout(id2);
    vutaray{3}=yout(id3);
    vutaraz{1}=zout(id1);
    vutaraz{2}=zout(id2);
    vutaraz{3}=zout(id3);
    vutarat{1}=ceil(currt(id1)/100);
    vutarat{2}=ceil(currt(id2)/100);
    vutarat{3}=ceil(currt(id3)/100);
    vutaraI{1}=currI(id1);
    vutaraI{2}=currI(id2);
    vutaraI{3}=currI(id3);
    vutaracrlb{1}=currcrlb(id1);
    vutaracrlb{2}=currcrlb(id2);
    vutaracrlb{3}=currcrlb(id3);
    vutarall{1}=currll(id1);
    vutarall{2}=currll(id2);
    vutarall{3}=currll(id3);
    vutarabg{1}=currbg(id1);
    vutarabg{2}=currbg(id2);
    vutarabg{3}=currbg(id3);
    vutarazcon{1}=currzcon(id1);
    vutarazcon{2}=currzcon(id2);
    vutarazcon{3}=currzcon(id3);
    vutarazerr{1}=currzerr(id1);
    vutarazerr{2}=currzerr(id2);
    vutarazerr{3}=currzerr(id3);
    
    [flag]=iPALM2vutarav2(currentfolder,[savename '_ll'],3,vutarax,vutaray,vutaraz,vutarat,vutaraI,vutaracrlb,vutarall,vutarabg,vutarazcon,vutarazerr);
    save([currentfolder savename '_' '642' 'v20_60_three_color'],'vutarax','vutaray','vutaraz','vutarat','vutarall','vutaraI','vutarabg','vutarazcon','vutaracrlb','vutarazaster');
    
    coords=[];
    coords(:,1)=vutarax{1}/10;
    coords(:,2)=vutaray{1}/10;
    coords(:,3)=vutarat{1};
    zm=12.8;
    szx=168*zm;
    szy=168*zm;
    im=cHistRecon(szx,szy,single(coords(:,1)),single(coords(:,2)),0);
    gaussim=gaussf(im,[1 1]);
    str1=([currentfolder savename '_dot_1.tif']);
    str2=([currentfolder savename '_gauss_1.tif']);
    writeim(im,str1,'tiff',1);
    writeim(gaussim,str2,'tiff',1);
    
    coords=[];
    coords(:,1)=vutarax{2}/10;
    coords(:,2)=vutaray{2}/10;
    coords(:,3)=vutarat{2};
    zm=12.8;
    szx=168*zm;
    szy=168*zm;
    im=cHistRecon(szx,szy,single(coords(:,1)),single(coords(:,2)),0);
    gaussim=gaussf(im,[1 1]);
    str1=([currentfolder savename '_dot_2.tif']);
    str2=([currentfolder savename '_gauss_2.tif']);
    writeim(im,str1,'tiff',1);
    writeim(gaussim,str2,'tiff',1);
    
    coords=[];
    coords(:,1)=vutarax{3}/10;
    coords(:,2)=vutaray{3}/10;
    coords(:,3)=vutarat{3};
    zm=12.8;
    szx=168*zm;
    szy=168*zm;
    im=cHistRecon(szx,szy,single(coords(:,1)),single(coords(:,2)),0);
    gaussim=gaussf(im,[1 1]);
    str1=([currentfolder savename '_dot_3.tif']);
    str2=([currentfolder savename '_gauss_3.tif']);
    writeim(im,str1,'tiff',1);
    writeim(gaussim,str2,'tiff',1);
end