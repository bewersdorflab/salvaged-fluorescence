%%
clear
clc
str='E:\4Pi_Paper\crosstalk_three_color\three_color.mat';
load(str);
%% DY634
P=zeros(length(Pnew_DY634),2);
P(:,1)=Pnew_DY634(:,1);
P(:,2)=Pnew_DY634(:,3);

level1=0.10;
P1=log10(P);
X1=(P1(:,1)-2.5)*200;
Y1=(P1(:,2)-0.5)*100;

dmap=cHistRecon(350,350,single(Y1),single(X1),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
figure;imshow(dmap,[]); hold on; axis xy

BW=im2bw(dmap,level1);
se=strel('disk',5);
BW=imclose(BW,se);

B=bwboundaries(BW);
B1=B{1};
plot(B1(:,2),B1(:,1),'b-');

%% DL650
P=zeros(length(Pnew_DL650),2);
P(:,1)=Pnew_DL650(:,1);
P(:,2)=Pnew_DL650(:,3);

level2=0.10;
P1=log10(P);
X2=(P1(:,1)-2.5)*200;
Y2=(P1(:,2)-0.5)*100;

dmap=cHistRecon(350,350,single(Y2),single(X2),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
figure;imshow(dmap,[]); hold on; axis xy

BW=im2bw(dmap,level2);
se=strel('disk',5);
BW=imclose(BW,se);

B=bwboundaries(BW);
B2=B{1};
plot(B2(:,2),B2(:,1),'b-');

%% CF680
P=zeros(length(Pnew_CF680),2);
P(:,1)=Pnew_CF680(:,1);
P(:,2)=Pnew_CF680(:,3);

level3=0.10;
P1=log10(P);
X3=(P1(:,1)-2.5)*200;
Y3=(P1(:,2)-0.5)*100;

dmap=cHistRecon(350,350,single(Y3),single(X3),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
figure;imshow(dmap,[]); hold on; axis xy

BW=im2bw(dmap,level3);
se=strel('disk',5);
BW=imclose(BW,se);

B=bwboundaries(BW);
B3=B{1};
plot(B3(:,2),B3(:,1),'b-');

%%
R=[];
V=[];
V(:,1)=X1;
V(:,2)=Y1;
ind=inpolygon(V(:,1),V(:,2),B1(:,2),B1(:,1));
R(1,1)=sum(ind)/length(ind);
ind=inpolygon(V(:,1),V(:,2),B2(:,2),B2(:,1));
R(1,2)=sum(ind)/length(ind);
ind=inpolygon(V(:,1),V(:,2),B3(:,2),B3(:,1));
R(1,3)=sum(ind)/length(ind);

V=[];
V(:,1)=X2;
V(:,2)=Y2;
ind=inpolygon(V(:,1),V(:,2),B1(:,2),B1(:,1));
R(2,1)=sum(ind)/length(ind);
ind=inpolygon(V(:,1),V(:,2),B2(:,2),B2(:,1));
R(2,2)=sum(ind)/length(ind);
ind=inpolygon(V(:,1),V(:,2),B3(:,2),B3(:,1));
R(2,3)=sum(ind)/length(ind);

V=[];
V(:,1)=X3;
V(:,2)=Y3;
ind=inpolygon(V(:,1),V(:,2),B1(:,2),B1(:,1));
R(3,1)=sum(ind)/length(ind);
ind=inpolygon(V(:,1),V(:,2),B2(:,2),B2(:,1));
R(3,2)=sum(ind)/length(ind);
ind=inpolygon(V(:,1),V(:,2),B3(:,2),B3(:,1));
R(3,3)=sum(ind)/length(ind);

R(1,4)=1-R(1,1)-R(1,2)-R(1,3);
R(2,4)=1-R(2,1)-R(2,2)-R(2,3);
R(3,4)=1-R(3,1)-R(3,2)-R(3,3);
R=R';

%%
Pall=cat(1,Pnew_DY634,Pnew_DL650,Pnew_CF680);
P=zeros(length(Pall),2);
P(:,1)=Pall(:,1);
P(:,2)=Pall(:,3);

P1=log10(P);
X4=(P1(:,1)-2.5)*200;
Y4=(P1(:,2)-0.5)*100;

dmap=cHistRecon(350,350,single(Y4),single(X4),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
figure;imshow(dmap,[]); hold on; axis xy
plot(B1(:,2),B1(:,1),'y-','linewidth',1.5);
plot(B2(:,2),B2(:,1),'m-','linewidth',1.5);
plot(B3(:,2),B3(:,1),'g-','linewidth',1.5);
fnames='E:\4Pi_Paper\crosstalk_three_color\three_color_intensity_bin_v2.jpg';
print(fnames,'-djpeg','-r300');



