%%
clc
mask=Iresult>300 & llresult<150 & CRLBresult(:,1)<0.3 & CRLBresult(:,2)<0.3;
mtc=(sxtot.^3./sytot-sytot.^3./sxtot)./40*2*pi;
maskmtc=mtc<pi&mtc>-pi &(sxtot+sytot)<6;
maskbg=bgresult<(median(bgresult)+2*std(bgresult))&bgresult>(median(bgresult)-2*std(bgresult));
% mask=mask&maskbg&maskmtc;
currx=xresult(mask);
curry=yresult(mask);
currt=tresult(mask); 
currzresult=zfresult(mask);
currI=Iresult(mask);
currcrlb=sqrt((CRLBresult(mask,1).^2+CRLBresult(mask,2).^2)/2);
currll=llresult(mask);
currbg=bgresult(mask);
currzcon=zangctrresult(mask);
currzaster=zast_err_result(mask);

currentfolder='F:\4Pi_two_color\2017-6-30\';
savename='Cell01';

xout=currx.*128;
yout=curry.*128;
zout=currzresult;

% tic
% [xout,yout,zout,shifts]=iPALM_driftcorrection_RedunLSv8(currx.*128,curry.*128,currzresult,currt,3000,0,1,1);
% toc
% save([currentfolder savename '_' '642' '_DCresult'],'xout','yout','zout','shifts');

%%
vutarax{1}=xout;
vutaray{1}=yout;
vutaraz{1}=zout;
vutarat{1}=currt;
vutaraI{1}=currI;
vutaracrlb{1}=currcrlb;
vutarall{1}=currll;
vutarabg{1}=currbg;
vutarazcon{1}=currzcon;
vutarazaster{1}=currzaster;

% [flag]=iPALM2vutarav2(currentfolder,[savename '_ll'],1,vutarax,vutaray,vutaraz,vutarat,vutaraI,vutaracrlb,vutarall,vutarabg,vutarazcon,vutarazaster);
% save([currentfolder savename '_' '642' 'v20_60'],'vutarax','vutaray','vutaraz','vutarat','vutarall','vutaraI','vutarabg','vutarazcon','vutaracrlb','vutarazaster');

%%
coords=[];
% coords(:,1)=vutarax{1}/10;
% coords(:,2)=vutaray{1}/10;
% coords(:,3)=vutarat{1};
coords(:,1)=vutarax/10;
coords(:,2)=vutaray/10;
zm=12.8;
szx=168*zm;
szy=168*zm;
im=cHistRecon(szx,szy,single(coords(:,1)),single(coords(:,2)),0);
gaussim=gaussf(im,[2 2]);
str1=([currentfolder savename '_dot.tif']);
str2=([currentfolder savename '_gauss.tif']);
writeim(im,str1,'tiff',1);
writeim(gaussim,str2,'tiff',1);

%%
% V=[];
% V(:,1)=vutarax{1}/128;
% V(:,2)=vutaray{1}/128;
% Z=vutaraz{1};
% segnum=ceil((max(Z)-min(Z))/10);
% [rch gch bch]=srhist_color(168,zm,V(:,1),V(:,2),Z,segnum);
% rchsm=gaussf(rch,1);
% gchsm=gaussf(gch,1);
% bchsm=gaussf(bch,1);
% max_chsm=max([ceil(max(rchsm)),ceil(max(gchsm)),ceil(max(bchsm))]);
% max_chsm=min(max_chsm,255);
% rchsmst=imstretch_linear(rchsm,0,max_chsm,0,255);
% gchsmst=imstretch_linear(gchsm,0,max_chsm,0,255);
% bchsmst=imstretch_linear(bchsm,0,max_chsm,0,255);
% colorim=joinchannels('RGB',rchsmst,gchsmst,bchsmst);
% str1=([currentfolder savename '_colorim.tif']);
% writeim(colorim,str1,'TIFF');
