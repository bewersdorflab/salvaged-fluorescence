%%
id=RT(:,2)>1;
sum(id)/length(id)

id=RT(:,2)>0.4 & RT(:,2)<0.7;
sum(id)/length(id)

id=RT(:,2)<0.20;
sum(id)/length(id)

%%
clc
% close all
PT=P;
ix=PT(:,2)>0;% & RT(:,1)<0.25;
P=log10(PT(ix,:));
X=(P(:,1)-2.2)*200;
Y=(P(:,2))*60;

dmap=cHistRecon(400,400,single(Y),single(X),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
figure;imshow(dmap,[]);
% dipshow(dmap);

%%
clc
close all
ix=PT(:,3)>0;
P=log10(PT(ix,:));
P1=PT(ix,:);
X=(P(:,1)-2.3)*200;
Y=(P(:,3))*60;

dmap=cHistRecon(300,300,single(Y),single(X),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
[CY,CX]=find(dmap==max(dmap(:)));
figure;imshow(dmap,[]); hold on; plot(CX,CY,'ro');

level=graythresh(dmap);
BW=im2bw(dmap,0.1);
se=strel('disk',5);
BW=imclose(BW,se);
% figure;imshow(BW);

B=bwboundaries(BW);
B=B{1};
plot(B(:,2),B(:,1),'b-');

V=[];
V(:,1)=X;
V(:,2)=Y;
ind=inpolygon(V(:,1),V(:,2),B(:,2),B(:,1));
sum(ind)/length(ind)

figure;plot(X,Y,'r.');
hold on;plot(B(:,2),B(:,1),'b-');

P2=P1(ind,:);
% Dist=sqrt((X-CX).^2+(Y-CY).^2);

% B_660=B;

%%
figure; hold on
B=B_635;
plot(B(:,2),B(:,1),'r-');
B=B_650;
plot(B(:,2),B(:,1),'b-');
B=B_660;
plot(B(:,2),B(:,1),'b-');

%%
clc
close all
ix=PT(:,3)>0;
P=log10(PT(ix,:));
X=(P(:,1)-2.3)*200;
Y=(P(:,3))*60;

B=B_650;
V=[];
V(:,1)=X;
V(:,2)=Y;
ind=inpolygon(V(:,1),V(:,2),B(:,2),B(:,1));
sum(ind)/length(ind)