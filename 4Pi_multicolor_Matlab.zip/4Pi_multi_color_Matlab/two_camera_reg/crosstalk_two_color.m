%%
clear
clc
str='E:\4Pi_Paper\crosstalk_two_color\two_color.mat';
load(str);
%% AF647
P=zeros(length(Pnew_AF647),2);
P(:,1)=Pnew_AF647(:,1);
P(:,2)=Pnew_AF647(:,3);

level1=0.01;
P1=log10(P);
X1=(P1(:,1)-2.5)*200;
Y1=(P1(:,2)-0.5)*100;

dmap=cHistRecon(350,350,single(Y1),single(X1),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
figure;imshow(dmap,[]); hold on; axis xy

BW=im2bw(dmap,level1);
se=strel('disk',5);
BW=imclose(BW,se);

B=bwboundaries(BW);
B1=B{1};
plot(B1(:,2),B1(:,1),'b-');

%% CF660C
P=zeros(length(Pnew_CF660C),2);
P(:,1)=Pnew_CF660C(:,1);
P(:,2)=Pnew_CF660C(:,3);

level2=0.01;
P1=log10(P);
X2=(P1(:,1)-2.5)*200;
Y2=(P1(:,2)-0.5)*100;

dmap=cHistRecon(350,350,single(Y2),single(X2),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
figure;imshow(dmap,[]); hold on; axis xy

BW=im2bw(dmap,level2);
se=strel('disk',5);
BW=imclose(BW,se);

B=bwboundaries(BW);
B2=B{1};
plot(B2(:,2),B2(:,1),'b-');

%%
R=[];
V=[];
V(:,1)=X1;
V(:,2)=Y1;
ind=inpolygon(V(:,1),V(:,2),B1(:,2),B1(:,1));
R(1,1)=sum(ind)/length(ind);
ind=inpolygon(V(:,1),V(:,2),B2(:,2),B2(:,1));
R(1,2)=sum(ind)/length(ind);

V=[];
V(:,1)=X2;
V(:,2)=Y2;
ind=inpolygon(V(:,1),V(:,2),B1(:,2),B1(:,1));
R(2,1)=sum(ind)/length(ind);
ind=inpolygon(V(:,1),V(:,2),B2(:,2),B2(:,1));
R(2,2)=sum(ind)/length(ind);

R(1,3)=1-R(1,1)-R(1,2);
R(2,3)=1-R(2,1)-R(2,2);
R=R';

%%
Pall=cat(1,Pnew_AF647(1:2827683,:),Pnew_CF660C);
P=zeros(length(Pall),2);
P(:,1)=Pall(:,1);
P(:,2)=Pall(:,3);

P1=log10(P);
X3=(P1(:,1)-2.5)*200;
Y3=(P1(:,2)-0.5)*100;

dmap=cHistRecon(350,350,single(Y3),single(X3),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
figure;imshow(dmap,[]); hold on; axis xy
plot(B1(:,2),B1(:,1),'g-','linewidth',1.5);
plot(B2(:,2),B2(:,1),'m-','linewidth',1.5);
% fnames='E:\4Pi_Paper\crosstalk_two_color\two_color_intensity_bin.jpg';
% print(fnames,'-djpeg','-r300');



