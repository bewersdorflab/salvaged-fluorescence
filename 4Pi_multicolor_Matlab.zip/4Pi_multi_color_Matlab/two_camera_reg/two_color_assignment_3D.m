%%
clc
mask=Iresult>500 & llresult<300 & CRLBresult(:,1)<0.30 & CRLBresult(:,2)<0.30 & PT(:,2)>0 & zfresult>200 & zfresult<1200 & zast_err_result<0.1;
mtc=(sxtot.^3./sytot-sytot.^3./sxtot)./40*2*pi;
maskmtc=mtc<pi&mtc>-pi &(sxtot+sytot)<6;
maskbg=bgresult<(median(bgresult)+2*std(bgresult))&bgresult>(median(bgresult)-2*std(bgresult));
mask=mask&maskbg&maskmtc;
currx=xresult(mask);
curry=yresult(mask);
currt=tresult(mask); 
currzresult=zfresult(mask);
currI=Iresult(mask);
currcrlb=sqrt((CRLBresult(mask,1).^2+CRLBresult(mask,2).^2)/2);
currll=llresult(mask);
currbg=bgresult(mask);
currzcon=zangctrresult(mask);
currzaster=zast_err_result(mask);
xout=currx.*128;
yout=curry.*128;
zout=currzresult;
P=PT(mask,:);
R=RT(mask,:);

currentfolder='E:\4Pi_two_color\2018-10-10\';
savename='Cell02';

% driftstr=[currentfolder savename '_drift.mat'];
% tic
% % [xout,yout,zout,shifts]=iPALM_driftcorrection_RedunLSv8(xout,yout,zout,currt,3000,0,1,0);
% [xout,yout,zout,shifts]=iPALM_driftcorrection_RedunLSv12(xout,yout,zout,currt,3000,1,driftstr);
% % [xout,yout,zout,shifts]=iPALM_driftcorrection_RedunLSv6(xout,yout,zout,currt,3000,0,1,driftstr);
% toc
% save([currentfolder savename '_DCresult_two_color'],'xout','yout','zout','shifts','mask');

%%
threshold1=0.1;
threshold2=0.2;
level1=0.1;
level2=0.1;

P0=log10(P);
ix=R(:,1)<threshold1;
P1=P0(ix,:);
X1=(P1(:,1)-2.2)*200;
Y1=(P1(:,2))*60;

dmap=cHistRecon(400,400,single(Y1),single(X1),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
figure;subplot(1,3,1);imshow(dmap,[]); hold on

BW=im2bw(dmap,level1);
se=strel('disk',5);
BW=imclose(BW,se);

B=bwboundaries(BW);
B1=B{1};
plot(B1(:,2),B1(:,1),'b-');

ix=R(:,1)>threshold2;
P1=P0(ix,:);
X1=(P1(:,1)-2.2)*200;
Y1=(P1(:,2))*60;

dmap=cHistRecon(400,400,single(Y1),single(X1),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
subplot(1,3,2);imshow(dmap,[]); hold on

BW=im2bw(dmap,level2);
se=strel('disk',5);
BW=imclose(BW,se);

B=bwboundaries(BW);
B2=B{1};
plot(B2(:,2),B2(:,1),'b-');

X=(P0(:,1)-2.2)*200;
Y=P0(:,2)*60;
dmap=cHistRecon(400,400,single(Y),single(X),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
subplot(1,3,3);imshow(dmap,[]); hold on; 
plot(B1(:,2),B1(:,1),'g-');
plot(B2(:,2),B2(:,1),'b-');
pause(1)

%%
tic
id1=inpolygon(X,Y,B1(:,2),B1(:,1));
id2=inpolygon(X,Y,B2(:,2),B2(:,1));
toc

%%
% [p1,s1,mu1]=polyfit(P0(id1,1),P0(id1,2),1);
% [p2,s2,mu2]=polyfit(P0(id2,1),P0(id2,2),1);
% [y1,d1]=polyval(p1,P0(:,1),s1,mu1);
% [y2,d2]=polyval(p2,P0(:,1),s2,mu2);
% e=[];
% e(:,1)=log10(P(:,2))-y1;
% e(:,2)=log10(P(:,2))-y2;
% ix=e(:,1)>0 & e(:,2)<0;
% e1=abs(e(ix,:));
% e1(:,3)=e1(:,1)+e1(:,2);
% e2=e1(:,1)./e1(:,3);

%%
% id1=R(:,1)<threshold1;
% id2=R(:,1)>threshold2;
vutarax{1}=xout(id1);
vutarax{2}=xout(id2);
vutaray{1}=yout(id1);
vutaray{2}=yout(id2);
vutaraz{1}=zout(id1);
vutaraz{2}=zout(id2);
vutarat{1}=currt(id1);
vutarat{2}=currt(id2);
vutaraI{1}=currI(id1);
vutaraI{2}=currI(id2);
vutaracrlb{1}=currcrlb(id1);
vutaracrlb{2}=currcrlb(id2);
vutarall{1}=currll(id1);
vutarall{2}=currll(id2);
vutarabg{1}=currbg(id1);
vutarabg{2}=currbg(id2);
vutarazcon{1}=currzcon(id1);
vutarazcon{2}=currzcon(id2);
vutarazaster{1}=currzaster(id1);
vutarazaster{2}=currzaster(id2);

%%
coords=[];
coords(:,1)=vutarax{1}/10;
coords(:,2)=vutaray{1}/10;
coords(:,3)=vutarat{1};
zm=12.8;
szx=168*zm;
szy=168*zm;
im=cHistRecon(szx,szy,single(coords(:,1)),single(coords(:,2)),0);
gaussim=gaussf(im,[1 1]);
% str1=([currentfolder savename '_dot_1.tif']);
str2=([currentfolder savename '_gauss_1.tif']);
% writeim(im,str1,'tiff',1);
writeim(gaussim,str2,'tiff',1);

coords=[];
coords(:,1)=vutarax{2}/10;
coords(:,2)=vutaray{2}/10;
coords(:,3)=vutarat{2};
zm=12.8;
szx=168*zm;
szy=168*zm;
im=cHistRecon(szx,szy,single(coords(:,1)),single(coords(:,2)),0);
gaussim=gaussf(im,[1 1]);
% str1=([currentfolder savename '_dot_2.tif']);
str2=([currentfolder savename '_gauss_2.tif']);
% writeim(im,str1,'tiff',1);
writeim(gaussim,str2,'tiff',1);

%%
% V=[];
% V(:,1)=vutarax{1}/128;
% V(:,2)=vutaray{1}/128;
% Z=vutaraz{1};
% segnum=ceil((max(Z)-min(Z))/10);
% [rch gch bch]=srhist_color(168,zm,V(:,1),V(:,2),Z,segnum);
% rchsm=gaussf(rch,1);
% gchsm=gaussf(gch,1);
% bchsm=gaussf(bch,1);
% max_chsm=max([ceil(max(rchsm)),ceil(max(gchsm)),ceil(max(bchsm))]);
% max_chsm=min(max_chsm,255);
% rchsmst=imstretch_linear(rchsm,0,max_chsm,0,255);
% gchsmst=imstretch_linear(gchsm,0,max_chsm,0,255);
% bchsmst=imstretch_linear(bchsm,0,max_chsm,0,255);
% colorim=joinchannels('RGB',rchsmst,gchsmst,bchsmst);
% str1=([currentfolder savename '_colorim_1.tif']);
% writeim(colorim,str1,'TIFF');
% 
% V=[];
% V(:,1)=vutarax{2}/128;
% V(:,2)=vutaray{2}/128;
% Z=vutaraz{2};
% segnum=ceil((max(Z)-min(Z))/10);
% [rch gch bch]=srhist_color(168,zm,V(:,1),V(:,2),Z,segnum);
% rchsm=gaussf(rch,1);
% gchsm=gaussf(gch,1);
% bchsm=gaussf(bch,1);
% max_chsm=max([ceil(max(rchsm)),ceil(max(gchsm)),ceil(max(bchsm))]);
% max_chsm=min(max_chsm,255);
% rchsmst=imstretch_linear(rchsm,0,max_chsm,0,255);
% gchsmst=imstretch_linear(gchsm,0,max_chsm,0,255);
% bchsmst=imstretch_linear(bchsm,0,max_chsm,0,255);
% colorim=joinchannels('RGB',rchsmst,gchsmst,bchsmst);
% str1=([currentfolder savename '_colorim_2.tif']);
% writeim(colorim,str1,'TIFF');

%%
save([currentfolder savename '_' '642' 'v20_60_two_color'],'vutarax','vutaray','vutaraz','vutarat','vutarall','vutaraI','vutarabg','vutarazcon','vutaracrlb','vutarazaster');
vutarat{1}=ceil(currt(id1)/100);
vutarat{2}=ceil(currt(id2)/100);
[flag]=iPALM2vutarav2(currentfolder,[savename '_ll'],2,vutarax,vutaray,vutaraz,vutarat,vutaraI,vutaracrlb,vutarall,vutarabg,vutarazcon,vutarazaster);
