%%
clc
clear
folder='E:\4Pi_Paper\chromatic_shift\three_color\';
files=dir([folder '*.mat']);

%%
R1=[];
R2=[];
R3=[];
for i=1:13
    i
    filename=[folder files(i).name];
    load(filename);
    mask1=vutarax{1}(:)>1000 & vutarax{1}(:)<21000 & vutaray{1}(:)>1000 & vutaray{1}(:)<21000 & vutaraz{1}(:)>-300 & vutaraz{1}(:)<300;
    mask2=vutarax{2}(:)>1000 & vutarax{2}(:)<21000 & vutaray{2}(:)>1000 & vutaray{2}(:)<21000 & vutaraz{2}(:)>-300 & vutaraz{2}(:)<300;
    mask3=vutarax{3}(:)>1000 & vutarax{3}(:)<21000 & vutaray{3}(:)>1000 & vutaray{3}(:)<21000 & vutaraz{3}(:)>-300 & vutaraz{3}(:)<300;
    vutarax{1}=vutarax{1}(mask1);
    vutaray{1}=vutaray{1}(mask1);
    vutaraz{1}=vutaraz{1}(mask1);
    vutarax{2}=vutarax{2}(mask2);
    vutaray{2}=vutaray{2}(mask2);
    vutaraz{2}=vutaraz{2}(mask2);
    vutarax{3}=vutarax{3}(mask3);
    vutaray{3}=vutaray{3}(mask3);
    vutaraz{3}=vutaraz{3}(mask3);
    
    xlin=cat(1,vutarax{1}(:),vutarax{2}(:),vutarax{3}(:));
    ylin=cat(1,vutaray{1}(:),vutaray{2}(:),vutaray{3}(:));
    zlin=cat(1,vutaraz{1}(:),vutaraz{2}(:),vutaraz{3}(:));
    minx=min(xlin);
    miny=min(ylin);
    minz=min(zlin);
    pixelsz=20;
    rndsz=2;
    x1=floor((xlin-minx)./pixelsz);
    x2=floor((ylin-miny)./pixelsz);
    x3=floor((zlin-minz)./pixelsz);
    x1sz=ceil(max(x1)/rndsz)*rndsz+1;
    x2sz=ceil(max(x2)/rndsz)*rndsz+1;
    x3sz=max(ceil(max(x3)/rndsz)*rndsz+1,21);
    x1_1=(vutarax{1}-minx)/pixelsz;
    x2_1=(vutaray{1}-miny)/pixelsz;
    x3_1=(vutaraz{1}-minz)/pixelsz;
    x1_2=(vutarax{2}-minx)/pixelsz;
    x2_2=(vutaray{2}-miny)/pixelsz;
    x3_2=(vutaraz{2}-minz)/pixelsz;
    x1_3=(vutarax{3}-minx)/pixelsz;
    x2_3=(vutaray{3}-miny)/pixelsz;
    x3_3=(vutaraz{3}-minz)/pixelsz;
    
    im1=cHistRecon3D(x1sz,x2sz,x3sz,single(x1_1),single(x2_1),single(x3_1),0);
    im2=cHistRecon3D(x1sz,x2sz,x3sz,single(x1_2),single(x2_2),single(x3_2),0);
    im3=cHistRecon3D(x1sz,x2sz,x3sz,single(x1_3),single(x2_3),single(x3_3),0);
    tic
    shiftvector1=findshift(single(gaussf(im1,1)),single(gaussf(im2,1)),'grs');
    shiftvector2=findshift(single(gaussf(im1,1)),single(gaussf(im3,1)),'grs');
    shiftvector3=findshift(single(gaussf(im2,1)),single(gaussf(im3,1)),'grs');
    toc
    shift1=shiftvector1'*pixelsz;
    shift2=shiftvector2'*pixelsz;
    shift3=shiftvector3'*pixelsz;
    R1(i,:)=shift1;
    R2(i,:)=shift2;
    R3(i,:)=shift3;
end
str=[folder,'shift_three_color_20nm_all.mat'];
save(str,'R1','R2','R3');

%%
A(:,1)=mean(abs(R1))';
A(:,2)=(std(abs(R1)))'/sqrt(13);
A(:,1)=mean(abs(R2))';
A(:,2)=(std(abs(R2)))'/sqrt(13);
A(:,1)=mean(abs(R3))';
A(:,2)=(std(abs(R3)))'/sqrt(13);

%%
R=[];
for i=1:13
    i
    filename=[folder files(i).name];
    load(filename);
    mask1=vutarax{1}(:)>1000 & vutarax{1}(:)<21000 & vutaray{1}(:)>1000 & vutaray{1}(:)<21000 & vutaraz{1}(:)>-300 & vutaraz{1}(:)<300;
    mask2=vutarax{3}(:)>1000 & vutarax{3}(:)<21000 & vutaray{3}(:)>1000 & vutaray{3}(:)<21000 & vutaraz{3}(:)>-300 & vutaraz{3}(:)<300;
    vutarax{1}=vutarax{1}(mask1);
    vutaray{1}=vutaray{1}(mask1);
    vutaraz{1}=vutaraz{1}(mask1);
    vutarax{3}=vutarax{3}(mask2);
    vutaray{3}=vutaray{3}(mask2);
    vutaraz{3}=vutaraz{3}(mask2);
    
    xlin=cat(1,vutarax{1}(:),vutarax{3}(:));
    ylin=cat(1,vutaray{1}(:),vutaray{3}(:));
    zlin=cat(1,vutaraz{1}(:),vutaraz{3}(:));
    minx=min(xlin);
    miny=min(ylin);
    minz=min(zlin);
    pixelsz=20;
    rndsz=2;
    x1=floor((xlin-minx)./pixelsz);
    x2=floor((ylin-miny)./pixelsz);
    x3=floor((zlin-minz)./pixelsz);
    x1sz=ceil(max(x1)/rndsz)*rndsz+1;
    x2sz=ceil(max(x2)/rndsz)*rndsz+1;
    x3sz=max(ceil(max(x3)/rndsz)*rndsz+1,21);
    x1_1=(vutarax{1}-minx)/pixelsz;
    x2_1=(vutaray{1}-miny)/pixelsz;
    x3_1=(vutaraz{1}-minz)/pixelsz;
    x1_2=(vutarax{3}-minx)/pixelsz;
    x2_2=(vutaray{3}-miny)/pixelsz;
    x3_2=(vutaraz{3}-minz)/pixelsz;
    
    im1=cHistRecon3D(x1sz,x2sz,x3sz,single(x1_1),single(x2_1),single(x3_1),0);
    im2=cHistRecon3D(x1sz,x2sz,x3sz,single(x1_2),single(x2_2),single(x3_2),0);
    tic
    shiftvector=findshift(single(gaussf(im2,1)),single(gaussf(im1,1)),'grs');
    toc
    shift=shiftvector'*pixelsz;
    R(i,:)=shift;
end
str=[folder,'shift_three_color_20.mat'];
save(str,'R');

%%
R=[];
for i=1:1
    i
    filename=[folder files(i).name];
    load(filename);
    mask1=vutarax{1}(:)>1000 & vutarax{1}(:)<21000 & vutaray{1}(:)>1000 & vutaray{1}(:)<21000 & vutaraz{1}(:)>-300 & vutaraz{1}(:)<300;
    mask2=vutarax{2}(:)>1000 & vutarax{2}(:)<21000 & vutaray{2}(:)>1000 & vutaray{2}(:)<21000 & vutaraz{2}(:)>-300 & vutaraz{2}(:)<300;
    vutarax{1}=vutarax{1}(mask1);
    vutaray{1}=vutaray{1}(mask1);
    vutaraz{1}=vutaraz{1}(mask1);
    vutarax{2}=vutarax{2}(mask2);
    vutaray{2}=vutaray{2}(mask2);
    vutaraz{2}=vutaraz{2}(mask2);
    
    xlin=cat(1,vutarax{1}(:),vutarax{2}(:));
    ylin=cat(1,vutaray{1}(:),vutaray{2}(:));
    zlin=cat(1,vutaraz{1}(:),vutaraz{2}(:));
    minx=min(xlin);
    miny=min(ylin);
    minz=min(zlin);
    pixelsz=20;
    rndsz=2;
    x1=floor((xlin-minx)./pixelsz);
    x2=floor((ylin-miny)./pixelsz);
    x3=floor((zlin-minz)./pixelsz);
    x1sz=ceil(max(x1)/rndsz)*rndsz+1;
    x2sz=ceil(max(x2)/rndsz)*rndsz+1;
    x3sz=max(ceil(max(x3)/rndsz)*rndsz+1,21);
    x1_1=(vutarax{1}-minx)/pixelsz;
    x2_1=(vutaray{1}-miny)/pixelsz;
    x3_1=(vutaraz{1}-minz)/pixelsz;
    x1_2=(vutarax{2}-minx)/pixelsz;
    x2_2=(vutaray{2}-miny)/pixelsz;
    x3_2=(vutaraz{2}-minz)/pixelsz;
    
    im1=cHistRecon3D(x1sz,x2sz,x3sz,single(x1_1),single(x2_1),single(x3_1),0);
    im2=cHistRecon3D(x1sz,x2sz,x3sz,single(x1_2),single(x2_2),single(x3_2),0);
    tic
    shiftvector=findshift(single(gaussf(im2,1)),single(gaussf(im1,1)),'grs');
    toc
    shift=shiftvector'*pixelsz;
    R(i,:)=shift;
end
str=[folder,'shift_three_color_20nm_1vs2.mat'];
save(str,'R');

%%
R=[];
for i=1:1
    i
    filename=[folder files(i).name];
    load(filename);
    mask1=vutarax{2}(:)>1000 & vutarax{2}(:)<21000 & vutaray{2}(:)>1000 & vutaray{2}(:)<21000 & vutaraz{2}(:)>-300 & vutaraz{2}(:)<300;
    mask2=vutarax{3}(:)>1000 & vutarax{3}(:)<21000 & vutaray{3}(:)>1000 & vutaray{3}(:)<21000 & vutaraz{3}(:)>-300 & vutaraz{3}(:)<300;
    vutarax{2}=vutarax{2}(mask1);
    vutaray{2}=vutaray{2}(mask1);
    vutaraz{2}=vutaraz{2}(mask1);
    vutarax{3}=vutarax{3}(mask2);
    vutaray{3}=vutaray{3}(mask2);
    vutaraz{3}=vutaraz{3}(mask2);
    
    xlin=cat(1,vutarax{2}(:),vutarax{3}(:));
    ylin=cat(1,vutaray{2}(:),vutaray{3}(:));
    zlin=cat(1,vutaraz{2}(:),vutaraz{3}(:));
    minx=min(xlin);
    miny=min(ylin);
    minz=min(zlin);
    pixelsz=20;
    rndsz=2;
    x1=floor((xlin-minx)./pixelsz);
    x2=floor((ylin-miny)./pixelsz);
    x3=floor((zlin-minz)./pixelsz);
    x1sz=ceil(max(x1)/rndsz)*rndsz+1;
    x2sz=ceil(max(x2)/rndsz)*rndsz+1;
    x3sz=max(ceil(max(x3)/rndsz)*rndsz+1,21);
    x1_1=(vutarax{2}-minx)/pixelsz;
    x2_1=(vutaray{2}-miny)/pixelsz;
    x3_1=(vutaraz{2}-minz)/pixelsz;
    x1_2=(vutarax{3}-minx)/pixelsz;
    x2_2=(vutaray{3}-miny)/pixelsz;
    x3_2=(vutaraz{3}-minz)/pixelsz;
    
    im1=cHistRecon3D(x1sz,x2sz,x3sz,single(x1_1),single(x2_1),single(x3_1),0);
    im2=cHistRecon3D(x1sz,x2sz,x3sz,single(x1_2),single(x2_2),single(x3_2),0);
    tic
    shiftvector=findshift(single(gaussf(im2,1)),single(gaussf(im1,1)),'grs');
    toc
    shift=shiftvector'*pixelsz;
    R(i,:)=shift;
end
str=[folder,'shift_three_color_20nm_2vs3.mat'];
save(str,'R');


