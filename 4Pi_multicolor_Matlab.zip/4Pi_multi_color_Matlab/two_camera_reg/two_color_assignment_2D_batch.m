clear
clc
currentfolder='F:\4Pi_two_color\2018-2-23\';
ID=[3,4];
for tt=1:length(ID)
    tt
    close all
    str=strcat(currentfolder,['Cell',num2str(ID(tt),'%02d'),'_642_tmpresult_20180223.mat'])
    load(str);
    str=strcat(currentfolder,['Cell',num2str(ID(tt),'%02d'),'_ratio.mat'])
    load(str);
    savename=['Cell',num2str(ID(tt),'%02d')];
    
    mask=Iresult>500 & llresult<300 & CRLBresult(:,1)<0.2 & CRLBresult(:,2)<0.2 & PT(:,2)>0;
    % maskbg=bgresult<(median(bgresult)+2*std(bgresult))&bgresult>(median(bgresult)-2*std(bgresult));
    % mask=mask&maskbg;
    currx=xresult(mask);
    curry=yresult(mask);
    currt=tresult(mask);
    currzresult=zfresult(mask);
    currI=Iresult(mask);
    currcrlb=sqrt((CRLBresult(mask,1).^2+CRLBresult(mask,2).^2)/2);
    currll=llresult(mask);
    currbg=bgresult(mask);
    currzcon=zangctrresult(mask);
    currzaster=zast_err_result(mask);
    xout=currx.*128;
    yout=curry.*128;
    zout=currzresult;
    Pnew=PT(mask,:);
    Rnew=RT(mask,:)*2;
    
%     tic
%     [xout,yout,zout,shifts]=iPALM_driftcorrection_RedunLSv8(xout,yout,zout,currt,3000,0,0,0);
%     toc
%     save([currentfolder savename '_' '642' '_DCresult'],'xout','yout','zout','shifts','mask');
    
    %%
    P=zeros(length(Pnew),2);
    R=zeros(length(Rnew),1);
    P(:,1)=Pnew(:,1);
    P(:,2)=Pnew(:,2);
    R(:,1)=Rnew(:,1);
    
    threshold1=0.12;
    threshold2=0.25;
    level1=0.2;
    level2=0.2;
    
    P0=log10(P);
    ix=R(:,1)<threshold1;
    P1=P0(ix,:);
    X1=(P1(:,1)-2.2)*200;
    Y1=(P1(:,2))*60;
    
    dmap=cHistRecon(400,400,single(Y1),single(X1),0);
    dmap=double(gaussf(dmap,2));
    dmap=dmap/max(dmap(:));
    figure;subplot(1,3,1);imshow(dmap,[]); hold on
    
    BW=im2bw(dmap,level1);
    se=strel('disk',5);
    BW=imclose(BW,se);
    
    B=bwboundaries(BW);
    B1=B{1};
    plot(B1(:,2),B1(:,1),'b-');
    
    ix=R(:,1)>threshold2;
    P1=P0(ix,:);
    X1=(P1(:,1)-2.2)*200;
    Y1=(P1(:,2))*60;
    
    dmap=cHistRecon(400,400,single(Y1),single(X1),0);
    dmap=double(gaussf(dmap,2));
    dmap=dmap/max(dmap(:));
    subplot(1,3,2);imshow(dmap,[]); hold on
    
    BW=im2bw(dmap,level2);
    se=strel('disk',5);
    BW=imclose(BW,se);
    
    B=bwboundaries(BW);
    B2=B{1};
    plot(B2(:,2),B2(:,1),'b-');
    
    X=(P0(:,1)-2.2)*200;
    Y=P0(:,2)*60;
    dmap=cHistRecon(400,400,single(Y),single(X),0);
    dmap=double(gaussf(dmap,2));
    dmap=dmap/max(dmap(:));
    subplot(1,3,3);imshow(dmap,[]); hold on;
    plot(B1(:,2),B1(:,1),'g-');
    plot(B2(:,2),B2(:,1),'b-');
    pause(1)
    
    %%
    tic
    id1=inpolygon(X,Y,B1(:,2),B1(:,1));
    id2=inpolygon(X,Y,B2(:,2),B2(:,1));
    toc
    
    %%
    % [p1,s1,mu1]=polyfit(P0(id1,1),P0(id1,2),1);
    % [p2,s2,mu2]=polyfit(P0(id2,1),P0(id2,2),1);
    % [y1,d1]=polyval(p1,P0(:,1),s1,mu1);
    % [y2,d2]=polyval(p2,P0(:,1),s2,mu2);
    % e=[];
    % e(:,1)=log10(P(:,2))-y1;
    % e(:,2)=log10(P(:,2))-y2;
    % % ix=e(:,1)>0 & e(:,2)<0;
    % % e1=abs(e(ix,:));
    % % e1(:,3)=e1(:,1)+e1(:,2);
    % % e2=e1(:,1)./e1(:,3);
    
    %%
%     id1=R(:,1)<threshold1;
%     id2=R(:,1)>threshold2;
    vutarax{1}=xout(id1);
    vutarax{2}=xout(id2);
    vutaray{1}=yout(id1);
    vutaray{2}=yout(id2);
    vutaraz{1}=zout(id1);
    vutaraz{2}=zout(id2);
    vutarat{1}=currt(id1);
    vutarat{2}=currt(id2);
    vutaraI{1}=currI(id1);
    vutaraI{2}=currI(id2);
    vutaracrlb{1}=currcrlb(id1);
    vutaracrlb{2}=currcrlb(id2);
    vutarall{1}=currll(id1);
    vutarall{2}=currll(id2);
    vutarabg{1}=currbg(id1);
    vutarabg{2}=currbg(id2);
    vutarazcon{1}=currzcon(id1);
    vutarazcon{2}=currzcon(id2);
    vutarazaster{1}=currzaster(id1);
    vutarazaster{2}=currzaster(id2);
    
    % [flag]=iPALM2vutarav2(currentfolder,[savename '_ll'],2,vutarax,vutaray,vutaraz,vutarat,vutaraI,vutaracrlb,vutarall,vutarabg,vutarazcon,vutarazaster);
    % save([currentfolder savename '_' '642' 'v20_60_two_color'],'vutarax','vutaray','vutaraz','vutarat','vutarall','vutaraI','vutarabg','vutarazcon','vutaracrlb','vutarazaster');
    
    %%
    coords=[];
    coords(:,1)=vutarax{1}/10;
    coords(:,2)=vutaray{1}/10;
    coords(:,3)=vutarat{1};
    zm=12.8;
    szx=168*zm;
    szy=168*zm;
    im=cHistRecon(szx,szy,single(coords(:,1)),single(coords(:,2)),0);
    gaussim=gaussf(im,[1 1]);
    str1=([currentfolder savename '_dot_1.tif']);
    str2=([currentfolder savename '_gauss_1.tif']);
    writeim(im,str1,'tiff',1);
    writeim(gaussim,str2,'tiff',1);
    
    coords=[];
    coords(:,1)=vutarax{2}/10;
    coords(:,2)=vutaray{2}/10;
    coords(:,3)=vutarat{2};
    zm=12.8;
    szx=168*zm;
    szy=168*zm;
    im=cHistRecon(szx,szy,single(coords(:,1)),single(coords(:,2)),0);
    gaussim=gaussf(im,[1 1]);
    str1=([currentfolder savename '_dot_2.tif']);
    str2=([currentfolder savename '_gauss_2.tif']);
    writeim(im,str1,'tiff',1);
    writeim(gaussim,str2,'tiff',1);

end