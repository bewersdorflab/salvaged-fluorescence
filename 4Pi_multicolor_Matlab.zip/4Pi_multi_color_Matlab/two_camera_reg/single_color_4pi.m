clc
mask=vutarall<300 & vutarazerr<60 & vutarax>4000 & vutarax<17000 & vutaray>3000 & vutaray<20000 & vutaraz>-200 & vutaraz<400; 
% mask=P(:,2)>0;
% P=P(mask,:);
% R=R(mask,:);
% mask=ones(length(vutarax),1)>0;
xout=vutarax(mask);
yout=vutaray(mask);
zout=vutaraz(mask);
currt=vutarat(mask); 
currI=vutaraI(mask);
currcrlb=vutaracrlb(mask);
currll=vutarall(mask);
currbg=vutarabg(mask);
currzcon=vutarazcon(mask);
currzerr=vutarazerr(mask);

currentfolder='F:\4Pi_two_color\2017-10-4\';
savename='Cell06_JR';

% drift3d_flag=0;
% frmnum=3000;
% tic
% if drift3d_flag==1
%     mask1=xout>1000&xout<19000&yout>1000&yout<19000;
%     xout1=xout(mask1);
%     yout1=yout(mask1);
%     zout1=zout(mask1);
%     currt1=currt(mask1);
%     [xout1,yout1,zout1,shifts]=iPALM_driftcorrection_RedunLSv7_3d(single(xout1),single(yout1),single(zout1),currt1,frmnum,0);
%     [xout]=shiftcoords_LSv2(xout,shifts(:,1),currt,frmnum,0,0);
%     [yout]=shiftcoords_LSv2(yout,shifts(:,2),currt,frmnum,0,0);
%     [zout]=shiftcoords_LSv2(zout,shifts(:,3),currt,frmnum,0,0);
% else
%     [xout,yout,zout,shifts]=iPALM_driftcorrection_RedunLSv8(xout,yout,zout,currt,frmnum,0,1,0);
% end
% toc
x=xout;
y=yout;
z=zout;
frame=currt;
p.drift_timepointsz=70;
p.zrange=[-200 400];
drift=driftcorrection3D_so(x,y,z,frame,p);
pos.xnm=x;
pos.ynm=y;
pos.znm=z;
pos.frame=frame;
poso=applydriftcorrection(drift,pos);
xout=poso.xnm;
yout=poso.ynm;
zout=poso.znm;
save([currentfolder savename '_DCresult'],'xout','yout','zout','drift');

%%
vutarax=[];
vutaray=[];
vutaraz=[];
vutarat=[];
vutaraI=[];
vutaracrlb=[];
vutarall=[];
vutarabg=[];
vutarazcon=[];
vutarazerr=[];
vutarax{1}=xout;
vutaray{1}=yout;
vutaraz{1}=zout;
vutarat{1}=ceil(currt/100);
vutaraI{1}=currI;
vutaracrlb{1}=currcrlb;
vutarall{1}=currll;
vutarabg{1}=currbg;
vutarazcon{1}=currzcon;
vutarazerr{1}=currzerr;
[flag]=iPALM2vutarav2(currentfolder,[savename '_ll'],1,vutarax,vutaray,vutaraz,vutarat,vutaraI,vutaracrlb,vutarall,vutarabg,vutarazcon,vutarazerr);
save([currentfolder savename '_' '642' 'v20_60'],'vutarax','vutaray','vutaraz','vutarat','vutarall','vutaraI','vutarabg','vutarazcon','vutaracrlb','vutarazerr');