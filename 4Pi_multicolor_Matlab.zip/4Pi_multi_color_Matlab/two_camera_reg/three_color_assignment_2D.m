%%
clc
mask=Iresult>500 & llresult<300 & CRLBresult(:,1)<0.3 & CRLBresult(:,2)<0.3 & PT(:,2)>0 & PT(:,3)>0;
% maskbg=bgresult<(median(bgresult)+2*std(bgresult))&bgresult>(median(bgresult)-2*std(bgresult));
% mask=mask&maskbg;
currx=xresult(mask);
curry=yresult(mask);
currt=tresult(mask); 
currzresult=zfresult(mask);
currI=Iresult(mask);
currcrlb=sqrt((CRLBresult(mask,1).^2+CRLBresult(mask,2).^2)/2);
currll=llresult(mask);
currbg=bgresult(mask);
currzcon=zangctrresult(mask);
currzaster=zast_err_result(mask);
xout=currx.*128;
yout=curry.*128;
zout=currzresult;
Pnew=PT(mask,:);
Rnew=RT(mask,:);

currentfolder='E:\4Pi_two_color\2018-2-28\';
savename='Cell08';

% tic
% [xout,yout,zout,shifts]=iPALM_driftcorrection_RedunLSv8(xout,yout,zout,currt,3000,0,0,0);
% toc
% save([currentfolder savename '_DCresult'],'xout','yout','zout','shifts','mask');

%%
P=zeros(length(Pnew),2);
R=zeros(length(Rnew),1);
P(:,1)=Pnew(:,1);
P(:,2)=Pnew(:,2);
R(:,1)=Rnew(:,1);

threshold1=0.05;
threshold2=0.10;
threshold3=0.20;
threshold4=0.40;
level1=0.15;
level2=0.25;
level3=0.15;

ix=R(:,1)<threshold1 & P(:,2)<80 & P(:,2)>1;
P1=log10(P(ix,:));
X1=(P1(:,1)-2.2)*200;
Y1=(P1(:,2))*60;

dmap=cHistRecon(400,400,single(Y1),single(X1),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
figure;subplot(2,2,1);imshow(dmap,[]); hold on

BW=im2bw(dmap,level1);
se=strel('disk',5);
BW=imclose(BW,se);

B=bwboundaries(BW);
B1=B{1};
plot(B1(:,2),B1(:,1),'r-');

ix=R(:,1)>threshold2 & R(:,1)<threshold3;
P1=log10(P(ix,:));
X1=(P1(:,1)-2.2)*200;
Y1=(P1(:,2))*60;

dmap=cHistRecon(400,400,single(Y1),single(X1),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
subplot(2,2,2);imshow(dmap,[]); hold on

BW=im2bw(dmap,level2);
se=strel('disk',5);
BW=imclose(BW,se);

B=bwboundaries(BW);
B2=B{1};
plot(B2(:,2),B2(:,1),'g-');

ix=R(:,1)>threshold4;
P1=log10(P(ix,:));
X1=(P1(:,1)-2.2)*200;
Y1=(P1(:,2))*60;

dmap=cHistRecon(400,400,single(Y1),single(X1),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
subplot(2,2,3);imshow(dmap,[]); hold on

BW=im2bw(dmap,level3);
se=strel('disk',5);
BW=imclose(BW,se);

B=bwboundaries(BW);
B3=B{1};
plot(B3(:,2),B3(:,1),'b-');

X=(log10(P(:,1))-2.2)*200;
Y=(log10(P(:,2)))*60;
dmap=cHistRecon(400,400,single(Y),single(X),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
subplot(2,2,4);imshow(dmap,[]); hold on; 
plot(B1(:,2),B1(:,1),'r-');
plot(B2(:,2),B2(:,1),'g-');
plot(B3(:,2),B3(:,1),'b-');
pause(1)

%%
tic
id1=inpolygon(X,Y,B1(:,2),B1(:,1));
id2=inpolygon(X,Y,B2(:,2),B2(:,1));
id3=inpolygon(X,Y,B3(:,2),B3(:,1));
toc
%%
% id1=R(:,2)<threshold1;
% id2=R(:,2)>threshold2 & R(:,2)<threshold3;
% id3=R(:,2)>threshold4;
vutarax{1}=xout(id1);
vutarax{2}=xout(id2);
vutarax{3}=xout(id3);
vutaray{1}=yout(id1);
vutaray{2}=yout(id2);
vutaray{3}=yout(id3);
vutaraz{1}=zout(id1);
vutaraz{2}=zout(id2);
vutaraz{3}=zout(id3);
vutarat{1}=currt(id1);
vutarat{2}=currt(id2);
vutarat{3}=currt(id3);
vutaraI{1}=currI(id1);
vutaraI{2}=currI(id2);
vutaraI{3}=currI(id3);
vutaracrlb{1}=currcrlb(id1);
vutaracrlb{2}=currcrlb(id2);
vutaracrlb{3}=currcrlb(id3);
vutarall{1}=currll(id1);
vutarall{2}=currll(id2);
vutarall{3}=currll(id3);
vutarabg{1}=currbg(id1);
vutarabg{2}=currbg(id2);
vutarabg{3}=currbg(id3);
vutarazcon{1}=currzcon(id1);
vutarazcon{2}=currzcon(id2);
vutarazcon{3}=currzcon(id3);
vutarazaster{1}=currzaster(id1);
vutarazaster{2}=currzaster(id2);
vutarazaster{3}=currzaster(id3);

% [flag]=iPALM2vutarav2(currentfolder,[savename '_ll'],2,vutarax,vutaray,vutaraz,vutarat,vutaraI,vutaracrlb,vutarall,vutarabg,vutarazcon,vutarazaster);
% save([currentfolder savename '_' '642' 'v20_60_three_color'],'vutarax','vutaray','vutaraz','vutarat','vutarall','vutaraI','vutarabg','vutarazcon','vutaracrlb','vutarazaster');

coords=[];
coords(:,1)=vutarax{1}/10;
coords(:,2)=vutaray{1}/10;
coords(:,3)=vutarat{1};
zm=12.8;
szx=168*zm;
szy=168*zm;
im=cHistRecon(szx,szy,single(coords(:,1)),single(coords(:,2)),0);
gaussim=gaussf(im,[1 1]);
str1=([currentfolder savename '_dot_1.tif']);
str2=([currentfolder savename '_gauss_1.tif']);
writeim(im,str1,'tiff',1);
writeim(gaussim,str2,'tiff',1);

coords=[];
coords(:,1)=vutarax{2}/10;
coords(:,2)=vutaray{2}/10;
coords(:,3)=vutarat{2};
zm=12.8;
szx=168*zm;
szy=168*zm;
im=cHistRecon(szx,szy,single(coords(:,1)),single(coords(:,2)),0);
gaussim=gaussf(im,[1 1]);
str1=([currentfolder savename '_dot_2.tif']);
str2=([currentfolder savename '_gauss_2.tif']);
writeim(im,str1,'tiff',1);
writeim(gaussim,str2,'tiff',1);

coords=[];
coords(:,1)=vutarax{3}/10;
coords(:,2)=vutaray{3}/10;
coords(:,3)=vutarat{3};
zm=12.8;
szx=168*zm;
szy=168*zm;
im=cHistRecon(szx,szy,single(coords(:,1)),single(coords(:,2)),0);
gaussim=gaussf(im,[1 1]);
str1=([currentfolder savename '_dot_3.tif']);
str2=([currentfolder savename '_gauss_3.tif']);
writeim(im,str1,'tiff',1);
writeim(gaussim,str2,'tiff',1);