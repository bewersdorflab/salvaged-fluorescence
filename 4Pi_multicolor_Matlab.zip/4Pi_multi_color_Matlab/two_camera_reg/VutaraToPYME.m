n1=length(vutarax{1});
n2=length(vutarax{2});

x(1:n1,1)=vutarax{1};
x(n1+1:n1+n2,1)=vutarax{2};
y(1:n1,1)=vutaray{1};
y(n1+1:n1+n2,1)=vutaray{2};
z(1:n1,1)=vutaraz{1};
z(n1+1:n1+n2,1)=vutaraz{2};
error_x(1:n1,1)=vutaracrlb{1}*128/sqrt(2);
error_x(n1+1:n1+n2,1)=vutaracrlb{2}*128/sqrt(2);
error_y=error_x;
A(1:n1,1)=vutaraI{1};
A(n1+1:n1+n2,1)=vutaraI{2};
probe(1:n1,1)=0;
probe(n1+1:n1+n2,1)=1;

LLH(1:n1,1)=vutarall{1};
LLH(n1+1:n1+n2,1)=vutarall{2};
t(1:n1,1)=vutarat{1};
t(n1+1:n1+n2,1)=vutarat{2};
zcon(1:n1,1)=vutarazcon{1};
zcon(n1+1:n1+n2,1)=vutarazcon{2};
error_z(1:n1,1)=vutarazerr{1};
error_z(n1+1:n1+n2,1)=vutarazerr{2};

data=[A,x,y,z,error_x,error_y,error_z,probe,LLH,zcon];

filestr='E:\EMCCD\20170408\Cell04.mat';
save(filestr,'data');