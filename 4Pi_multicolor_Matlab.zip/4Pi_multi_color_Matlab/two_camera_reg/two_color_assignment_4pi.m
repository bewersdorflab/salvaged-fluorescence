%%
% vutaraz={};
% st=length(zout{1,1})+length(zout{1,2})++length(zout{1,3});
% et=length(zout{1,1})+length(zout{1,2})+length(zout{1,3})+length(zout{1,4});
% vutaraz=cat(1,zout{1,1},zout{1,2},zout{1,3},zout{1,4});
%%
clc
P0=PT(vutarapr,:);
R0=RT(vutarapr,:);
mask=vutarall<300 & vutarazerr<60 & P0(:,2)>0 & P0(:,3)>0;% & vutarax>4000 & vutarax<16000 & vutaray>2000 & vutaray<14000;% & vutaraz>-300 & vutaraz<200;% & vutarat>3000; 
% mask=P(:,2)>0;
Pnew=P0(mask,:);
Rnew=R0(mask,:);
% mask=ones(length(vutarax),1)>0;
xout=vutarax(mask);
yout=vutaray(mask);
zout=vutaraz(mask);
currt=vutarat(mask); 
currI=vutaraI(mask);
currcrlb=vutaracrlb(mask);
currll=vutarall(mask);
currbg=vutarabg(mask);
currzcon=vutarazcon(mask);
currzerr=vutarazerr(mask);

% ID=(1:length(xout))';
% id=ID>st&ID<et;
% Pnew=Pnew(id,:);
% Rnew=Rnew(id,:);
% % mask=ones(length(vutarax),1)>0;
% xout=xout(id);
% yout=yout(id);
% zout=zout(id);
% currt=currt(id); 
% currI=currI(id);
% currcrlb=currcrlb(id);
% currll=currll(id);
% currbg=currbg(id);
% currzcon=currzcon(id);
% currzerr=currzerr(id);
% 
currentfolder='E:\4Pi_two_color\2019-3-17\';
savename='Cell04';

%%

% [zout,shifts]=iPALM_driftcorrection_RedunLSv9(xout,zout,currt,3000,0);

% drift3d_flag=0;
% frmnum=3000;
% if drift3d_flag
%     mask1=xout>1000&xout<19000&yout>1000&yout<19000;
%     xout1=xout(mask1);
%     yout1=yout(mask1);
%     zout1=zout(mask1);
%     currt1=currt(mask1);
%     [xout1,yout1,zout1,shifts]=iPALM_driftcorrection_RedunLSv7_3d(single(xout1),single(yout1),single(zout1),currt1,frmnum,0);
%     [xout]=shiftcoords_LSv2(xout,shifts(:,1),currt,frmnum,0,0);
%     [yout]=shiftcoords_LSv2(yout,shifts(:,2),currt,frmnum,0,0);
%     [zout]=shiftcoords_LSv2(zout,shifts(:,3),currt,frmnum,0,0);
% else
%     [xout,yout,zout,shifts]=iPALM_driftcorrection_RedunLSv8(xout,yout,zout,currt,frmnum,0,1,0);
% end

% tic
% frmnum=3000;
% [zout,shifts]=iPALM_driftcorrection_RedunLSv9(xout,zout,currt,frmnum,0);
% toc

% frmnum=3000;
% x=xout;
% y=yout;
% z=zout;
% frame=currt;
% p.framestart=0;
% p.framestop=ceil((max(frame)/frmnum))*frmnum-1;
% points=ceil((max(frame)/frmnum));
% p.correctxy=false;
% p.drift_timepoints=points;
% p.correctz=true;
% p.drift_timepointsz=points;
% p.zrange=[min(z) max(z)];
% [drift,driftinfo,fieldc]=driftcorrection3D_so(x,y,z,frame,p);
% shiftz=driftinfo.z.dz;
% shiftz=diff(shiftz);
% [zout]=shiftcoords_LS(zout,shiftz,currt,frmnum,0);
% shifts=shiftz;
% 
% save([currentfolder savename '_DCresult_two_color'],'xout','yout','zout','shifts');

%%
P=zeros(length(Pnew),2);
R=zeros(length(Rnew),1);
P(:,1)=Pnew(:,1);
P(:,2)=Pnew(:,3);
R(:,1)=Rnew(:,2);

threshold1=0.10;
threshold2=0.10;
level1=0.05;
level2=0.05;

ix=R(:,1)<threshold1;
P1=log10(P(ix,:));
X1=(P1(:,1)-2.2)*200;
Y1=(P1(:,2))*60;

dmap=cHistRecon(400,400,single(Y1),single(X1),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
figure;subplot(1,3,1);imshow(dmap,[]); hold on

BW=im2bw(dmap,level1);
se=strel('disk',10);
BW=imclose(BW,se);

B=bwboundaries(BW);
B1=B{1};
plot(B1(:,2),B1(:,1),'b-');

ix=R(:,1)>threshold2;
P1=log10(P(ix,:));
X1=(P1(:,1)-2.2)*200;
Y1=(P1(:,2))*60;

dmap=cHistRecon(400,400,single(Y1),single(X1),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
subplot(1,3,2);imshow(dmap,[]); hold on

BW=im2bw(dmap,level2);
se=strel('disk',5);
BW=imclose(BW,se);

B=bwboundaries(BW);
B2=B{1};
plot(B2(:,2),B2(:,1),'b-');

X=(log10(P(:,1))-2.2)*200;
Y=(log10(P(:,2)))*60;
dmap=cHistRecon(400,400,single(Y),single(X),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
subplot(1,3,3);imshow(dmap,[]); hold on; 
plot(B1(:,2),B1(:,1),'g-');
plot(B2(:,2),B2(:,1),'b-');
pause(1)

%%
tic
id1=inpolygon(X,Y,B1(:,2),B1(:,1));
id2=inpolygon(X,Y,B2(:,2),B2(:,1));
toc

%%
% P0=log10(P);
% [p1,s1,mu1]=polyfit(P0(id1,1),P0(id1,2),1);
% [p2,s2,mu2]=polyfit(P0(id2,1),P0(id2,2),1);
% [y1,d1]=polyval(p1,P0(:,1),s1,mu1);
% [y2,d2]=polyval(p2,P0(:,1),s2,mu2);
% e=[];
% e(:,1)=log10(P(:,2))-y1;
% e(:,2)=log10(P(:,2))-y2;
% ix=e(:,1)>0 & e(:,2)<0;
% e1=abs(e(ix,:));
% e1(:,3)=e1(:,1)+e1(:,2);
% e2=e1(:,1)./e1(:,3);

%%
% id1=R(:,1)<threshold1;
% id2=R(:,1)>threshold2;
vutarax=[];
vutaray=[];
vutaraz=[];
vutarat=[];
vutaraI=[];
vutaracrlb=[];
vutarall=[];
vutarabg=[];
vutarazcon=[];
vutarazerr=[];
vutarax{1}=xout(id1);
vutarax{2}=xout(id2);
vutaray{1}=yout(id1);
vutaray{2}=yout(id2);
vutaraz{1}=zout(id1);
vutaraz{2}=zout(id2);
vutarat{1}=currt(id1);
vutarat{2}=currt(id2);
vutaraI{1}=currI(id1);
vutaraI{2}=currI(id2);
vutaracrlb{1}=currcrlb(id1);
vutaracrlb{2}=currcrlb(id2);
vutarall{1}=currll(id1);
vutarall{2}=currll(id2);
vutarabg{1}=currbg(id1);
vutarabg{2}=currbg(id2);
vutarazcon{1}=currzcon(id1);
vutarazcon{2}=currzcon(id2);
vutarazerr{1}=currzerr(id1);
vutarazerr{2}=currzerr(id2);

%%
% frmnum=3000;
% zout1=vutaraz{1};
% currt1=vutarat{1};
% x=vutarax{1};
% y=vutaray{1};
% z=vutaraz{1};
% % frame=vutarat{1};
% % p.framestart=0;
% % p.framestop=ceil((max(frame)/frmnum))*frmnum-1;
% % points=ceil((max(frame)/frmnum));
% % p.correctxy=false;
% % p.drift_timepoints=points;
% % p.correctz=true;
% % p.drift_timepointsz=points;
% % p.zrange=[min(z) max(z)];
% % [drift,driftinfo,fieldc]=driftcorrection3D_so(x,y,z,frame,p);
% % shiftz1=driftinfo.z.dz;
% % shiftz1=diff(shiftz1);
% % [zout1]=shiftcoords_LS(zout1,shiftz1,currt1,frmnum,0);
% [zout1,shiftz1]=iPALM_driftcorrection_RedunLSv9(x,z,currt1,frmnum,0);
% vutaraz{1}=zout1;
% 
% frmnum=3000;
% zout2=vutaraz{2};
% currt2=vutarat{2};
% x=vutarax{2};
% y=vutaray{2};
% z=vutaraz{2};
% % frame=vutarat{2};
% % p.framestart=0;
% % p.framestop=ceil((max(frame)/frmnum))*frmnum-1;
% % points=ceil((max(frame)/frmnum));
% % p.correctxy=false;
% % p.drift_timepoints=points;
% % p.correctz=true;
% % p.drift_timepointsz=points;
% % p.zrange=[min(z) max(z)];
% % [drift,driftinfo,fieldc]=driftcorrection3D_so(x,y,z,frame,p);
% % shiftz2=driftinfo.z.dz;
% % shiftz2=diff(shiftz2);
% % [zout2]=shiftcoords_LS(zout2,shiftz2,currt2,frmnum,0);
% [zout2,shiftz2]=iPALM_driftcorrection_RedunLSv9(x,z,currt2,frmnum,0);
% vutaraz{2}=zout2;
% 
% save([currentfolder savename '_DCresult_two_color'],'shiftz1','shiftz2');

%%
coords=[];
coords(:,1)=vutarax{1}/10;
coords(:,2)=vutaray{1}/10;
coords(:,3)=vutarat{1};
zm=12.8;
szx=168*zm;
szy=168*zm;
im=cHistRecon(szx,szy,single(coords(:,1)),single(coords(:,2)),0);
gaussim=gaussf(im,[1 1]);
str1=([currentfolder savename '_dot_1.tif']);
str2=([currentfolder savename '_gauss_1.tif']);
writeim(im,str1,'tiff',1);
writeim(gaussim,str2,'tiff',1);

coords=[];
coords(:,1)=vutarax{2}/10;
coords(:,2)=vutaray{2}/10;
coords(:,3)=vutarat{2};
zm=12.8;
szx=168*zm;
szy=168*zm;
im=cHistRecon(szx,szy,single(coords(:,1)),single(coords(:,2)),0);
gaussim=gaussf(im,[1 1]);
str1=([currentfolder savename '_dot_2.tif']);
str2=([currentfolder savename '_gauss_2.tif']);
writeim(im,str1,'tiff',1);
writeim(gaussim,str2,'tiff',1);

save([currentfolder savename '_' '642' 'v20_60_two_color'],'vutarax','vutaray','vutaraz','vutarat','vutarall','vutaraI','vutarabg','vutarazcon','vutaracrlb','vutarazerr');
vutarat{1}=ceil(currt(id1)/100);
vutarat{2}=ceil(currt(id2)/100);
[flag]=iPALM2vutarav2(currentfolder,[savename '_ll'],2,vutarax,vutaray,vutaraz,vutarat,vutaraI,vutaracrlb,vutarall,vutarabg,vutarazcon,vutarazerr);
%%
% zm=12.8;
% V=[];
% V(:,1)=vutarax{1}/128;
% V(:,2)=vutaray{1}/128;
% Z=vutaraz{1};
% segnum=ceil((max(Z)-min(Z))/10);
% [rch gch bch]=srhist_color(168,zm,V(:,1),V(:,2),Z,segnum);
% rchsm=gaussf(rch,1);
% gchsm=gaussf(gch,1);
% bchsm=gaussf(bch,1);
% max_chsm=max([ceil(max(rchsm)),ceil(max(gchsm)),ceil(max(bchsm))]);
% max_chsm=min(max_chsm,255);
% rchsmst=imstretch_linear(rchsm,0,max_chsm,0,255);
% gchsmst=imstretch_linear(gchsm,0,max_chsm,0,255);
% bchsmst=imstretch_linear(bchsm,0,max_chsm,0,255);
% colorim=joinchannels('RGB',rchsmst,gchsmst,bchsmst);
% str1=([currentfolder savename '_colorim_1.tif']);
% writeim(colorim,str1,'TIFF');
% 
% V=[];
% V(:,1)=vutarax{2}/128;
% V(:,2)=vutaray{2}/128;
% Z=vutaraz{2};
% segnum=ceil((max(Z)-min(Z))/10);
% [rch gch bch]=srhist_color(168,zm,V(:,1),V(:,2),Z,segnum);
% rchsm=gaussf(rch,1);
% gchsm=gaussf(gch,1);
% bchsm=gaussf(bch,1);
% max_chsm=max([ceil(max(rchsm)),ceil(max(gchsm)),ceil(max(bchsm))]);
% max_chsm=min(max_chsm,255);
% rchsmst=imstretch_linear(rchsm,0,max_chsm,0,255);
% gchsmst=imstretch_linear(gchsm,0,max_chsm,0,255);
% bchsmst=imstretch_linear(bchsm,0,max_chsm,0,255);
% colorim=joinchannels('RGB',rchsmst,gchsmst,bchsmst);
% str1=([currentfolder savename '_colorim_2.tif']);
% writeim(colorim,str1,'TIFF');
