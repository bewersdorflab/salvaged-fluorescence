%%
clc
mask1=vutarax{1}(:)>2000 & vutarax{1}(:)<18000 & vutaray{1}(:)>2000 & vutaray{1}(:)<18000 & vutaraz{1}(:)>0 & vutaraz{1}(:)<500;
mask2=vutarax{2}(:)>2000 & vutarax{2}(:)<18000 & vutaray{2}(:)>2000 & vutaray{2}(:)<18000 & vutaraz{2}(:)>0 & vutaraz{2}(:)<500;
vutarax{1}=vutarax{1}(mask1);
vutaray{1}=vutaray{1}(mask1);
vutaraz{1}=vutaraz{1}(mask1);
vutarax{2}=vutarax{2}(mask2);
vutaray{2}=vutaray{2}(mask2);
vutaraz{2}=vutaraz{2}(mask2);

%%
xlin=cat(1,vutarax{1}(:),vutarax{2}(:));
ylin=cat(1,vutaray{1}(:),vutaray{2}(:));
zlin=cat(1,vutaraz{1}(:),vutaraz{2}(:));
minx=min(xlin);
miny=min(ylin);
minz=min(zlin);
pixelsz=20;
rndsz=2;
x1=floor((xlin-minx)./pixelsz);
x2=floor((ylin-miny)./pixelsz);
x3=floor((zlin-minz)./pixelsz);
x1sz=ceil(max(x1)/rndsz)*rndsz+1;
x2sz=ceil(max(x2)/rndsz)*rndsz+1;
x3sz=max(ceil(max(x3)/rndsz)*rndsz+1,21);
x1_1=(vutarax{1}-minx)/pixelsz;
x2_1=(vutaray{1}-miny)/pixelsz;
x3_1=(vutaraz{1}-minz)/pixelsz;
x1_2=(vutarax{2}-minx)/pixelsz;
x2_2=(vutaray{2}-miny)/pixelsz;
x3_2=(vutaraz{2}-minz)/pixelsz;

%%
clc
% shift=[];
% im1=cHistRecon(x1sz,x2sz,x1_1,x2_1,0);
% im2=cHistRecon(x1sz,x2sz,x1_2,x2_2,0);
% [shift(1),shift(2)]=drift_correction_corev2(single(gaussf(im1,1)),single(gaussf(im2,1)),[0 0]);
% shift
% [shift(1),shift(2)]=drift_correction_core(single(gaussf(im1,1)),single(gaussf(im2,1)),[0 0]);
% shift
% shiftvector = findshift(single(gaussf(im2,1))', single(gaussf(im1,1))', 'grs');
% shiftvector'

im1=cHistRecon3D(x1sz,x2sz,x3sz,single(x1_1),single(x2_1),single(x3_1),0);
im2=cHistRecon3D(x1sz,x2sz,x3sz,single(x1_2),single(x2_2),single(x3_2),0);
shiftvector = findshift(single(gaussf(im2,1)),single(gaussf(im1,1)),'grs');
shift=shiftvector'*pixelsz

% shift=[];
% [shift(1),shift(2),shift(3)]=drift_correction_core3d(single(im1),single(im2),[0 0 0]);
% shift

%%
clc
x1_3=x1_1-0.002;
x2_3=x2_1-0.003;
shift=[];
im1=cHistRecon(x1sz,x2sz,x1_1,x2_1,0);
im2=cHistRecon(x1sz,x2sz,x1_3,x2_3,0);
[shift(1),shift(2)]=drift_correction_corev2(single(gaussf(im1,1)),single(gaussf(im2,1)),[0 0]);
shift
[shift(1),shift(2)]=drift_correction_core(single(gaussf(im1,1)),single(gaussf(im2,1)),[0 0]);
shift
shiftvector = findshift(single(gaussf(im2,1))', single(gaussf(im1,1))', 'grs');
shiftvector'
shiftvector = findshift(single(gaussf(im2,1))', single(gaussf(im1,1))', 'iter');
shiftvector'

% im1=cHistRecon(x1sz,single(x3sz),x1_1,single(x3_1),0);
% im2=cHistRecon(x1sz,single(x3sz),x1_3,single(x3_3),0);
% [shift1,shift(3)]=drift_correction_core(single(gaussf(im1,1)),single(gaussf(im2,1)),[0 0]);
% shift

%%
clc
x1_3=x1_1-0.02;
x2_3=x2_1-0.04;
x3_3=x3_1-0.06;
shift=[];
im1=cHistRecon3D(x1sz,x2sz,x3sz,single(x1_1),single(x2_1),single(x3_1),0);
im2=cHistRecon3D(x1sz,x2sz,x3sz,single(x1_3),single(x2_3),single(x3_3),0);
shiftvector = findshift(single(gaussf(im2,1)), single(gaussf(im1,1)), 'grs');
shiftvector'
% [shift(1),shift(2),shift(3)]=drift_correction_core3d(single(im1),single(im2),[0 0 0]);
% shift

%%
clc
co11=[vutarax{1},vutaray{1},vutaraz{1}]; % in nm
co12=[vutarax{2},vutaray{2},vutaraz{2}]; % in nm
% co12=[vutarax{1}+2,vutaray{1}-3,vutaraz{1}+1]; % in nm
pixelsz=20;
[trans]=iPALM_find2color_transformv2(single(co11),single(co12),pixelsz);

%%
[X,Y,Z] = meshgrid(0.5:1:20.5,0.5:1:20.5,0:0.1:1);
X=X(:)*1000;
Y=Y(:)*1000;
Z=Z(:)*1000;
co2=[X,Y,Z];
[newco2]=iPALM_2color_reg(co2,trans);
Er=newco2-co2;

%%
id=X>7000 & X<14000 & Y>7000 & Y<14000;
er=Er(id,:);
mean(er)

id=X<7000 & Y<7000;
er1=Er(id,:);
mean(er1)

