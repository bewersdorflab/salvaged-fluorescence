%% SCMOS data
% centers=[260,515,1517,1772];
close all
centers=[235,475,1557,1798];
pathname='G:\4PISCMOS\2017-3-1_beads\';
ID=15;
dataFolder=([pathname,'Cell',num2str(ID,'%02d'),'\']);
imageName=(['Cell',num2str(ID,'%02d'),'_642_000_000.dcimg']);
[~,qds]=iPALM_readdcimg([dataFolder imageName],centers);
meanqds1 = mean(qds(:,:,:,1),3);
offset = median(meanqds1(:));
qd1=qds(:,:,:,1)-offset;
qd1(qd1<=0)=1e-7;
im1=mean(qd1,3);

%% EMCCD data
dataFolder=([pathname,'EMCCD\','Cell',num2str(ID,'%02d'),'\']);
imageName=(['Cell',num2str(ID,'%02d'),'_01.tif']);
A=tiffread([dataFolder imageName]);
meanA=mean(A,3);
offset=median(meanA(:));
A=A-offset;
A=double(A);
A(A<=0)=1e-7;
im2=imrotate(mean(A,3),90);

%%
sz=168;
mean_v=ones(sz,sz);
mean_vg=ones(sz,sz);
I=repmat(im1,1,1,10);
V1=[];
[sub_regions tlz locmaxc subvar_g]=iPALMast_sumim_seg(I,10,9,mean_v,mean_vg,0);
[P1 CRLB1 LL1]=sCMOS_MLE_DB_YL_CUDA42(single(sub_regions(:,:,:)),1.4,200,2,single(subvar_g(:,:,:)),single(subvar_g(:,:,:).*0+1));
xf=P1(:,2);
yf=P1(:,1);
xest=xf+tlz(:,2);
yest=yf+tlz(:,1);
L=length(P1);
V1(:,1)=xest(1:round(L/10))+1;
V1(:,2)=yest(1:round(L/10))+1;
figure;imshow(im1,[]);hold on;plot(V1(:,1),V1(:,2),'bo');

%%
mean_v=ones(128,128);
mean_vg=ones(128,128);
I=repmat(im2,1,1,10);
V2=[];
[sub_regions tlz locmaxc subvar_g]=iPALMast_sumim_seg(I,10,7,mean_v,mean_vg,0);
[P1 CRLB1 LL1]=sCMOS_MLE_DB_YL_CUDA42(single(sub_regions(:,:,:)),1.4,200,2,single(subvar_g(:,:,:)),single(subvar_g(:,:,:).*0+1));
xf=P1(:,2);
yf=P1(:,1);
xest=xf+tlz(:,2);
yest=yf+tlz(:,1);
L=length(P1);
V2(:,1)=xest(1:round(L/10))+1;
V2(:,2)=yest(1:round(L/10))+1;
figure;imshow(im2,[]);hold on;plot(V2(:,1),V2(:,2),'bo');
figure;imshow(im1,[]);hold on;plot(V2(:,1)*sz/128,V2(:,2)*sz/128,'bo');
%%
x1=V1;
x2=[];
x2(:,1)=V2(:,1)*sz/128;
x2(:,2)=V2(:,2)*sz/128;
[rx1 rx2 result flag] = GetPointsReg(x1,x2);
D=sqrt((rx1(:,1)-rx2(:,1)).^2+(rx1(:,2)-rx2(:,2)).^2);
id=D>20;
rx1(id,:)=[];
rx2(id,:)=[];
figure;plot(rx1(:,1),rx1(:,2),'bo');hold on;plot(rx2(:,1),rx2(:,2),'ro');
axis([0 sz 0 sz]);axis equal

%%
x1=rx1;
x2=rx2;
[betax,betay]=biplaneReg_linear(x2(:,1),x2(:,2),x1(:,1),x1(:,2));

x3=[];
XX=[ones(size(x1(:,1))),x1(:,1),x1(:,2),x1(:,1).*x1(:,2),x1(:,1).^2,x1(:,2).^2];
x3(:,1)=XX*betax;
x3(:,2)=XX*betay;

Ex=x2(:,1)-x3(:,1);
Ey=x2(:,2)-x3(:,2);
Ex=Ex*128;
Ey=Ey*128;
std(Ex)
std(Ey)

figure;
hold on
plot(x2(:,1),x2(:,2),'r.');
plot(x3(:,1),x3(:,2),'go');
axis([0 sz 0 sz]);
axis equal

% figure;
% hold on
% plot(V2(:,1),V2(:,2),'r.');
% plot(x3(:,1)*128/sz,x3(:,2)*128/sz,'go');
% axis([0 128 0 128]);
% axis equal

id=abs(Ex)>200 | abs(Ey)>200;
x1(id,:)=[];
x2(id,:)=[];

x3=[];
[betax,betay]=biplaneReg_linear(x2(:,1),x2(:,2),x1(:,1),x1(:,2));
XX=[ones(size(x1(:,1))),x1(:,1),x1(:,2),x1(:,1).*x1(:,2),x1(:,1).^2,x1(:,2).^2];
x3(:,1)=XX*betax;
x3(:,2)=XX*betay;

Ex=x2(:,1)-x3(:,1);
Ey=x2(:,2)-x3(:,2);
Ex=Ex*128;
Ey=Ey*128;
std(Ex)
std(Ey)

figure;
hold on
plot(x2(:,1),x2(:,2),'r.');
plot(x3(:,1),x3(:,2),'go');
axis([0 sz 0 sz]);
axis equal

% figure;
% hold on
% plot(V2(:,1),V2(:,2),'r.');
% plot(x3(:,1)*128/sz,x3(:,2)*128/sz,'go');
% axis([0 128 0 128]);
% axis equal

% savefolder=pathname;
% savename='two_camera_reg_20170223.mat';
% str=strcat(savefolder,'\',savename);