%%
% E=[];
% for i=1:11
%     load('E:\4Pi_two_color\2018-6-14+\Cell04_642v20_60_two_color.mat');
%     mask1=vutarax{1}(:)>2000 & vutarax{1}(:)<18000 & vutaray{1}(:)>2000 & vutaray{1}(:)<18000 & vutaraz{1}(:)>-1600+(i-1)*200 & vutaraz{1}(:)<-1600+i*200;
%     mask2=vutarax{2}(:)>2000 & vutarax{2}(:)<18000 & vutaray{2}(:)>2000 & vutaray{2}(:)<18000 & vutaraz{2}(:)>-1600+(i-1)*200 & vutaraz{2}(:)<-1600+i*200;
%     vutarax{1}=vutarax{1}(mask1);
%     vutaray{1}=vutaray{1}(mask1);
%     vutaraz{1}=vutaraz{1}(mask1);
%     vutarax{2}=vutarax{2}(mask2);
%     vutaray{2}=vutaray{2}(mask2);
%     vutaraz{2}=vutaraz{2}(mask2);
%     
%     xlin=cat(1,vutarax{1}(:),vutarax{2}(:));
%     ylin=cat(1,vutaray{1}(:),vutaray{2}(:));
%     zlin=cat(1,vutaraz{1}(:),vutaraz{2}(:));
%     minx=min(xlin);
%     miny=min(ylin);
%     minz=min(zlin);
%     pixelsz=20;
%     rndsz=2;
%     x1=floor((xlin-minx)./pixelsz);
%     x2=floor((ylin-miny)./pixelsz);
%     x3=floor((zlin-minz)./pixelsz);
%     x1sz=ceil(max(x1)/rndsz)*rndsz+1;
%     x2sz=ceil(max(x2)/rndsz)*rndsz+1;
%     x3sz=max(ceil(max(x3)/rndsz)*rndsz+1,21);
%     x1_1=(vutarax{1}-minx)/pixelsz;
%     x2_1=(vutaray{1}-miny)/pixelsz;
%     x3_1=(vutaraz{1}-minz)/pixelsz;
%     x1_2=(vutarax{2}-minx)/pixelsz;
%     x2_2=(vutaray{2}-miny)/pixelsz;
%     x3_2=(vutaraz{2}-minz)/pixelsz;
%     
%     im1=cHistRecon3D(x1sz,x2sz,x3sz,single(x1_1),single(x2_1),single(x3_1),0);
%     im2=cHistRecon3D(x1sz,x2sz,x3sz,single(x1_2),single(x2_2),single(x3_2),0);
%     shiftvector = findshift(single(gaussf(im2,1)),single(gaussf(im1,1)),'grs');
%     shift=shiftvector'*pixelsz
%     E(i,:)=shift;
% end

%%
clear
clc
E=[];
step=100;
for i=1:8
    i
    load('E:\4Pi_two_color\2018-6-14+\Test\Cell04_642v20_60_two_color.mat');
%     load('E:\4Pi_two_color\2018-6-14+\Test\Cell02_642v20_60_two_color.mat')
    vutaraid{1}=(1:length(vutarax{1}))';
    vutaraid{2}=(1:length(vutarax{2}))';
%     vutaraz{1}=vutaraz{1}*199/198;
%     vutaraz{2}=vutaraz{2}*199/202;
    mask1=vutarax{1}(:)>5000 & vutarax{1}(:)<15000 & vutaray{1}(:)>5000 & vutaray{1}(:)<15000 & vutaraz{1}(:)>-500+(i-1)*step & vutaraz{1}(:)<-500+i*step;
    mask2=vutarax{2}(:)>5000 & vutarax{2}(:)<15000 & vutaray{2}(:)>5000 & vutaray{2}(:)<15000 & vutaraz{2}(:)>-500+(i-1)*step & vutaraz{2}(:)<-500+i*step;
    vutarax{1}=vutarax{1}(mask1);
    vutaray{1}=vutaray{1}(mask1);
    vutaraz{1}=vutaraz{1}(mask1);
    vutarax{2}=vutarax{2}(mask2);
    vutaray{2}=vutaray{2}(mask2);
    vutaraz{2}=vutaraz{2}(mask2);
    
    xlin=cat(1,vutarax{1}(:),vutarax{2}(:));
    ylin=cat(1,vutaray{1}(:),vutaray{2}(:));
    zlin=cat(1,vutaraz{1}(:),vutaraz{2}(:));
    minx=min(xlin);
    miny=min(ylin);
    minz=min(zlin);
    pixelsz=20;
    rndsz=2;
    x1=floor((xlin-minx)./pixelsz);
    x2=floor((ylin-miny)./pixelsz);
    x3=floor((zlin-minz)./pixelsz);
    x1sz=ceil(max(x1)/rndsz)*rndsz+1;
    x2sz=ceil(max(x2)/rndsz)*rndsz+1;
    x3sz=max(ceil(max(x3)/rndsz)*rndsz+1,21);
    x1_1=(vutarax{1}-minx)/pixelsz;
    x2_1=(vutaray{1}-miny)/pixelsz;
    x3_1=(vutaraz{1}-minz)/pixelsz;
    x1_2=(vutarax{2}-minx)/pixelsz;
    x2_2=(vutaray{2}-miny)/pixelsz;
    x3_2=(vutaraz{2}-minz)/pixelsz;
    
    im1=cHistRecon3D(x1sz,x2sz,x3sz,single(x1_1),single(x2_1),single(x3_1),0);
    im2=cHistRecon3D(x1sz,x2sz,x3sz,single(x1_2),single(x2_2),single(x3_2),0);
    shiftvector = findshift(single(gaussf(im2,1)),single(gaussf(im1,1)),'grs');
    shift=shiftvector'*pixelsz
    E(i,:)=shift;
end


