clc
E=[];
pathname='G:\4PISCMOS\2017-4-14\';
FN=2000;
for k=1:100
    %%
    k
    V=[];
    % mask=Iresult>300 & Iresult<20000 & abs(xresult-83)<70 & abs(yresult-83)<70 ;% & llresult<500;% & zangctrresult>0.0
    % mask=ones(length(Iresult),1)>0;
    % k=40;
    mask=tresult<k*FN & tresult>=(k-1)*FN;
    V(:,1)=xresult(mask)+1;
    V(:,2)=yresult(mask)+1;
    V(:,3)=tresult(mask)-(k-1)*FN;
    V(:,4)=Iresult(mask);
    
    %%
    load([pathname,'two_camera_reg_20170414.mat']);
    x1=[];
    x1(:,1)=V(:,1);
    x1(:,2)=V(:,2);
    x3=[];
    XX=[ones(size(x1(:,1))),x1(:,1),x1(:,2),x1(:,1).*x1(:,2),x1(:,1).^2,x1(:,2).^2];
    x3(:,1)=XX*betax;
    x3(:,2)=XX*betay;
    x3=x3*128/168;
    
    %%
    dataFolder=([pathname, '\EMCCD\Cell02\']);
    files=dir([dataFolder,'*.tif']);
    filestr=strcat(dataFolder,files(k).name);
    Im=tiffread(filestr);
    Im=imrotate(Im,90);
    
    %%
    [sub_regions tlz locmaxc subvar_g]=iPALMast_sumim_seg(Im,5,7,ones(128,128),ones(128,128),0);
    sub_regions=sub_regions*12/200;
    [P CRLB LL]=sCMOS_MLE_DB_YL_CUDA42(single(sub_regions(:,:,:)),0.75,50,6,single(subvar_g(:,:,:)),single(subvar_g(:,:,:).*0+1));
    
    %%
    mask=abs(P(:,1)-3)<1 & abs(P(:,2)-3)<1 & CRLB(:,1)>0&CRLB(:,2)>0&CRLB(:,1)<0.2&CRLB(:,2)<0.2 & -2*LL<150 & P(:,3)>300;
    llr=-2*LL(mask);
    P1=P(mask,:);
    tlzf=tlz(mask,:);
    T=tlzf(:,3);
    cx=P1(:,1)+tlzf(:,1)+1;
    cy=P1(:,2)+tlzf(:,2)+1;
    
    % I=im(:,:,1);
    % ix=(T==0);
    % figure;imshow(I,[0 max(I(:))]);hold on;plot(cy(ix,1),cx(ix,1),'bo');
    V1=[];
    V1(:,1)=cy;
    V1(:,2)=cx;
    V1(:,3)=T+1;
    
    %%
    V2=x3;
    V2(:,3)=V(:,3)+1;
    V2(:,4)=(1:length(V2))';
    
    %%
    close all
    f=1;
    I=Im(:,:,f);
    ix=V1(:,3)==f;
    figure;imshow(I,[0 max(I(:))]);hold on;
    plot(V1(ix,1),V1(ix,2),'bo');   
    ix=V2(:,3)==f;
    plot(V2(ix,1),V2(ix,2),'ro');
    pause(0.5)
    
    %%
    if k==1
        stx=0;
        sty=0;
    else
        stx=E(k-1,1);
        sty=E(k-1,2);
    end
    m=0;
    while 1
        m=m+1
        V1(:,4)=0;
        for i=1:length(V1)
            x=V1(i,1);
            y=V1(i,2);
            t=V1(i,3);
            ix=V2(:,3)==t;
            V0=V2(ix,:);
            dist=(V0(:,1)-stx-x).^2+(V0(:,2)-sty-y).^2;
            if min(dist)<1
                id=find(dist==min(dist));
                V1(i,4)=V0(id,4);
            end
        end
        id=V1(:,4)>0;
        V1new=V1(id,:);
        V2new=V2(V1new(:,4),:);
        Ve=V2new-V1new;
        mean(Ve)
        std(Ve)
        stx1=mean(Ve(:,1));
        sty1=mean(Ve(:,2));
        if abs(stx1-stx)<0.05 && abs(sty1-sty)<0.05
            break
        else
            stx=stx1;
            sty=sty1;
        end
    end
    E(k,1)=stx1;
    E(k,2)=sty1;
end
%%
datafolder=pathname;
save([datafolder,'Cell02_shift.mat'],'E');