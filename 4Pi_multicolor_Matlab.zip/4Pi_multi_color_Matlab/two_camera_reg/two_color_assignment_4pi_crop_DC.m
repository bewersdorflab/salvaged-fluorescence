%%
clc

% id1=probe==0;
% currx=x(id1);
% curry=y(id1);
% currz=z(id1);
% currt=frame(id1)-1;
% tic
% [xout1,yout1,zout1,shifts1]=iPALM_driftcorrection_RedunLSv8(currx,curry,currz,currt,1000,0,1,0);
% toc
% 
% id2=probe==1;
% currx=x(id2);
% curry=y(id2);
% currz=z(id2);
% currt=frame(id2)-1;
% tic
% [xout2,yout2,zout2,shifts2]=iPALM_driftcorrection_RedunLSv8(currx,curry,currz,currt,1000,0,1,0);
% toc

id1=probe==0;
id2=probe==1;
tic
[xout,yout,zout,shifts]=iPALM_driftcorrection_RedunLSv8(x,y,z,frame-1,1000,0,1,1);
toc

currentfolder='G:\4PISCMOS\2017-5-13\';
savename='Cell06_crop';
% save([currentfolder savename '_DCresult1'],'xout','yout','zout','shifts');

%%
vutarax=[];
vutaray=[];
vutaraz=[];
vutarat=[];
vutaraI=[];
vutaracrlb=[];
vutarall=[];
vutarabg=[];
vutarazcon=[];
vutarazerr=[];

vutarax{1}=xout1;
vutarax{2}=xout2;
vutaray{1}=yout1;
vutaray{2}=yout2;
vutaraz{1}=zout1;
vutaraz{2}=zout2;
% vutarax{1}=xout(id1);
% vutarax{2}=xout(id2);
% vutaray{1}=yout(id1);
% vutaray{2}=yout(id2);
% vutaraz{1}=zout(id1);
% vutaraz{2}=zout(id2);

vutarat{1}=frame(id1);
vutarat{2}=frame(id2);
vutaraI{1}=photoncount(id1);
vutaraI{2}=photoncount(id2);
vutaracrlb{1}=chisq(id1);
vutaracrlb{2}=chisq(id2);
vutarall{1}=loglikelihood(id1);
vutarall{2}=loglikelihood(id2);
vutarabg{1}=customconfidence1(id1);
vutarabg{2}=customconfidence1(id2);
vutarazcon{1}=customconfidence2(id1);
vutarazcon{2}=customconfidence2(id2);
vutarazerr{1}=customconfidence3(id1);
vutarazerr{2}=customconfidence3(id2);

[flag]=iPALM2vutarav2(currentfolder,[savename '_ll'],2,vutarax,vutaray,vutaraz,vutarat,vutaraI,vutaracrlb,vutarall,vutarabg,vutarazcon,vutarazerr);
save([currentfolder savename '_' '642' 'v20_60_two_color'],'vutarax','vutaray','vutaraz','vutarat','vutarall','vutaraI','vutarabg','vutarazcon','vutaracrlb','vutarazerr');

%%
coords=[];
coords(:,1)=vutarax{1}/10;
coords(:,2)=vutaray{1}/10;
coords(:,3)=vutarat{1};
zm=12.8;
szx=168*zm;
szy=168*zm;
im=cHistRecon(szx,szy,single(coords(:,1)),single(coords(:,2)),0);
gaussim=gaussf(im,[1 1]);
str1=([currentfolder savename '_dot_1.tif']);
str2=([currentfolder savename '_gauss_1.tif']);
writeim(im,str1,'tiff',1);
writeim(gaussim,str2,'tiff',1);

coords=[];
coords(:,1)=vutarax{2}/10;
coords(:,2)=vutaray{2}/10;
coords(:,3)=vutarat{2};
zm=12.8;
szx=168*zm;
szy=168*zm;
im=cHistRecon(szx,szy,single(coords(:,1)),single(coords(:,2)),0);
gaussim=gaussf(im,[1 1]);
str1=([currentfolder savename '_dot_2.tif']);
str2=([currentfolder savename '_gauss_2.tif']);
writeim(im,str1,'tiff',1);
writeim(gaussim,str2,'tiff',1);
