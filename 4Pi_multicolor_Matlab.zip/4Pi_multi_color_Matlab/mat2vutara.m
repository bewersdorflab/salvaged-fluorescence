%%
currentfolder='E:\4Pi_two_color\2018-6-1+\';
savename='Cell04_x';
stepsize=20;
vutarat{1,1}=round(vutarax{1,1}/stepsize);
vutarat{1,2}=round(vutarax{1,2}/stepsize);

%%
[flag]=iPALM2vutarav2(currentfolder,[savename '_ll'],2,vutarax,vutaray,vutaraz,vutarat,vutaraI,vutaracrlb,vutarall,vutarabg,vutarazcon,vutarazerr);

%%
currentfolder='E:\4Pi_two_color\2018-6-1+\';
savename='Cell04_y';
stepsize=100;
vutarat{1,1}=round(vutaray{1,1}/stepsize);
vutarat{1,2}=round(vutaray{1,2}/stepsize);
% vutarax{1,1}=ceil(vutarax{1,1}/stepsize);
% vutarax{1,2}=ceil(vutarax{1,2}/stepsize);
% vutaray{1,1}=ceil(vutaray{1,1}/stepsize);
% vutaray{1,2}=ceil(vutaray{1,2}/stepsize);

%%
[flag]=iPALM2vutarav2(currentfolder,[savename '_ll'],2,vutarax,vutaray,vutaraz,vutarat,vutaraI,vutaracrlb,vutarall,vutarabg,vutarazcon,vutarazerr);