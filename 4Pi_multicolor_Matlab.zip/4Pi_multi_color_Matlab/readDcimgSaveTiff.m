%%
clear
clc

current_folder='E:\4Pi_two_color\2018-11-13\Cell01\';
files=dir([current_folder,'\*.dcimg']);

scmos_cali_file='readout1_tmpcalibration.mat';
tmpld=load(scmos_cali_file);
offsetim=tmpld.offsetim; 
varim=tmpld.varim;
gainim=tmpld.g3;    
caliims=cat(3,offsetim,varim,gainim);

I=[];
q1=[];
q2=[];
q3=[];
q4=[];
for j=85:numel(files)
    filename=files(j).name
    centers=[235 473 1558 1797];
    display(['Reading dcimg files...']);
    [~,qds,calicrops]=iPALM_readdcimg([current_folder,filename],centers,caliims);
    qd1=qds(:,:,:,1);
    qd2=qds(:,:,:,2);
    qd3=qds(:,:,:,3);
    qd4=qds(:,:,:,4);
    q1=qd1;
    q2=qd2;
    q3=qd3;
    q4=qd4;

%     q1(:,:,j)=qd1;
%     q2(:,:,j)=qd2;
%     q3(:,:,j)=qd3;
%     q4(:,:,j)=qd4;
%     q1=mean(qd1,3);
%     I1=qd1;
% end
filestr=[current_folder filename(1:end-6) '_q1' '.tif'];
tiffwrite(q1,filestr);
filestr=[current_folder filename(1:end-6) '_q2' '.tif'];
tiffwrite(q2,filestr);
filestr=[current_folder filename(1:end-6) '_q3' '.tif'];
tiffwrite(q3,filestr);
filestr=[current_folder filename(1:end-6) '_q4' '.tif'];
tiffwrite(q4,filestr);
end