close all
pixelsz=50;
xx=[vutarax{1,1};vutarax{1,2};vutarax{1,3}];
yy=[vutaray{1,1};vutaray{1,2};vutaray{1,3}];
x1_1=(xx)/pixelsz;
x2_1=(yy)/pixelsz;
x1sz=ceil(128*168/pixelsz);
im1=cHistRecon(x1sz,x1sz,x2_1,x1_1,0);
dipshow(im1);

%%
V=[xx,yy];
% theta=atand(t);
theta=-15;
T=[cosd(theta) -sind(theta);sind(theta),cosd(theta)];
Vnew=V(:,1:2)*T;
Vnew(:,1)=Vnew(:,1)-mean(Vnew(:,1))+11000;
Vnew(:,2)=Vnew(:,2)-mean(Vnew(:,2))+14000;

x1_1=(Vnew(:,1))/pixelsz;
x2_1=(Vnew(:,2))/pixelsz;
x1sz=ceil(128*200/pixelsz);
im2=cHistRecon(x1sz,x1sz,x2_1,x1_1,0);
dipshow(im2); 

%%
V1=[vutarax{1,1},vutaray{1,1}];
V2=[vutarax{1,2},vutaray{1,2}];
V3=[vutarax{1,3},vutaray{1,3}];
V1new=V1(:,1:2)*T;
V2new=V2(:,1:2)*T;
V3new=V3(:,1:2)*T;

%%
xx=[V1new(:,1);V2new(:,1);V3new(:,1)];
yy=[V1new(:,2);V2new(:,2);V3new(:,2)];
vutarax{1,1}=V1new(:,1)-min(xx);
vutaray{1,1}=V1new(:,2)-min(yy);
vutarax{1,2}=V2new(:,1)-min(xx);
vutaray{1,2}=V2new(:,2)-min(yy);
vutarax{1,3}=V3new(:,1)-min(xx);
vutaray{1,3}=V3new(:,2)-min(yy);

%%
currentfolder='E:\4Pi_two_color\2018-7-26+\';
savename='Cell04_rotate2';
vutarazerr=vutarazcon;
vutarat{1}=ceil(vutarat{1}/100);
vutarat{2}=ceil(vutarat{2}/100);
vutarat{3}=ceil(vutarat{3}/100);
[flag]=iPALM2vutarav2(currentfolder,[savename '_ll'],3,vutarax,vutaray,vutaraz,vutarat,vutaraI,vutaracrlb,vutarall,vutarabg,vutarazcon,vutarazerr);
