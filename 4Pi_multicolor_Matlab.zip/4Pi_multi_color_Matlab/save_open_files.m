%%
openFiles = matlab.desktop.editor.getAll;
fileNames = {openFiles.Filename};
save('opened_mfiles.mat', fileNames);

%%
for i=1:length(fileNames)
    matlab.desktop.editor.openDocument(fileNames{1,i});      
end