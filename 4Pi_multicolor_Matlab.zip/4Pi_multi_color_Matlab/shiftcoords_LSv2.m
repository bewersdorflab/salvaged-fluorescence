% v2 2017-2-17 Yongdeng add interpolation 

function [out]=shiftcoords_LSv2(xout,shiftx,toutin,frmnum,reverseflag,interpflag)

if ~interpflag
    if reverseflag==0
        segnum=ceil((max(toutin)+1)/frmnum);
        for ii=2:1:segnum
            st1=(ii-1)*frmnum;
            ed1=(ii)*frmnum-1;
            maskt=toutin>=st1&toutin<=ed1;
            xout(maskt)=xout(maskt)-sum(shiftx(1:ii-1,1));
        end
        out=xout;
    else
        segnum=ceil((max(toutin)+1)/frmnum);
        for ii=1:1:segnum-1
            st1=(ii-1)*frmnum;
            ed1=(ii)*frmnum-1;
            maskt=toutin>=st1&toutin<=ed1;
            xout(maskt)=xout(maskt)+sum(shiftx(ii:segnum-1,1));
        end
        out=xout;
    end
else
    drift=cumsum(shiftx);
    ntotalframe=max(toutin)+1;
    nbinframe=floor(ntotalframe/frmnum);
    indexinterp=zeros(nbinframe+2,1);
    indexinterp(1)=1;
    indexinterp(nbinframe+2)=ntotalframe;
    indexinterp(2:nbinframe+1)=round(frmnum/2):frmnum:frmnum*nbinframe-1;
    finaldrift=interp1(indexinterp,[0 0 drift' drift(nbinframe-1,1)],1:ntotalframe,'spline')';
    if reverseflag
        finaldrift=finaldrift-finaldrift(end,1);
        shift=finaldrift(toutin+1,1);
        out=xout-shift;
    else
        shift=finaldrift(toutin+1,1);
        out=xout-shift;
    end
end

    