%%
clear
clc
load('E:\4Pi_two_color\2018-11-15+\Cell03_642v20_60_three_color.mat')
V1=[];
V2=[];
V3=[];
V1(:,1)=vutarax{1,1};
V1(:,2)=vutaray{1,1};
V1(:,3)=vutaraz{1,1};
V2(:,1)=vutarax{1,2};
V2(:,2)=vutaray{1,2};
V2(:,3)=vutaraz{1,2};
V3(:,1)=vutarax{1,3};
V3(:,2)=vutaray{1,3};
V3(:,3)=vutaraz{1,3};

%%
V1new={};
V2new={};
V3new={};
P=[];
T=[];
sz=500;
n=1;
m=ceil(21500/sz);
for i=1:m
    for j=1:m
        i
        j
        mask1=V1(:,1)>=(i-1)*sz & V1(:,1)<i*sz & V1(:,2)>=(j-1)*sz & V1(:,2)<j*sz;
        mask2=V2(:,1)>=(i-1)*sz & V2(:,1)<i*sz & V2(:,2)>=(j-1)*sz & V2(:,2)<j*sz;
        mask3=V3(:,1)>=(i-1)*sz & V3(:,1)<i*sz & V3(:,2)>=(j-1)*sz & V3(:,2)<j*sz;
        if sum(mask1)>500 && sum(mask2)>300 && sum(mask3)>500
            V1new{n}=V1(mask1,:);
            V2new{n}=V2(mask2,:);
            V3new{n}=V3(mask3,:);
            P(n,1)=(i-1)*sz+sz/2;
            P(n,2)=(j-1)*sz+sz/2;
            T(n,1)=sum(mask1);
            T(n,2)=sum(mask2);
            T(n,3)=sum(mask3);
            n=n+1;
        end
    end
end

%%
dmap=cHistRecon(2150/2,2150/2,single(V2(:,1)/20),single(V2(:,2)/20),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
figure;imshow(dmap,[]); hold on
plot(P(:,2)/20,P(:,1)/20,'bs','markersize',20);
for i=1:length(P)
    text(P(i,2)/20-10,P(i,1)/20,num2str(i),'color','w');
end
hold off

%%
% id=40;
% plot3(V1new{1,id}(:,1),V1new{1,id}(:,2),V1new{1,id}(:,3),'.b'); hold on;
% plot3(V2new{1,id}(:,1),V2new{1,id}(:,2),V2new{1,id}(:,3),'.r'); hold off;

%% align from top PM
CT=[];
VT1=[];
VT2=[];
VT3=[];
for i=1:length(P)
    i
    z1=V1new{1,i}(:,3);
    z2=V2new{1,i}(:,3);
    z3=V3new{1,i}(:,3);
    cz2=min(mean(z2),median(z2));
    id1=z1>cz2;
    cz1=mean(z1(id1));
    id3=z3>cz2;
    cz01=mean(z2(z2>cz2));
    cz02=mean(z3(z3>cz2));
%     if abs(cz01-cz02)>100
%         continue
%     end
%     CT(i,1)=cz1;
%     CT(i,2)=cz2;
%     CT(i,3)=cz3;
    v1=z1(id1)-cz1;
    v2=z2-cz1;
    v3=z3-cz1;
    VT1=cat(1,v1,VT1);
    VT2=cat(1,v2,VT2);
    VT3=cat(1,v3,VT3);
end

%%
C=[];
figure;
bins=(-500:5:200);
subplot(1,3,1); h1=histogram(VT1,bins);
subplot(1,3,2); h2=histogram(VT2,bins);
subplot(1,3,3); h3=histogram(VT3,bins);
C(:,1)=bins(1:end-1);
C(:,2)=h1.Values;
C(:,3)=h2.Values;
C(:,4)=h3.Values;
C(:,2)=C(:,2)/max(C(:,2));
C(:,3)=C(:,3)/max(C(:,3));
C(:,4)=C(:,4)/max(C(:,4));