%%
clear
clc
load('E:\4Pi_two_color\2018-11-19+\Cell08_642v20_60_two_color.mat');
V1=[];
V2=[];
V1(:,1)=vutarax{1,1};
V1(:,2)=vutaray{1,1};
V1(:,3)=vutaraz{1,1};
V2(:,1)=vutarax{1,2};
V2(:,2)=vutaray{1,2};
V2(:,3)=vutaraz{1,2};

%%
V1new={};
V2new={};
P=[];
T=[];
sz=100;
n=1;
m=ceil(21500/sz);
for i=1:m
    i
    for j=1:m
        mask1=V1(:,1)>=(i-1)*sz & V1(:,1)<i*sz & V1(:,2)>=(j-1)*sz & V1(:,2)<j*sz;
        mask2=V2(:,1)>=(i-1)*sz & V2(:,1)<i*sz & V2(:,2)>=(j-1)*sz & V2(:,2)<j*sz;
        if sum(mask1)>0 && sum(mask2)>0
            V1new{n}=V1(mask1,:);
            V2new{n}=V2(mask2,:);
            P(n,1)=(i-1)*sz+sz/2;
            P(n,2)=(j-1)*sz+sz/2;
            T(n,1)=sum(mask1);
            T(n,2)=sum(mask2);
            n=n+1;
        end
    end
end

%%
P0=P;
V10=V1new;
V20=V2new;

%%
P=[];
V1new={};
V2new={};
m=1;
for i=1:length(P0)
     if T(i,1)>100 && T(i,2)>300
        P(m,:)=P0(i,:);
        V1new{m}=V10{i};
        V2new{m}=V20{i};
        m=m+1;
     end
end

%%
dmap=cHistRecon(2150/2,2150/2,single(V2(:,1)/20),single(V2(:,2)/20),0);
dmap=double(gaussf(dmap,2));
dmap=dmap/max(dmap(:));
figure;imshow(dmap,[]); hold on
plot(P(:,2)/20,P(:,1)/20,'bs','markersize',2);
% for i=1:length(P)
%     text(P(i,2)/20-10,P(i,1)/20,num2str(i),'color','w');
% end
% hold off

%%
% id=40;
% plot3(V1new{1,id}(:,1),V1new{1,id}(:,2),V1new{1,id}(:,3),'.b'); hold on;
% plot3(V2new{1,id}(:,1),V2new{1,id}(:,2),V2new{1,id}(:,3),'.r'); hold off;

%% align from top PM
CT=[];
VT1=[];
VT2=[];
for i=1:length(P)
    i
    z1=V1new{1,i}(:,3);
    z2=V2new{1,i}(:,3);
    cz2=median(z2);
    id1=z1>cz2;
    cz1=median(z1(id1));
%     if std(z1(id1))>15
%         continue
%     end

    CT(i,1)=cz1;
    CT(i,2)=cz2;
    v1=z1(id1)-cz1;
    v2=z2-cz1;
       
    ed=(-50:5:50);
    [Y,edges] = histcounts(v1,ed);
    ed1=(-47.5:5:50);
    [sigma,mu1,A,B]=mygaussfit(ed1,Y,5,100);
    CT(i,1)=mu1;    
%     if sigma>12
%         continue
%     end        
    v1=v1-mu1;
    v2=v2-mu1;   
    
    VT1=cat(1,v1,VT1);
    VT2=cat(1,v2,VT2);
end

%%
figure;
C=[];
bins=(-500:5:200);
subplot(1,2,1); h1=histogram(VT1,bins);
subplot(1,2,2); h2=histogram(VT2,bins);
C(:,1)=bins(1:end-1);
C(:,2)=h1.Values;
C(:,3)=h2.Values;
C(:,2)=C(:,2)/max(C(:,2));
C(:,3)=C(:,3)/max(C(:,3));

%% align from bottom PM
% CB=[];
% VB1=[];
% VB2=[];
% for i=1:length(P)
%     i
%     z1=V1new{1,i}(:,3);
%     z2=V2new{1,i}(:,3);
%     cz2=min(mean(z2),median(z2));
%     id1=z1<cz2;
%     cz1=mean(z1(id1));
%     CB(i,1)=cz1;
%     CB(i,2)=cz2;
%     v1=z1(id1)-cz1;
%     v2=z2-cz1;
%     VB1=cat(1,v1,VB1);
%     VB2=cat(1,v2,VB2);
% end

%%
% CB=[];
% VB1=[];
% VB2=[];
% for i=1:length(P)
%     i
%     z1=V1new{1,i}(:,3);
%     z2=V2new{1,i}(:,3);
%     cz2=(mean(z2)+median(z2))/2;
%     id1=z1<cz2;
%     cz1=median(z1(id1));
%     CB(i,1)=cz1;
%     CB(i,2)=cz2;
%     v1=z1-cz2;
%     v2=z2-cz2;
%     VB1=cat(1,v1,VB1);
%     VB2=cat(1,v2,VB2);
% end