id=probe==0;
vutarax{1,1}=single(x(id));
vutaray{1,1}=single(y(id));
id=probe==1;
vutarax{1,2}=single(x(id));
vutaray{1,2}=single(y(id));

%%
pixelsz=50;
xx=[vutarax{1,1};vutarax{1,2}];
yy=[vutaray{1,1};vutaray{1,2}];
x1_1=(xx)/pixelsz;
x2_1=(yy)/pixelsz;
x1sz=ceil(128*168/pixelsz);
im1=cHistRecon(x1sz,x1sz,x2_1,x1_1,0);
dipshow(im1);

%%
V=[xx,yy];
% theta=atand(t);
theta=20;
T=[cosd(theta) -sind(theta);sind(theta),cosd(theta)];
Vnew=V(:,1:2)*T;
Vnew(:,1)=Vnew(:,1)-mean(Vnew(:,1))+11000;
Vnew(:,2)=Vnew(:,2)-mean(Vnew(:,2))+14000;

x1_1=(Vnew(:,1))/pixelsz;
x2_1=(Vnew(:,2))/pixelsz;
x1sz=ceil(128*200/pixelsz);
im2=cHistRecon(x1sz,x1sz,x2_1,x1_1,0);
dipshow(im2); 

%%
V1=[vutarax{1,1},vutaray{1,1}];
V2=[vutarax{1,2},vutaray{1,2}];
V1new=V1(:,1:2)*T;
V2new=V2(:,1:2)*T;

%%
xx=[V1new(:,1);V2new(:,1)];
yy=[V1new(:,2);V2new(:,2)];
vutarax{1,1}=V1new(:,1)-min(xx);
vutaray{1,1}=V1new(:,2)-min(yy);
vutarax{1,2}=V2new(:,1)-min(xx);
vutaray{1,2}=V2new(:,2)-min(yy);

%%
currentfolder='E:\4Pi_Paper\dual_tubulin\20171128\';
savename='Cell01_rotate';
vutarat{1}=ceil(vutarat{1}/100);
vutarat{2}=ceil(vutarat{2}/100);
% [flag]=iPALM2vutarav2(currentfolder,[savename '_ll'],2,vutarax,vutaray,vutaraz,vutarat,vutaraI,vutaracrlb,vutarall,vutarabg,vutarazcon,vutarazerr);

%%

[flag]=iPALM2vutarav2(currentfolder,[savename '_ll'],2,vutarax,vutaray,vutaraz,vutarat,vutaraI,vutaracrlb,vutarall,vutarabg,vutarazcon,vutarazerr);
