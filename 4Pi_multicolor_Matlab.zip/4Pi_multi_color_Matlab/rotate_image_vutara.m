pixelsz=50;
xx=single(x);
yy=single(y);
x1_1=(xx)/pixelsz;
x2_1=(yy)/pixelsz;
x1sz=ceil(128*168/pixelsz);
im1=cHistRecon(x1sz,x1sz,x2_1,x1_1,0);
dipshow(im1);

%%
V=[xx,yy];
% theta=atand(t);
theta=49;
T=[cosd(theta) -sind(theta);sind(theta),cosd(theta)];
Vnew=V(:,1:2)*T;
Vnew(:,1)=Vnew(:,1)-mean(Vnew(:,1))+2000;
Vnew(:,2)=Vnew(:,2)-mean(Vnew(:,2))+2000;

x1_1=(Vnew(:,1))/pixelsz;
x2_1=(Vnew(:,2))/pixelsz;
x1sz=ceil(128*100/pixelsz);
im2=cHistRecon(x1sz,x1sz,x2_1,x1_1,0);
dipshow(im2); 

%%
V1=[x,y];
V1new=V1(:,1:2)*T;

%%
xx=V1new(:,1);
yy=V1new(:,2);
vutarax{1,1}=V1new(:,1)-min(xx);
vutaray{1,1}=V1new(:,2)-min(yy);

%%
rfolder='E:\4Pi_Paper\CF680_tubulin';
fid = fopen([rfolder '20180218_Cell05.csv'],'wt');
dlmwrite([rfolder '20180218_Cell05.csv'],Mtot,'-append')
% fprintf(filename,c);
fprintf(fid,'%s\n',c);
fclose(fid);
