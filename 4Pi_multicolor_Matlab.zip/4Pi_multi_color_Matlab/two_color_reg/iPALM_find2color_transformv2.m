function [trans]=iPALM_find2color_transformv2(co1,co2,pixelsz)
%% determine sz
% tmp=max(co1,[],1)-min(co1,[],1);
% tmp2=max(co2,[],1)-min(co2,[],1);
% msz=max(tmp,tmp2);
% xsz=max(msz(1),msz(2));
% zsz=msz(3);
% dc=min(min(co1,[],1), min(co2,[],1));
% xszp=xsz./pixelsz;
% zszp=zsz./pixelsz;
% rndsz=2;
% xszp=ceil(xszp/rndsz)*rndsz+1; % ensure odd number of pixels per frame
% zszp=ceil(zszp/rndsz)*rndsz+1; % ensure odd number of pixels per frame
% %% coordinate normlization
% % nco1=round((co1-repmat(dc,[size(co1,1) 1]))./pixelsz);
% % nco2=round((co2-repmat(dc,[size(co2,1) 1]))./pixelsz);
% nco1=((co1-repmat(dc,[size(co1,1) 1]))./pixelsz);
% nco2=((co2-repmat(dc,[size(co2,1) 1]))./pixelsz);

%%

xlin=cat(1,co1(:,1),co2(:,1));
ylin=cat(1,co1(:,2),co2(:,2));
zlin=cat(1,co1(:,3),co2(:,3));
minx=min(xlin);
miny=min(ylin);
minz=min(zlin);
rndsz=2;
x1=floor((xlin-minx)./pixelsz);
x2=floor((ylin-miny)./pixelsz);
x3=floor((zlin-minz)./pixelsz);
x1sz=ceil(max(x1)/rndsz)*rndsz+1;
x2sz=ceil(max(x2)/rndsz)*rndsz+1;
x3sz=max(ceil(max(x3)/rndsz)*rndsz+1,21);
x1_1=(co1(:,1)-minx)/pixelsz;
x2_1=(co1(:,2)-miny)/pixelsz;
x3_1=(co1(:,3)-minz)/pixelsz;
x1_2=(co2(:,1)-minx)/pixelsz;
x2_2=(co2(:,2)-miny)/pixelsz;
x3_2=(co2(:,3)-minz)/pixelsz;

im1=cHistRecon3D(x1sz,x2sz,x3sz,single(x1_1),single(x2_1),single(x3_1),0);
im2=cHistRecon3D(x1sz,x2sz,x3sz,single(x1_2),single(x2_2),single(x3_2),0);
sm_im561=gaussf(im1,1);
sm_im642=gaussf(im2,1);


%% make images
% im642=cHistRecon3D(xszp, xszp, zszp, single(nco1(:,1)), single(nco1(:,2)), single(nco1(:,3)), 0);
% sm_im642=gaussf(im642,1);
% 
% im561=cHistRecon3D(xszp, xszp, zszp, single(nco2(:,1)), single(nco2(:,2)), single(nco2(:,3)), 0);
% sm_im561=gaussf(im561,1);

% im561=cHistRecon3D(xszp, xszp, zszp, single(nco1(:,1)+1), single(nco1(:,2)+2), single(nco1(:,3)+1), 0);
% sm_im561=gaussf(im561,1);

% display('Finished Reconstructing 3D images in 2 Channels');
% colorim=joinchannels('RGB', sm_im642, sm_im561);
% dipshow(colorim,[0 1]);

%% cross correlation
% im642=gpuArray(im642);
% im561=gpuArray(im561);
% [shiftx,shifty,shiftz]=drift_correction_core3d_align(single(im561),single(im642),[0,0,0]);
% [shiftx,shifty,shiftz]*pixelsz

shiftvector = findshift(single(sm_im642), single(sm_im561), 'grs');
shiftx=shiftvector(2);
shifty=shiftvector(1);
shiftz=shiftvector(3);
[shifty,shiftx,shiftz]

display('Finished Channel alignment initial guess');
%% correct
% n561x=nco2(:,1)+shiftx;
% n561y=nco2(:,2)+shifty;
% n561z=nco2(:,3)+shiftz;
% 
% im561=cHistRecon3D(xszp, xszp, zszp, single(n561x), single(n561y), single(n561z), 0);
% sm_im561=gaussf(im561,1);
% colorim=joinchannels('RGB', sm_im642, sm_im561);
% dipshow(colorim,[0 1]);
% save tmpresult sm_im642 sm_im561
%%
[optimizer, metric] = imregconfig('multimodal');

optimizer.InitialRadius = 0.00001;
optimizer.Epsilon = 1.5e-8;
optimizer.GrowthFactor = 1.1;
optimizer.MaximumIterations = 300;
tmpt=eye(4);
tmpt(4,1:3)=[shifty,shiftx,shiftz];
% tmpt(4,1:3)=0;
ini_tform = affine3d(tmpt);
% [trans] = imregtform(single(sm_im561), single(sm_im642), 'affine', optimizer, metric);
% trans.T
% [trans] = imregtform(single(sm_im561), single(sm_im642), 'translation', optimizer, metric, 'InitialTransformation', ini_tform);
% trans.T
[trans] = imregtform(single(sm_im561), single(sm_im642), 'affine', optimizer, metric, 'InitialTransformation', ini_tform);
%% transfer
trans.T(4,1:3)=trans.T(4,1:3)*pixelsz;
trans.T
% moving_reg = imregister(single(sm_im561), single(sm_im642), 'affine', optimizer, metric, 'InitialTransformation', ini_tform);
display('Finished Channel alignment final guess');
% colorim=joinchannels('RGB', sm_im642, moving_reg);
% dipshow(colorim,[0 1]);
% save tmpreg sm_im642 sm_im561 trans