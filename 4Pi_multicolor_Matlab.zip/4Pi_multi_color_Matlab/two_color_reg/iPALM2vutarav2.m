% for v14 iPALMast_analysisv14scmos.m

function [flag]=iPALM2vutarav2(resultfolder,filename,colornum,xcell,ycell,zcell,tcell,LLRcell,conf1,conf2,conf3)
% [flag]=iPALM2vutara(filename,colornum,x,y,z)
Mtot=[];
flag=0;


rfolder=[resultfolder filename '\'];
mkdir(rfolder);
% 
c =['image-ID,cycle,z-step,frame,particle-ID,accum,probe,photon-count,photon-count11,photon-count12,photon-count21,photon-count22,psfx,psfy,psfz,psf-photon-count,x,y,z,amp,background11,background12,background21,background22,chisq,valid'];
% c=['asda,asdasd'];
fid = fopen([rfolder 'particles.csv'],'wt');
% fprintf(filename,c);
fprintf(fid,'%s\n',c);
fclose(fid);

for cc=1:1:colornum
    Mtottmp=[];
    x=xcell{cc};
    y=ycell{cc};
    z=zcell{cc};
    col1=tcell{cc};
    col2=tcell{cc};
    col3=tcell{cc};
    col4=tcell{cc};
    col5=ones(size(x));
    col6=ones(size(x));
    col7=ones(size(x)).*0+cc-1;
    col8=ones(size(x));
    col9=ones(size(x));
    col10=ones(size(x));
    col11=ones(size(x));
    col12=ones(size(x));
    col13=ones(size(x));
    col14=ones(size(x));
    col15=ones(size(x));
    col16=ones(size(x));
    col17=x;
    col18=y;
    col19=z;
    col20=ones(size(x));
    col21=ones(size(x));
    col22=ones(size(x));
    col23=ones(size(x));
    col24=ones(size(x));
    if nargin>7
        col25=LLRcell{cc};
    else 
        col25=ones(size(x));
    end
    col26=ones(size(x));
    kk=26;
    if nargin>8
        col27=conf1{cc};
        kk=27;
    end
    if nargin>9
        col28=conf2{cc};
        kk=28;
    end
    if nargin>10
        col29=conf3{cc};
        kk=29;
    end
    %% cat them together
    
    for ii=1:1:kk
        eval(['Mtottmp=cat(2,Mtottmp,' ['col' num2str(ii)] ');']);
    end
    
    if cc==1
        Mtot=Mtottmp;
    else
        Mtot=cat(1,Mtot,Mtottmp);
    end
end

try
    dlmwrite([rfolder 'particles.csv'],Mtot,'-append')
    flag=1;
catch
    error('Error in writing csv file, please check write permission in current folder');
end

