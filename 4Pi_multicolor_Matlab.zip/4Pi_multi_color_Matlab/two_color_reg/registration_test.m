clear
clc
[X,Y,Z] = meshgrid(-10:1:10, -10:1:10, -1:0.1:0); 
x=X(:)*1000;
y=Y(:)*1000;
z=Z(:)*1000;
co1=[x y z]; % in nm

ldtmp=load('Mito_registration_cell6_09-28-2015.mat');
[co2]=iPALM_2color_reg(co1, ldtmp.trans);
ldtmp=load('Mito_registration_cell5_09-29-2015.mat');
[co3]=iPALM_2color_reg(co1, ldtmp.trans);
ldtmp=load('Mito_registration_cell4_09-28-2015.mat');
[co4]=iPALM_2color_reg(co1, ldtmp.trans);
ldtmp=load('Mito_registration_cell3_09-28-2015.mat');
[co5]=iPALM_2color_reg(co1, ldtmp.trans);

plot3(co3(:,1),co3(:,2),co3(:,3),'bo');
hold on
plot3(co2(:,1),co2(:,2),co2(:,3),'ro');

colorx{1}=co1(:,1);
colorx{2}=co2(:,1);
colorx{3}=co3(:,1);
colorx{4}=co4(:,1);
colorx{5}=co5(:,1);
colory{1}=co1(:,2);
colory{2}=co2(:,2);
colory{3}=co3(:,2);
colory{4}=co4(:,2);
colory{5}=co5(:,2);
colorz{1}=co1(:,3);
colorz{2}=co2(:,3);
colorz{3}=co3(:,3);
colorz{4}=co4(:,3);
colorz{5}=co5(:,3);
tcell{1}=co1(:,3).*0+1;
tcell{2}=co2(:,3).*0+1;
tcell{3}=co3(:,3).*0+1;
tcell{4}=co4(:,3).*0+1;
tcell{5}=co5(:,3).*0+1;

datafolder='D:\4Pi\Sep25th-2015\test\';
[flag]=iPALM2vutarav2([],[datafolder 'test'],5,colorx,colory,colorz,tcell);

%%
clear
clc
[X,Y,Z] = meshgrid(0, 0, 0); 
x=X(:)*1000;
y=Y(:)*1000;
z=Z(:)*1000;
co1=[x y z]; % in nm

ldtmp=load('Mito_registration_cell1_10-07-2015.mat');
[co2]=iPALM_2color_reg(co1, ldtmp.trans);
ldtmp=load('Mito_registration_cell2_10-07-2015.mat');
[co3]=iPALM_2color_reg(co1, ldtmp.trans);
ldtmp=load('Mito_registration_cell3_10-07-2015.mat');
[co4]=iPALM_2color_reg(co1, ldtmp.trans);
ldtmp=load('Mito_registration_cell4_10-07-2015.mat');
[co5]=iPALM_2color_reg(co1, ldtmp.trans);
ldtmp=load('Mito_registration_cell5_10-07-2015.mat');
[co6]=iPALM_2color_reg(co1, ldtmp.trans);
ldtmp=load('Mito_registration_cell6_10-07-2015.mat');
[co7]=iPALM_2color_reg(co1, ldtmp.trans);

figure
hold on
plot3(co2(:,1),co2(:,2),co2(:,3),'ro');
plot3(co3(:,1),co3(:,2),co3(:,3),'go');
plot3(co4(:,1),co4(:,2),co4(:,3),'bo');
plot3(co5(:,1),co5(:,2),co5(:,3),'mo');
plot3(co6(:,1),co6(:,2),co6(:,3),'co');
plot3(co7(:,1),co7(:,2),co7(:,3),'yo');

figure
hold on
plot(co2(:,2),co2(:,1),'ro');
plot(co3(:,2),co3(:,1),'go');
plot(co4(:,2),co4(:,1),'bo');
plot(co5(:,2),co5(:,1),'mo');
plot(co6(:,2),co6(:,1),'co');
plot(co7(:,2),co7(:,1),'yo');

figure
hold on
plot(co2(:,2),co2(:,3),'ro');
plot(co3(:,2),co3(:,3),'go');
plot(co4(:,2),co4(:,3),'bo');
plot(co5(:,2),co5(:,3),'mo');
plot(co6(:,2),co6(:,3),'co');
plot(co7(:,2),co7(:,3),'yo');

colorx{1}=co1(:,1);
colorx{2}=co2(:,1);
colorx{3}=co3(:,1);
colorx{4}=co4(:,1);
colorx{5}=co5(:,1);
colorx{6}=co6(:,1);
colorx{7}=co7(:,1);
colory{1}=co1(:,2);
colory{2}=co2(:,2);
colory{3}=co3(:,2);
colory{4}=co4(:,2);
colory{5}=co5(:,2);
colory{6}=co6(:,2);
colory{7}=co7(:,2);
colorz{1}=co1(:,3);
colorz{2}=co2(:,3);
colorz{3}=co3(:,3);
colorz{4}=co4(:,3);
colorz{5}=co5(:,3);
colorz{6}=co6(:,3);
colorz{7}=co7(:,3);
tcell{1}=co1(:,3).*0+1;
tcell{2}=co2(:,3).*0+1;
tcell{3}=co3(:,3).*0+1;
tcell{4}=co4(:,3).*0+1;
tcell{5}=co5(:,3).*0+1;
tcell{6}=co6(:,3).*0+1;
tcell{7}=co7(:,3).*0+1;

datafolder='C:\ProgramData\Vutara\SR\Experiments\sep30th-2015\mito_registration\two-color\';
[flag]=iPALM2vutarav2([],[datafolder 'test'],7,colorx,colory,colorz,tcell);
