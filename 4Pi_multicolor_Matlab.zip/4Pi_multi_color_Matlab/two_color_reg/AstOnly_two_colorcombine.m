datafolder='Z:\Fang\MATLAB\Projects\iPALM\_dev_branch5_iPALMscmos_2colorAlign\Test_data\Feb20th_2015\';

c642=load([datafolder 'npc8_642v18_120.mat']);
c561=load([datafolder 'npc8_560v18_120.mat']);

%% registering color
addpath 'Z:\Fang\MATLAB\Projects\iPALM\_dev_branch5_iPALMscmos_2colorAlign';
ldtmp=load('ColorReg561to642trans33-19-03-02-2015.mat');
co2=[c561.vutarax c561.vutaray c561.vutaraz]; % in nm
[newco2]=iPALM_2color_reg(co2, ldtmp.trans);


vutarax=[];
vutaray=[];
vutaraz=[];
vutarat=[];
vutarax{1}=newco2(:,1);
vutarax{2}=c642.vutarax;
vutaray{1}=newco2(:,2);
vutaray{2}=c642.vutaray;
vutaraz{1}=newco2(:,3);
vutaraz{2}=c642.vutaraz;
vutarat{1}=round(c561.vutarat./10);
vutarat{2}=round(c642.vutarat./10);


[flag]=iPALM2vutarav2([],['npc8_8nm_' datestr(now,'MM-hh-mm-DD-YYYY')],2,vutarax,vutaray,vutaraz,vutarat);
      