clear
clc
[X,Y] = meshgrid(1:10:150, 1:10:150); 
x=X(:);
y=Y(:);
co1=[x y]; % in nm
plot(x,y,'bo');

ch=4;
fmfile='align1_561_Sep30th_2015FMTtransform093015.mat';
ldtmp=load(fmfile);
ldtmp.R(:,:,1)=eye(3);
cocurr=[x' ; y'; ones(1,numel(x))];
transco=ldtmp.R(:,:,ch)*cocurr;
x1=transco(1,:);
y1=transco(2,:);

fmfile='align1_561_Sep25th_2015FMTtransform092515.mat';
ldtmp=load(fmfile);
ldtmp.R(:,:,1)=eye(3);
cocurr=[x' ; y'; ones(1,numel(x))];
transco=ldtmp.R(:,:,ch)*cocurr;
x2=transco(1,:);
y2=transco(2,:);

fmfile='align1_561_Sep23rd_2015FMTtransform092315.mat';
ldtmp=load(fmfile);
ldtmp.R(:,:,1)=eye(3);
cocurr=[x' ; y'; ones(1,numel(x))];
transco=ldtmp.R(:,:,ch)*cocurr;
x3=transco(1,:);
y3=transco(2,:);

fmfile='align1_561_Sep18th_2015FMTtransform091815.mat';
ldtmp=load(fmfile);
ldtmp.R(:,:,1)=eye(3);
cocurr=[x' ; y'; ones(1,numel(x))];
transco=ldtmp.R(:,:,ch)*cocurr;
x4=transco(1,:);
y4=transco(2,:);

fmfile='align5_561_Sep14th_2015FMTtransform091415.mat';
ldtmp=load(fmfile);
ldtmp.R(:,:,1)=eye(3);
cocurr=[x' ; y'; ones(1,numel(x))];
transco=ldtmp.R(:,:,ch)*cocurr;
x5=transco(1,:);
y5=transco(2,:);

fmfile='align1_561_Sep11th_2015FMTtransform092115.mat';
ldtmp=load(fmfile);
ldtmp.R(:,:,1)=eye(3);
cocurr=[x' ; y'; ones(1,numel(x))];
transco=ldtmp.R(:,:,ch)*cocurr;
x6=transco(1,:);
y6=transco(2,:);

% fmfile='align1_561_Sep2nd_2015FMTtransform092115.mat';
% ldtmp=load(fmfile);
% ldtmp.R(:,:,1)=eye(3);
% cocurr=[x' ; y'; ones(1,numel(x))];
% transco=ldtmp.R(:,:,ch)*cocurr;
% x7=transco(1,:);
% y7=transco(2,:);

plot(x1,y1,'ro');hold on;
plot(x2,y2,'go');
plot(x3,y3,'bo');
plot(x4,y4,'mo');
plot(x5,y5,'co');
plot(x6,y6,'yo');
% plot(x7,y7,'ko');