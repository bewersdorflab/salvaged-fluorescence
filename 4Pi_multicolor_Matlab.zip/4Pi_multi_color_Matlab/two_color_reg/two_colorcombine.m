clear
clc
datafolder='D:\4Pi\Sep30th-2015\COPI_AF647_GM130_Cy3B\two-color\';
for i=1:6
c642=load([datafolder,'cell',num2str(i),'_642v20_60.mat']);
c561=load([datafolder,'cell',num2str(i),'_561v20_60.mat']);

%% registering color
% addpath 'Z:\Fang\MATLAB\Projects\iPALM\_dev_branch5_iPALMscmos_2colorAlign\Ast_Only_calibration';
ldtmp=load('Mito_registration_cell6_10-21-2015.mat');
co2=[c561.vutarax c561.vutaray c561.vutaraz]; % in nm
% ldtmp.trans.T(4,3)=16;
[newco2]=iPALM_2color_reg(co2, ldtmp.trans);

vutarax=[];
vutaray=[];
vutaraz=[];
vutarat=[];
vutarax{2}=newco2(:,1);
vutarax{1}=c642.vutarax;
vutaray{2}=newco2(:,2);
vutaray{1}=c642.vutaray;
vutaraz{2}=newco2(:,3);
vutaraz{1}=c642.vutaraz;
vutarat{2}=round(c561.vutarat./10);
vutarat{1}=round(c642.vutarat./10);

[flag]=iPALM2vutarav2([],[datafolder,'cell',num2str(i),'_561v642_old'],2,vutarax,vutaray,vutaraz,vutarat);

vutarax=[];
vutaray=[];
vutaraz=[];
vutarat=[];
vutarax{2}=c561.vutarax;
vutarax{1}=c642.vutarax;
vutaray{2}=c561.vutaray;
vutaray{1}=c642.vutaray;
vutaraz{2}=c561.vutaraz;
vutaraz{1}=c642.vutaraz;
vutarat{2}=round(c561.vutarat./10);
vutarat{1}=round(c642.vutarat./10);

[flag]=iPALM2vutarav2([],[datafolder,'cell',num2str(i),'_561v642'],2,vutarax,vutaray,vutaraz,vutarat);
end