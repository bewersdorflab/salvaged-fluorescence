function [out]=iPALM_2color_reg(co,trans)
co2=[co(:,[2 1 3]) ones(size(co,1),1)];

tmp=co2*trans.T(:,1:3);
out=tmp(:,[2 1 3]);