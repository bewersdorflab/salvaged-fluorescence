clear
% clc

datafolder='G:\4PISCMOS\2016-5-27\PrgH\two-color\';
co1=[];
co2=[];
for i=12:12
    
    ld642=load([datafolder,'cell',num2str(i),'_642v20_60.mat']);
    ld561=load([datafolder,'cell',num2str(i),'_561v20_60.mat']);
    
    IX=ld642.vutaraz<400;    
    co11=[ld642.vutarax(IX) ld642.vutaray(IX) ld642.vutaraz(IX)]; % in nm
    
%     co11=[ld642.vutarax ld642.vutaray ld642.vutaraz]; % in nm
    co21=[ld561.vutarax ld561.vutaray ld561.vutaraz]; % in nm
    
    co1=cat(1,co1,co11);
    co2=cat(1,co2,co21);
%     co2=co1+repmat([-1.5 5.0 8.0]*20,[size(co1,1) 1]);
end

pixelsz=20;
[trans]=iPALM_find2color_transformv2(co1,co2,pixelsz);

% save(['ColorReg561to642trans_2CcalibrationData' datestr(now,'MM-hh-mm-DD-YYYY')], 'trans', 'co1', 'co2');
% save(['Mito_registration_cell',num2str(i),'_',datestr(now,'mm-DD-YYYY')], 'trans', 'co1', 'co2');

%% correct channel
[newco2]=iPALM_2color_reg(co2,trans);

colorx{1}=co1(:,1);
colorx{2}=co2(:,1);
colory{1}=co1(:,2);
colory{2}=co2(:,2);
colorz{1}=co1(:,3);
colorz{2}=co2(:,3);
tcell{1}=co1(:,3).*0+1;
tcell{2}=co2(:,3).*0+1;

[flag]=iPALM2vutarav2([],[datafolder,'cell0',num2str(i),'_561v642_old'],2,colorx,colory,colorz,tcell);

colorx{2}=newco2(:,1);
colorx{1}=co1(:,1);
colory{2}=newco2(:,2);
colory{1}=co1(:,2);
colorz{2}=newco2(:,3);
colorz{1}=co1(:,3);
tcell{2}=newco2(:,3).*0+1;
tcell{1}=co1(:,3).*0+1;

[flag]=iPALM2vutarav2([],[datafolder,'cell0',num2str(i),'_561v642'],2,colorx,colory,colorz,tcell);
