%%
Resultfolder='Ast_Only_calibration\';
mkdir(Resultfolder);
datafolder='training_data\Feb19th_2015\';

ld642=load([datafolder 'mito3_642_zfonly.mat']);
ld561=load([datafolder 'mito3_560_zfonly.mat']);

co1=[ld642.vutarax ld642.vutaray ld642.vutaraz]; % in nm
co2=[ld561.vutarax ld561.vutaray ld561.vutaraz]; % in nm
% co2=co1+repmat([0.1 0.2 0.3]*100,[size(co1,1) 1]);
pixelsz=25;

[trans]=iPALM_find2color_transformv2(co1,co2,pixelsz);

save([Resultfolder 'Ast_Only_ColorReg561to642trans' datestr(now,'MM-hh-mm-DD-YYYY')], 'trans', 'co1', 'co2');

% %% correct channel
% ldtmp=load('ColorReg561to642trans03-02-2015.mat');
% foldername='Z:\Fang\MATLAB\Projects\iPALM\_dev_branch5_iPALMscmos_2colorAlign\TwoColor_Data';
% ld642=load([foldername '\mito3_642DCresult.mat']);
% ld561=load([foldername '\mito3_560DCresult.mat']);
% 
% co1=[ld642.xout{1} ld642.yout{1} ld642.zout{1}]; % in nm
% co2=[ld561.xout{1} ld561.yout{1} ld561.zout{1}]; % in nm
% 
% [newco2]=iPALM_2color_reg(co2, ldtmp.trans);
% 
% colorx{1}=co1(:,1);
% colorx{2}=newco2(:,1);
% colory{1}=co1(:,2);
% colory{2}=newco2(:,2);
% colorz{1}=co1(:,3);
% colorz{2}=newco2(:,3);
% tcell{1}=co1(:,3).*0+1;
% tcell{2}=newco2(:,3).*0+1;
% 
% 
% [flag]=iPALM2vutarav2([],['mito11561_642'],2,colorx,colory,colorz,tcell);
% 
% 
% 
% [flag]=iPALM2vutarav2([],['test561'],1,{newco2(:,1)},{newco2(:,2)},{newco2(:,3)},{newco2(:,3).*0+1});
