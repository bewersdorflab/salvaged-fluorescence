clear
clc

current_folder='E:\test\';
fmfile='E:\test\align_642_FMTtransform_20180605.mat';

scmos_cali_file='readout1_tmpcalibration.mat';
tmpld=load(scmos_cali_file);
offsetim=tmpld.offsetim; 
varim=tmpld.varim;
gainim=tmpld.g3;    
caliims=cat(3,offsetim,varim,gainim);

files=dir([current_folder,'\*.dcimg']);
I=[];
for j=1:numel(files)
    filename=files(j).name;
    centers=[235 474 1557 1797];
    display(['Reading dcimg files...']);
    [~,qds,calicrops]=iPALM_readdcimg([current_folder,filename],centers,caliims);
    tmpim=calicrops(:,:,3,:);
    tmpim(tmpim<1.3|tmpim>3.5)=mean(mean(mean(calicrops(:,:,3,:))));
    calicrops(:,:,3,:)=tmpim;
    offsetim=squeeze(calicrops(:,:,1,:));
    varim=squeeze(calicrops(:,:,2,:));
    gainim=squeeze(calicrops(:,:,3,:));
    stacknum=getstepnum(filename);
    qd1=(qds(:,:,:,1)-repmat(offsetim(:,:,1),[1 1 size(qds,3) 1]))./repmat(gainim(:,:,1),[1 1 size(qds,3) 1]);
    qd2=(qds(:,:,:,2)-repmat(offsetim(:,:,2),[1 1 size(qds,3) 1]))./repmat(gainim(:,:,2),[1 1 size(qds,3) 1]);
    qd3=(qds(:,:,:,3)-repmat(offsetim(:,:,3),[1 1 size(qds,3) 1]))./repmat(gainim(:,:,3),[1 1 size(qds,3) 1]);
    qd4=(qds(:,:,:,4)-repmat(offsetim(:,:,4),[1 1 size(qds,3) 1]))./repmat(gainim(:,:,4),[1 1 size(qds,3) 1]);
    num_images=size(qds,3);
    
    [q1 q2 q3 q4]=iPALMast_RotAlign_FMT(qd1,qd2,qd3,qd4,fmfile);
    [v1 v2 v3 v4]=iPALMast_RotAlign_FMT(varim(:,:,1),varim(:,:,2),varim(:,:,3),varim(:,:,4),fmfile);
    [g1 g2 g3 g4]=iPALMast_RotAlign_FMT(gainim(:,:,1),gainim(:,:,2),gainim(:,:,3),gainim(:,:,4),fmfile);
    maskg=g1<=1|g2<=1|g3<=1|g4<=1;
    v1(maskg)=1e7;
    v2(maskg)=1e7;
    v3(maskg)=1e7;
    v4(maskg)=1e7;
    
    g1(maskg)=1e-7;
    g2(maskg)=1e-7;
    g3(maskg)=1e-7;
    g4(maskg)=1e-7;
    
    sumim1=q1+q2+q3+q4;
%     I(:,:,j)=sumim1;
%     I1(:,:,j)=q1;
%     I2(:,:,j)=q2;
%     I3(:,:,j)=q3;
%     I4(:,:,j)=q4;
%     q1=mean(qd1,3);
%     q2=mean(qd2,3);
%     q3=mean(qd3,3);
%     q4=mean(qd4,3);
%     I(:,:,1)=q1;
%     I(:,:,2)=q2;
%     I(:,:,3)=q3;
%     I(:,:,4)=q4;
    I=sumim1;
    I1=q1;
    I2=q2;
    I3=q3;
    I4=q4;
end
filestr=[current_folder filename(1:end-6) '.tif'];
tiffwrite(I,filestr);
% filestr=[current_folder filename(1:end-6) '_q1' '.tif'];
% tiffwrite(I1,filestr);
% filestr=[current_folder filename(1:end-6) '_q2' '.tif'];
% tiffwrite(I2,filestr);
% filestr=[current_folder filename(1:end-6) '_q3' '.tif'];
% tiffwrite(I3,filestr);
% filestr=[current_folder filename(1:end-6) '_q4' '.tif'];
% tiffwrite(I4,filestr);

%%
clear
clc

current_folder='F:\4PISCMOS\2018-5-29\Cell05\Cell12\';
files=dir([current_folder,'\*.dcimg']);

scmos_cali_file='readout1_tmpcalibration.mat';
tmpld=load(scmos_cali_file);
offsetim=tmpld.offsetim; 
varim=tmpld.varim;
gainim=tmpld.g3;    
caliims=cat(3,offsetim,varim,gainim);

I=[];
for j=1:numel(files)
    filename=files(j).name;
    centers=[235 474 1557 1797];
    display(['Reading dcimg files...']);
    [~,qds,calicrops]=iPALM_readdcimg([current_folder,filename],centers,caliims);
    qd1=qds(:,:,:,1);%-repmat(offsetim(:,:,1),[1 1 size(qds,3) 1]))./repmat(gainim(:,:,1),[1 1 size(qds,3) 1]);
%     q1=mean(qd1,3);
    I1=qd1;
end
filestr=[current_folder filename(1:end-6) '_q1' '.tif'];
tiffwrite(I1,filestr);
