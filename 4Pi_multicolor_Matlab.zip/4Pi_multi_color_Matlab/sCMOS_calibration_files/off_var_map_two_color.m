clear
clc

filename='G:\4PISCMOS\2016-8-9\Cell03\Cell03_405_000_000.dcimg';
for ii=1:1:4000
    ii
    rawim(:,:,ii)=dcimgmatlab(ii-1, filename)';
end
rawim=single(rawim);
omap=mean(rawim,3);
varmap=var(rawim,0,3);
%***************************************************************************************************************

filename='G:\4PISCMOS\2016-8-9\Cell04\Cell04_561_000_000.dcimg';
for ii=1:1:4000
    ii
    rawim(:,:,ii)=dcimgmatlab(ii-1, filename)';
end
rawim=single(rawim);
omap_50fps=mean(rawim,3);
varmap_50fps=var(rawim,0,3);
%***************************************************************************************************************

filename='G:\4PISCMOS\2016-8-9\Cell05\Cell05_561_000_000.dcimg';
for ii=1:1:4000
    ii
    rawim(:,:,ii)=dcimgmatlab(ii-1, filename)';
end
rawim=single(rawim);
omap_100fps=mean(rawim,3);
varmap_100fps=var(rawim,0,3);
%***************************************************************************************************************

filename='G:\4PISCMOS\2016-8-9\Cell06\Cell06_561_000_000.dcimg';
for ii=1:1:4000
    ii
    rawim(:,:,ii)=dcimgmatlab(ii-1, filename)';
end
rawim=single(rawim);
omap_200fps=mean(rawim,3);
varmap_200fps=var(rawim,0,3);
%***************************************************************************************************************

filename='G:\4PISCMOS\2016-8-9\Cell07\Cell07_561_000_000.dcimg';
for ii=1:1:4000
    ii
    rawim(:,:,ii)=dcimgmatlab(ii-1, filename)';
end
rawim=single(rawim);
omap_400fps=mean(rawim,3);
varmap_400fps=var(rawim,0,3);