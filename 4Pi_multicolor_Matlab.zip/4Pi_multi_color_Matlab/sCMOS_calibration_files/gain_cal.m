inversegain=zeros(256,2048);
for i=1:256
    for j=1:2048
        x(1,1)=0;
        y(1,1)=varmap(i,j);
        x(2,1)=omap_400fps(i,j)-omap(i,j);
        y(2,1)=varmap_400fps(i,j);
        x(3,1)=omap_200fps(i,j)-omap(i,j);
        y(3,1)=varmap_200fps(i,j);
        x(4,1)=omap_100fps(i,j)-omap(i,j);
        y(4,1)=varmap_100fps(i,j);
        x(5,1)=omap_50fps(i,j)-omap(i,j);
        y(5,1)=varmap_50fps(i,j);
        p=polyfit(x,y,1);
        inversegain(i,j)=p(1);
    end
end