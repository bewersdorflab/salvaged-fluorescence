mtc=(sxtot.^3./sytot-sytot.^3./sxtot)./40*2*pi; 
mask=Iresult>500 & llresult<300 & CRLBresult(:,5)<0.2 & CRLBresult(:,6)<0.2 & zangctrresult>0.3 & abs(mtc)<pi;
zangctrresult1=zangctrresult(mask);
stacktot1=stacktot(mask)+1;
zangresult1=zangresult(mask);
mtc1=mtc(mask);
E=[];
for i=1:max(stacktot1)
    id=stacktot1==i;
    E(i,1)=mean(zangctrresult1(id));
    A=mtc1(id);
    B=zangresult1(id);
    E(i,2)=std(mtc1(id));
end
    

