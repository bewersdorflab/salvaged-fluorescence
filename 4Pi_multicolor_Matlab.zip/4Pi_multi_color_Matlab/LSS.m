file='G:\4PISCMOS\test\drifttest_5msExp_200nm.tif';
I=tiffread(file);

% [sub_regions tlz locmaxc subvar_g]=iPALMast_sumim_seg(I,10,9,mean_v,mean_vg,0,1);
subvar_g=ones(15,15,1000);
sub_regions=I;
[P CRLB LL]=sCMOS_MLE_DB_YL_CUDA42(single(sub_regions(:,:,:)),1.4,200,2,single(subvar_g(:,:,:)),single(subvar_g(:,:,:).*0+1));
P(:,1)=P(:,1)-P(1,1);
P(:,2)=P(:,2)-P(1,2);

%%
L=1000;
Fs=200;
T=1/Fs; 
t=(0:L-1)'*T; 
NFFT=2^nextpow2(L); 
f=Fs/2*linspace(0,1,NFFT/2+1);
y1=P(:,1)*100;
Y1=fft(y1,NFFT)/L;
Y1_new=2*abs(Y1(1:NFFT/2+1));
figure;subplot(2,2,1);plot(f(1:NFFT/2+1),Y1_new(1:NFFT/2+1)); hold on 
xlabel('Frequency (Hz)')
ylabel('x (nm)')
axis([0 Fs/2 0 20])

y1d=diff(y1)/T;
Y1d = fft(y1d,NFFT)/L;
Y1d_new=2*abs(Y1d(1:NFFT/2+1));
subplot(2,2,2);plot(f(1:NFFT/2+1),Y1d_new(1:NFFT/2+1)); 
xlabel('Frequency (Hz)')
ylabel('velocity (nm/s)')
axis([0 Fs/2 0 2000])

y1=P(:,2)*100;
Y1=fft(y1,NFFT)/L;
Y1_new=2*abs(Y1(1:NFFT/2+1));
subplot(2,2,3);plot(f(1:NFFT/2+1),Y1_new(1:NFFT/2+1)); 
xlabel('Frequency (Hz)')
ylabel('y (nm)')
axis([0 Fs/2 0 20])

y1d=diff(y1)/T;
Y1d = fft(y1d,NFFT)/L;
Y1d_new=2*abs(Y1d(1:NFFT/2+1));
subplot(2,2,4);plot(f(1:NFFT/2+1),Y1d_new(1:NFFT/2+1)); 
xlabel('Frequency (Hz)')
ylabel('velocity (nm/s)')
axis([0 Fs/2 0 2000])