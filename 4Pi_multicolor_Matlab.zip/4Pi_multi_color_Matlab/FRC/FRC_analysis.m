%% from nature methods 2448
%% loading the data
% localizations of single emitters in the format:
%  x, y, t [pixels, pixels, frames]

fprintf('\n -- loading the data --\n')
coords=[];

% coords(:,1)=vutarax/128;
% coords(:,2)=vutaray/128;
% coords(:,3)=vutarat+1;

coords(:,1)=xresult;
coords(:,2)=yresult;
coords(:,3)=tresult+1;

pixelsize = 128;                                                           %in nanometers

%% make an overview image
totsz = 168;
superzoom = 16;
szx = superzoom * totsz;
szy = superzoom * totsz;

im = binlocalizations(coords, szx, szy, superzoom);
h=dipshow(im);
dipmapping(h,[0 5],'colormap',hot)


%% compute FIRE
fprintf('\n -- computing FIRE --\n')
[fire_value, ~, fireH, fireL] = postoresolution(coords, szx, superzoom); % in super-resolution pixels
fprintf('FIRE value %2.1f +- %2.2f [px]\n', fire_value, (fireL-fireH)/2);
fprintf('FIRE value %2.1f +- %2.2f [nm]\n', fire_value*pixelsize/superzoom, (fireL-fireH)/2*pixelsize/superzoom);


%% compute FIRE as a function of frame time (takes ~1-2min.)
fprintf('\n -- computing FIRE as a function of time for in 25 steps--\n')
tfrac = 25;
[~,~,~,~,fireT] = postoresolution(coords, szx, superzoom, 500, tfrac); % in super-resolution pixels
figure;
plot(linspace(0,1,tfrac),fireT*pixelsize/superzoom,'x-')
xlabel('time fraction')
ylabel('FIRE (nm)')
title('FIRE as a function of total number of frames')


%% compute FRC curve
fprintf('\n -- computing FRC curve--\n')
[~,frc_curve] = postoresolution(coords, szx, superzoom); 
figure;
qmax = 0.5/(pixelsize/superzoom);
plot(linspace(0,qmax*sqrt(2), length(frc_curve)), frc_curve,'-')
xlim([0,qmax])
hold on
plot([0 qmax],[1/7 1/7],'r-');
plot([0 qmax],[0 0],'k--'); hold off
xlabel('spatial frequency (nm^{-1})')
ylabel('FRC')
title('Fourier Ring Correlation curve')


%% compute FIRE (averaged over 20 runs)
fprintf('\n -- computing FIRE averaged over 20 random block splits --\n')
[fire_value, ~, fireH, fireL] = postoresolution(coords, szx, superzoom, 500,[], 20); % in super-resolution pixels
fprintf('FIRE value %2.1f +- %2.2f [px]\n', fire_value, (fireL-fireH)/2);
fprintf('FIRE value %2.1f +- %2.2f [nm]\n', fire_value*pixelsize/superzoom, (fireL-fireH)/2*pixelsize/superzoom);