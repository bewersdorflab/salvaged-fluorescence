%% loading the data
% localizations of single emitters in the format:
%  x, y, t [pixels, pixels, frames]
allcoords=handles.fitInfo(:,1:9);
segnum=max(allcoords(:,3))/8000;
% A=[];
% for i=1:segnum
%     i
%     st=(i-1)*800+1;
%     et=i*800;
%     id=allcoords(:,3)>=st & allcoords(:,3)<=et;
%     A(i,1:9)=mean(allcoords(id,:),1);
%     A(i,10)=sum(id);
% end
pixelsize = 103;                                                           %in nanometers

%%
D=[];
for i=1:segnum
    i
    % i=10;
%     st=(i-1)*8000+1;
    st=1;
    et=i*8000;
    id=allcoords(:,3)>=st & allcoords(:,3)<=et;
    coords=allcoords(id,1:3);
    % coords=allcoords(:,1:3);
    superzoom = handles.parameter.zm;
    szx = superzoom * handles.totsz;
    szy = superzoom * handles.totsz;
    
%     im = binlocalizations(coords, szx, szy, superzoom);
%     h=dipshow(im);
%     dipmapping(h,[0 5],'colormap',hot)
    
    fprintf('\n -- computing FIRE --\n')
    [fire_value, ~, fireH, fireL] = postoresolution(coords, szx, superzoom); % in super-resolution pixels
    fprintf('FIRE value %2.1f +- %2.2f [px]\n', fire_value, (fireL-fireH)/2);
    fprintf('FIRE value %2.1f +- %2.2f [nm]\n', fire_value*pixelsize/superzoom, (fireL-fireH)/2*pixelsize/superzoom);
    D(i,1)=fire_value*pixelsize/superzoom;
end

%% compute FIRE as a function of frame time (takes ~1-2min.)
fprintf('\n -- computing FIRE as a function of time for in 25 steps--\n')
tfrac = 25;
[~,~,~,~,fireT] = postoresolution(coords, szx, superzoom, 500, tfrac); % in super-resolution pixels
figure;
plot(linspace(0,1,tfrac),fireT*pixelsize/superzoom,'x-')
xlabel('time fraction')
ylabel('FIRE (nm)')
title('FIRE as a function of total number of frames')
min(fireT*pixelsize/superzoom)

%% compute FRC curve
fprintf('\n -- computing FRC curve--\n')
[~,frc_curve] = postoresolution(coords, szx, superzoom); 
figure;
qmax = 0.5/(pixelsize/superzoom);
plot(linspace(0,qmax*sqrt(2), length(frc_curve)), frc_curve,'-')
xlim([0,qmax])
hold on
plot([0 qmax],[1/7 1/7],'r-');
plot([0 qmax],[0 0],'k--'); hold off
xlabel('spatial frequency (nm^{-1})')
ylabel('FRC')
title('Fourier Ring Correlation curve')


%% compute FIRE (averaged over 20 runs)
fprintf('\n -- computing FIRE averaged over 20 random block splits --\n')
[fire_value, ~, fireH, fireL] = postoresolution(coords, szx, superzoom, 500,[], 20); % in super-resolution pixels
fprintf('FIRE value %2.1f +- %2.2f [px]\n', fire_value, (fireL-fireH)/2);
fprintf('FIRE value %2.1f +- %2.2f [nm]\n', fire_value*pixelsize/superzoom, (fireL-fireH)/2*pixelsize/superzoom);