close all 

clear all

%% readfile
foldername='D:\4Pi_two_color\20180520\';
num=xlsread([ foldername 'particles.csv']);
% tmpld=load('Y:\Fang\MATLAB\Projects\W-4PiSMSN\FRC\Nmeth\microtubule\MTcoords.mat');

%%
x=num(:,17);
y=num(:,18);
z=num(:,19);

SRpixelsize=7;

coords=[x-min(x) y-min(y) z-min(z)];
%%
zoom = 1;
coordsin = coords./SRpixelsize;
numpixelsx = ceil(max(coordsin(:,1)));
numpixelsy = ceil(max(coordsin(:,2)));
numpixelsz = ceil(max(coordsin(:,3)));
Nem = length(coordsin);
im1 = binlocalizations3D(coordsin(1:round(Nem/2),1:3),numpixelsx,numpixelsy,numpixelsz,zoom);
im1 = mat2im(im1);
im2 = binlocalizations3D(coordsin(round(Nem/2)+1:end,1:3),numpixelsx,numpixelsy,numpixelsz,zoom);
im2 = mat2im(im2);
Nim1 = imsize(im1);

% crop images
Nsize = 512;
xmin = 1337;
ymin = 1221;
zmin = 0;
imcrop1 = cut(im1,Nsize,[xmin ymin zmin]);
imcrop2 = cut(im2,Nsize,[xmin ymin zmin]);
szCR = imsize(imcrop1);
imcrop1 = extend(imcrop1,[szCR(1) szCR(1) szCR(1)]);
imcrop2 = extend(imcrop2,[szCR(1) szCR(1) szCR(1)]);
clear im1 im2

%%
% pixelsize
% Fourier transform input images
in1 = ft(imcrop1);
in2 = ft(imcrop2);

% Compute fourier ring correlation curve
frc_num = real(radialsum(in1.*conj(in2)));                                  % Numerator
in1 = abs(in1).^2;
in2 = abs(in2).^2;
frc_denom = sqrt(abs(radialsum(in1).*radialsum(in2)));                      % Denominator
frc_out = double(frc_num)./double(frc_denom);                               % FRC
frc_out(isnan(frc_out)) = 0;  

[fire_value, fireH, fireL] = frctoresolution3d(frc_out,Nsize);
fprintf('FIRE value %2.1f +- %2.2f [px]\n', fire_value, (fireL-fireH)/2);
fprintf('FIRE value %2.1f +- %2.2f [nm]\n', fire_value*SRpixelsize, (fireL-fireH)/2*SRpixelsize);

%% fourier plane 
[fpc_xy,fpc_xz,fpc_yz,fpc_out]=fpc(imcrop1,imcrop2);
dipshow(fpc_xy,'lin')
dipshow(fpc_xz,'lin')
dipshow(fpc_yz,'lin')


%% fourier
sz=imsize(fpc_out);
h=dipshow(fpc_out,'lin');
dipmapping(h,'global','slice',round(sz(1)/2))