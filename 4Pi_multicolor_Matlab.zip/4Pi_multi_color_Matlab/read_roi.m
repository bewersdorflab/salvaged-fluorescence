str='G:\4PISCMOS\2018-1-21\Cell02-1068-1029.roi';
roi=ReadImageJROI(str);
Rc=roi.mnCoordinates;
Rc(end+1,:)=Rc(1,:);
I=zeros(2150,2150);
BW=roipoly(I,Rc(:,1),Rc(:,2));
B=bwboundaries(BW);
B=B{1}/zm2;
maskroi=inpolygon(V(:,1),V(:,2),B(:,2),B(:,1));

% L=length(roi);
% I=zeros(sz*zm2,sz*zm2);
% Cluster=[];
% cellInfo=zeros(L,4);
% Vnew=[];
% VT=[];
% Vt=[];
% for i=1:L
%     Rc=roi{1,i}.mnCoordinates;
%     Rc(end+1,:)=Rc(1,:);
%     BW=roipoly(I,Rc(:,1),Rc(:,2));
%     B=bwboundaries(BW);
%     B=B{1}/zm2;
%     ind=inpolygon(V(:,1),V(:,2),B(:,2),B(:,1));
%     V1=V(ind,:);
% end