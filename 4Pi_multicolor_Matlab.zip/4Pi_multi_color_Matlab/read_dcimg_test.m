clear
clc
current_folder='G:\4PISCMOS\2018-5-15\Cell08\';
files=dir([current_folder,'\*.dcimg']);
I=[];
for j=1:numel(files)
    j
    filename=files(j).name;
    centers=[235 474 1557 1797];
    [tmp totalframes]= dcimgmatlab(0, [current_folder,filename]);
    if totalframes<10
        filename;
    end
end