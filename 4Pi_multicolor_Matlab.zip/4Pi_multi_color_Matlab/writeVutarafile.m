clear
clc
currentfolder='D:\4Pi_two_color\2017-4-11\';
str=strcat(currentfolder,'*_561v20_60.mat');
files=dir(str);
for i=1:length(files)
    i
    filename=files(i).name;
    str=strcat(currentfolder,filename);
    load(str);
    savename=filename(1:6);
    [flag]=iPALM2vutarav2(currentfolder,[savename '_ll'],1,{vutarax},{vutaray},{vutaraz},{vutarat},{vutaraI},{vutaracrlb},{vutarall},{vutarabg},{vutarazcon},{vutarazerr});
end
