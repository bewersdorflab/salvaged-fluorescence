MultiDM04 is what is provided on the disk for the 3rd deformable mirror that were used on Aug 9th 2014 to replace the broken deformable mirror. 
MultiMap_MikeFeinberg is attached in George's forwarded email.

The above 2 map file defer 2 numbers 59 and 60;